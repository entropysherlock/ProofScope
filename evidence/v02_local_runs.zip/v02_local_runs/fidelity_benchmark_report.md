# ProofScope report

ProofScope 0.2.0 · Lean (version 4.34.1, x86_64-unknown-linux-gnu, commit 5045d0056413266e57c625dcd7c365b10e377c52, Release) · 2026-11-08 20:48:19 UTC

## Kernel controls

- honest module accepted: **PASS**
- forged module rejected by replay: **PASS**
- forged declaration looked axiom-clean before replay: True

## Definition pairs

| Case | Group | Expected | Classification | Certificates (replayed) |
|---|---|---|---|---|
| `C1_equivalent_rewritten` | control | EQUIVALENT_CERTIFIED | **EQUIVALENT_CERTIFIED** ✓ | agree_domain, agree_domain_bounded, equal_all |
| `C2_off_by_one_boundary` | control | DISCREPANCY_IN_DOMAIN_CERTIFIED | **DISCREPANCY_IN_DOMAIN_CERTIFIED** ✓ | witness_all_bounded, witness_domain, witness_domain_bounded |
| `C3_missing_hypothesis` | control | DISCREPANCY_IN_DOMAIN_CERTIFIED | **DISCREPANCY_IN_DOMAIN_CERTIFIED** ✓ | witness_all, witness_all_bounded, witness_domain, witness_domain_bounded |
| `C4_quantifier_order` | control | DISCREPANCY_IN_DOMAIN_CERTIFIED | **DISCREPANCY_IN_DOMAIN_CERTIFIED** ✓ | witness_all, witness_domain |
| `C5_irrelevant_outside_domain` | control | DISCREPANCY_OUTSIDE_DOMAIN_ONLY_CERTIFIED | **DISCREPANCY_OUTSIDE_DOMAIN_ONLY_CERTIFIED** ✓ | agree_domain, agree_domain_bounded, witness_all, witness_all_bounded |
| `C6_genuine_inside_domain` | control | DISCREPANCY_IN_DOMAIN_CERTIFIED | **DISCREPANCY_IN_DOMAIN_CERTIFIED** ✓ | witness_all, witness_all_bounded, witness_domain, witness_domain_bounded |
| `C8_sorry_route_rejected` | control | DISCREPANCY_IN_DOMAIN_CERTIFIED | **DISCREPANCY_IN_DOMAIN_CERTIFIED** ✓ | witness_all_bounded, witness_domain, witness_domain_bounded |
| `M1_ceilDiv_drops_minus_one` | mutant | DISCREPANCY_IN_DOMAIN_CERTIFIED | **DISCREPANCY_IN_DOMAIN_CERTIFIED** ✓ | witness_all, witness_all_bounded, witness_domain_bounded |
| `M2_ceilDiv_becomes_floor` | mutant | DISCREPANCY_IN_DOMAIN_CERTIFIED | **DISCREPANCY_IN_DOMAIN_CERTIFIED** ✓ | witness_all, witness_all_bounded, witness_domain_bounded |
| `M3_ceilSqrt_becomes_floor_sqrt` | mutant | DISCREPANCY_IN_DOMAIN_CERTIFIED | **DISCREPANCY_IN_DOMAIN_CERTIFIED** ✓ | witness_all_bounded, witness_domain_bounded |
| `M4_ceilSqrt_always_rounds_up` | mutant | DISCREPANCY_IN_DOMAIN_CERTIFIED | **DISCREPANCY_IN_DOMAIN_CERTIFIED** ✓ | witness_all, witness_all_bounded, witness_domain_bounded |
| `R1_ceilDiv_vs_textbook` | real | DISCREPANCY_OUTSIDE_DOMAIN_ONLY_CERTIFIED | **DISCREPANCY_OUTSIDE_DOMAIN_ONLY_CERTIFIED** ✓ | agree_domain, agree_domain_bounded, witness_all, witness_all_bounded |
| `R2_ceilSqrt_vs_least_k` | real | — | **BOUNDED_AGREEMENT_ONLY** | agree_domain_bounded |

### Interpretations

- `C1_equivalent_rewritten`: Kernel-checked proof that the custom definition equals the reference everywhere: no scope change.
- `C2_off_by_one_boundary`: Kernel-checked witness of disagreement on the theorem's own domain: candidate scope change, needs expert review.
- `C3_missing_hypothesis`: Kernel-checked witness of disagreement on the theorem's own domain: candidate scope change, needs expert review.
- `C4_quantifier_order`: Kernel-checked witness of disagreement on the theorem's own domain: candidate scope change, needs expert review. (uses pair-specific tactics/lemmas)
- `C5_irrelevant_outside_domain`: Certified difference, but certified agreement on the theorem's domain: a convention (e.g. junk values), not a scope change.
- `C6_genuine_inside_domain`: Kernel-checked witness of disagreement on the theorem's own domain: candidate scope change, needs expert review.
- `C8_sorry_route_rejected`: Kernel-checked witness of disagreement on the theorem's own domain: candidate scope change, needs expert review. (uses pair-specific tactics/lemmas)
  - rejected candidates: {'equal_all': 'depends on sorryAx', 'agree_domain': 'depends on sorryAx'}
- `M1_ceilDiv_drops_minus_one`: Kernel-checked witness of disagreement on the theorem's own domain: candidate scope change, needs expert review.
- `M2_ceilDiv_becomes_floor`: Kernel-checked witness of disagreement on the theorem's own domain: candidate scope change, needs expert review.
- `M3_ceilSqrt_becomes_floor_sqrt`: Kernel-checked witness of disagreement on the theorem's own domain: candidate scope change, needs expert review.
- `M4_ceilSqrt_always_rounds_up`: Kernel-checked witness of disagreement on the theorem's own domain: candidate scope change, needs expert review.
- `R1_ceilDiv_vs_textbook`: Certified difference, but certified agreement on the theorem's domain: a convention (e.g. junk values), not a scope change. (uses pair-specific tactics/lemmas)
- `R2_ceilSqrt_vs_least_k`: Agreement verified by kernel computation on a finite box only; no general certificate.

## Metrics

```
{
 "labelled_cases": 12,
 "exact_label_accuracy": "12/12",
 "in_domain_discrepancy": {
  "tp": 9,
  "fp": 0,
  "fn": 0,
  "tn": 3,
  "precision": 1.0,
  "recall": 1.0
 },
 "certificates_replayed": 39,
 "inconsistent_runs": 0,
 "note": "Controls and mutants are constructed by the project itself: they show the engine behaves as designed, not that it generalises to unseen formalizations."
}
```

## Static scan

| File | Defs flagged | Unproved statements | Hazards |
|---|---|---|---|
| `CliqueFreeLog.lean` | 1 | 1 | sorry: 1 |
| `CourtadeKumar.lean` | 9 | 1 | sorry: 1 |
| `DepthFive.lean` | 3 | 1 | sorry: 1 |

## VERDICT

- Kernel controls PASSED: this machine's checker accepts an honest module and rejects a forged one.
- Labelled benchmark: 12/12 cases got the expected label; 39 certificates passed kernel replay.
- Real definition pairs: no theorem-relevant discrepancy was certified. That is a negative result, reported as such.
- Nothing here is a peer-reviewed finding. A certified difference shows two formal notions disagree; whether that changes the paper's claim is a human judgement.

## Limits

- leanchecker replay uses the same kernel implementation as Lean; it is an anti-tampering replay, not an independent kernel.
- Reference definitions and theorem domains are supplied by a person or AI and must be reviewed independently.
- Bounded agreement is certified only on the stated finite box.
- INCONCLUSIVE means the search failed; it is never counted as a pass.
