# v0.2 local runs (not GitHub Actions)

Produced on November 8, 2026 in a Linux sandbox with Lean 4.34.1, before v0.2 was run on GitHub. They are
included so the first GitHub run can be compared against them. They are not CI results.

- `openai_math_catalog_no_build/`: `python3 -m proofscope.project` on openai/math at `4eaee875`, subdirectory `lean`,
  with the catalog check and the Hadwiger counterexample's `Main` module as target. No build stage (no project code
  executed). Result: PASS; 208/208 catalog main results mechanically consistent; 374 files in the target's import
  closure hashed; no text-level trust hazards.
- `fidelity_benchmark_report.*`: `python3 -m proofscope.fidelity benchmark --scan examples/lean`. Kernel controls
  passed; 12/12 labelled cases; 39 certificates replayed.
