# ProofScope project audit

ProofScope 0.2.0 · 2026-11-08T20:49:46.665926+00:00

- Repository: https://github.com/openai/math
- Commit: `4eaee87548250b2682affda7d05d947c05554bae` (subdir `lean`)
- Targets: OAI.Combinatorics.HadwigerCounterexample.Main
- Build stage: not run (no project code executed)

Overall: **PASS** · HUMAN_REVIEW: 1 · VERIFIED: 9 · INFO: 3

## Findings

| Stage | Status | Check | Subject | Detail |
|---|---|---|---|---|
| S0 | **VERIFIED** | input validation | `arguments` | repository URL, 40-hex commit and Lean names accepted |
| S1 | **VERIFIED** | fetch pinned commit | `4eaee87548250b2682affda7d05d947c05554bae` | HEAD matches; tree 71e8eaa37259d11418fe4ee382a0f82b91ea973e |
| S2 | **VERIFIED** | Lean toolchain pinned | `leanprover/lean4:v4.34.1` |  |
| S2 | **VERIFIED** | lakefile requirements pinned to commits | `lakefile.lean` | 30 requirements |
| S2 | **VERIFIED** | lake-manifest dependency revisions | `42 packages` | all pinned to exact commits |
| S2 | **INFO** | dependencies tracking a branch or tag | `12 packages` | the manifest pins exact commits, but `lake update` would move these: plausible, LeanSearchClient, importGraph, proofwidgets, aesop, Qq, batteries, leansqlite, Cli, UnicodeBasic, BibtexQuery, MD4Lean |
| S5 | **INFO** | formalization.yaml catalog | `208 main results, 176 sources` |  |
| S5 | **VERIFIED** | catalog entries mechanically consistent | `208 checked` | 208 consistent, 0 warning, 0 failing (file exists, declaration found, comparator config lists it and the solution module imports it) |
| S5 | **HUMAN_REVIEW** | paper-to-Lean statement fidelity | `208 entries` | not decidable mechanically: each statement must be compared with its paper by a qualified reviewer |
| S5 | **INFO** | comparator challenges outside the catalog | `227 of 418` | these challenges have no main-result catalog entry linking them to a paper |
| S3 | **VERIFIED** | target module present | `OAI.Combinatorics.HadwigerCounterexample.Main` | OAI/Combinatorics/HadwigerCounterexample/Main.lean |
| S3 | **VERIFIED** | local import closure hashed | `288 files` | external import roots: Lean, Mathlib (pinned by the manifest, not re-hashed here) |
| S4 | **VERIFIED** | trust hazards in import closure | `288 files` | no sorry, admit, axiom, native_decide, unsafe, implemented_by or kernel-check bypass found (text scan) |

## What the labels mean

- **VERIFIED**: established mechanically in this run (see logs).
- **WARNING**: established, but weakens trust or needs a second look.
- **FAIL**: a check that should hold does not.
- **INCONCLUSIVE**: the check could not be completed; never counted as a pass.
- **HUMAN_REVIEW**: cannot be decided mechanically; needs a qualified reviewer.
- **INFO**: context only.

## VERDICT

- The audited source is exactly commit 4eaee8754825 of https://github.com/openai/math.
- 288 project files in the targets' import closure were hashed.
- No trust hazards were found in that closure by text scan.
- Catalog: 208 consistent, 0 warning, 0 failing (file exists, declaration found, comparator config lists it and the solution module imports it).
- The build stage was not run, so nothing here says the proofs compile.
- Overall status PASS. Whether each Lean statement matches its paper remains a human judgement.

## Trust and limits

- Text-level scans (S3-S5) can miss hazards hidden behind macros or produced by metaprograms; S6 is the semantic check.
- `leanchecker` uses the same kernel implementation as Lean; replay is an anti-tampering check, not an independent kernel.
- When S6 uses the official Mathlib binary cache, those compiled files are trusted, not rebuilt.
- No finding here says that a formal statement means what the paper claims; that is labelled HUMAN_REVIEW.
