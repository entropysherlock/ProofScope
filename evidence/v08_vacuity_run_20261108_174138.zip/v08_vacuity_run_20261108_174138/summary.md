# WESTFALL V0.8 summary

Commit `4eaee87548250b2682affda7d05d947c05554bae` · 20261108_174138 UTC · source clean True · forgery control PASS · self-test PASS

## Vacuity (top-level hypotheses of each challenge statement)

| Status | Statements |
|---|---|
| NO_TOPLEVEL_HYPOTHESES | 11 |
| INCONCLUSIVE_SEARCH_FAILED | 9 |
| NONVACUOUS_PROVEN | 5 |

## Definitions

390 challenge-file definitions audited; 86 carry heuristic flags for human review (see definitions.csv).

## Coverage

| Category | Paper statements |
|---|---|
| NEEDS_HUMAN_REVIEW | 276 |

## Limits

- official Mathlib binary cache
- single kernel implementation (leanchecker = same kernel)
- only top-level hypotheses analysed; nested ones are out of scope
- draft verdicts are AI-assisted and await a named reviewer's signature
- INCONCLUSIVE means the bounded tactic search found neither certificate; it is never counted as a pass.
