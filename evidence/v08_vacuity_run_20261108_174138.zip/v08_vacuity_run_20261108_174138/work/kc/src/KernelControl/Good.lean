theorem kc_good_add : 1 + 1 = 2 := rfl
