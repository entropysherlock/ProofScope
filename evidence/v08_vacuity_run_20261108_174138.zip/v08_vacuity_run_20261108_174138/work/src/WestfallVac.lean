import Lean

/-!
# WESTFALL V0.8 — vacuity analysis with kernel-checked certificates

`#westfall_vac decl` analyses the top-level hypotheses of `decl`
(binders whose type is a proposition) and tries to settle, with proofs checked by the kernel:

* **contradiction certificate** `∀ binders, False`   — the hypotheses can never hold together (VACUOUS);
* **witness certificate**       `∃ data, H₁ ∧ … ∧ Hₙ` — some instance satisfies all hypotheses (NON-VACUOUS).

Each successful proof is added with `addDecl`, so the kernel type-checks it; certificates whose axioms include
`sorryAx` are rejected (this blocks proofs that route through the unproved challenge statement itself).
A failed search is reported as INCONCLUSIVE, never as a pass.

Prior work: `atp-checkers` (Faults in Our Formal Benchmarking, ICML 2026) proves `False` from hypotheses inside
MetaM. This command differs in emitting persistent, kernel-checked certificate declarations (re-checkable with
`leanchecker`), in also searching for satisfiability witnesses, and in its explicit three-way outcome.

Output lines (logged as `info`):
`WESTFALL|<decl>|<status>|<certificate or ->|<tactic or ->|<detail>`
-/

open Lean Elab Command Meta Term

namespace WestfallV08

/-- Tactics tried for the contradiction certificate (strings parsed at run time; unknown tactics are skipped). -/
def contraTactics : List String :=
  ["intros; omega", "intros; simp_all", "intros; grind", "intros; norm_num at *", "intros; linarith",
   "intros; aesop", "intros; exact absurd ‹_› (by decide)"]

/-- Generic tactics tried for the witness certificate. -/
def witnessTactics : List String :=
  ["decide", "simp", "trivial", "grind", "aesop", "norm_num"]

/-- Small numerals tried as a shared witness for all data binders (`exists v, v, …`). -/
def witnessValues : List String := ["0", "1", "2", "3", "4", "5", "6", "8", "10", "100"]

/-- Alternatives used to close goals after `exists`; only those that parse in the current environment are used. -/
def finisherAlternatives : List String := ["decide", "omega", "simp", "norm_num", "trivial", "grind"]

def heartbeatsPerAttempt : Nat := 20000

def parses (env : Environment) (t : String) : Bool :=
  match Parser.runParserCategory env `tactic t with
  | .ok _ => true
  | .error _ => false

/-- Run one tactic string on a fresh goal of closed type `goal`. Returns the proof term only on full success:
no goals left, no metavariables or synthetic `sorry` in the term, and no new error messages logged. The state,
including the message log, is always restored, so failed or noisy attempts leave no trace. -/
def runTactic (goal : Expr) (tac : String) : TermElabM (Option Expr) := do
  let env ← getEnv
  match Parser.runParserCategory env `tactic s!"({tac})" with
  | .error _ => return none
  | .ok stx =>
    let s ← saveState
    let before := (← getThe Core.State).messages
    let result ← tryCatchRuntimeEx
      (do
        let mv ← mkFreshExprMVar goal
        let rest ← withTheReader Core.Context (fun c => { c with maxHeartbeats := heartbeatsPerAttempt * 1000 }) <|
          withCurrHeartbeats <| Term.withoutErrToSorry <| Tactic.run mv.mvarId! (Tactic.evalTactic stx)
        let newErrors := (← getThe Core.State).messages.hasErrors && !before.hasErrors
        if !rest.isEmpty || newErrors then return none
        let pf ← instantiateMVars mv
        if pf.hasMVar || pf.hasSyntheticSorry then return none
        return some pf)
      (fun _ => pure none)
    -- On failure roll everything back. On success keep the environment (tactics such as `omega` add auxiliary
    -- lemmas that the proof term refers to) but drop any messages the attempt produced.
    if result.isNone then s.restore
    modifyThe Core.State fun st => { st with messages := before }
    return result

/-- Add a certificate theorem (the kernel checks it) and reject it if it depends on `sorryAx`. -/
def addCertificate (name : Name) (lps : List Name) (ty pf : Expr) : TermElabM (Except String (Array Name)) := do
  let before := (← getThe Core.State).messages
  try
    addDecl (Declaration.thmDecl { name, levelParams := lps, type := ty, value := pf })
  catch e =>
    return .error s!"kernel rejected: {← e.toMessageData.toString}"
  -- guard against deferred kernel errors: the message log must not have gained an error
  if (← getThe Core.State).messages.hasErrors && !before.hasErrors then
    modifyThe Core.State fun st => { st with messages := before }
    return .error "kernel reported an error for the certificate; discarded"
  match (← getEnv).find? name with
  | some (.thmInfo _) => pure ()
  | _ => return .error "certificate was not recorded as a checked theorem; discarded"
  let axs ← collectAxioms name
  if axs.contains name then
    return .error "certificate appears among its own axioms (kernel check did not complete); discarded"
  if axs.contains ``sorryAx then
    return .error "certificate depends on sorryAx (it used an unproved statement); discarded"
  return .ok axs

/-- Try each tactic in turn; the first proof that the kernel accepts without `sorryAx` wins. -/
def search (goal : Expr) (tacs : List String) (certName : Name) (lps : List Name) :
    TermElabM (Option (String × Array Name) × List String) := do
  let mut notes : List String := []
  let mut k := 0
  for tac in tacs do
    if let some pf ← runTactic goal tac then
      let nm := certName.appendIndexAfter k
      k := k + 1
      match ← addCertificate nm lps goal pf with
      | .ok axs => return (some (s!"{nm}::{tac}", axs), notes)
      | .error msg => notes := notes ++ [s!"{tac}: {msg}"]
  return (none, notes)

def emit (fields : List String) : TermElabM Unit :=
  logInfo m!"{"WESTFALL|" ++ "|".intercalate (fields.map fun s => s.replace "|" "/" |>.replace "\n" " ")}"

/-- The analysis behind `#westfall_vac`. -/
def analyze (declName : Name) (tag : String) (manual : List String := []) : TermElabM Unit := do
  let some ci := (← getEnv).find? declName
    | emit [declName.toString, "ERROR", "-", "-", "declaration not found"]; return
  let lps := ci.levelParams
  let built? ← forallTelescope ci.type fun xs _ => do
    let mut props := #[]
    let mut data := #[]
    for x in xs do
      if ← isProp (← inferType x) then props := props.push x else data := data.push x
    if props.isEmpty then return none
    let propIds := props.map (·.fvarId!)
    let mut dependent := false
    for x in xs do
      let t ← inferType x
      if propIds.any (fun p => t.containsFVar p) then dependent := true
    let contra ← mkForallFVars xs (mkConst ``False)
    if dependent then return some (contra, none, props.size, data.size)
    let ptys ← props.mapM (fun p => inferType p)
    let mut conj := ptys.back!
    for i in (List.range (ptys.size - 1)).reverse do
      conj := mkApp2 (mkConst ``And) ptys[i]! conj
    let mut w := conj
    for x in data.reverse do
      w ← mkAppM ``Exists #[← mkLambdaFVars #[x] w]
    return some (contra, some w, props.size, data.size)
  match built? with
  | none =>
    emit [declName.toString, "NO_TOPLEVEL_HYPOTHESES", "-", "-",
          "no top-level propositional hypotheses; nested hypotheses (under ∃/∧) are not analysed"]
  | some (contra, w?, np, nd) =>
    let base := (`WestfallV08Cert).str tag
    let (cRes, cNotes) ← search contra (manual ++ contraTactics) (base.str "vacuous") lps
    let mut wRes : Option (String × Array Name) := none
    let mut wNotes : List String := []
    if let some w := w? then
      let env ← getEnv
      let fin := " | ".intercalate (finisherAlternatives.filter (parses env))
      let numeric := witnessValues.map fun v =>
        s!"exists {", ".intercalate (List.replicate nd v)} <;> first | {fin}"
      let small := ["0", "1", "2", "3", "4", "5", "7", "10"]
      let pairs := if nd == 2 then (small.flatMap fun a => small.map fun b => s!"exists {a}, {b} <;> first | {fin}") else []
      let tacs := manual ++ (if nd == 0 then witnessTactics else witnessTactics ++ numeric ++ pairs)
      let (r, n) ← search w tacs (base.str "witness") lps
      wRes := r; wNotes := n
    let detail := s!"hyps={np} data={nd}" ++
      (if cNotes.isEmpty && wNotes.isEmpty then "" else s!"; discarded: {cNotes ++ wNotes}")
    match cRes, wRes with
    | some (c, axs), none =>
      emit [declName.toString, "VACUOUS_PROVEN", c.splitOn "::" |>.head!, c.splitOn "::" |>.getLast!,
            detail ++ s!"; certificate axioms {axs.toList}"]
    | none, some (c, axs) =>
      emit [declName.toString, "NONVACUOUS_PROVEN", c.splitOn "::" |>.head!, c.splitOn "::" |>.getLast!,
            detail ++ s!"; certificate axioms {axs.toList}"]
    | some (c1, _), some (c2, _) =>
      emit [declName.toString, "BOTH_PROVEN_ENVIRONMENT_INCONSISTENT", s!"{c1} ; {c2}", "-", detail]
    | none, none =>
      let why := if w?.isNone then "witness not attempted (hypothesis types depend on proofs)" else "no tactic closed either goal"
      emit [declName.toString, "INCONCLUSIVE_SEARCH_FAILED", "-", "-", s!"{detail}; {why}"]

/-- `#westfall_vac decl "tag" "extra tactic ;; extra tactic"` — the optional third argument supplies manual
tactics (tried first, for both goals; they are subject to the same kernel and `sorryAx` checks). -/
syntax (name := westfallVac) "#westfall_vac " ident (ppSpace str)? (ppSpace str)? : command

@[command_elab westfallVac] def elabWestfallVac : CommandElab := fun stx => do
  let id := stx[1]
  let tag := if stx[2].isNone then "c" else (stx[2][0].isStrLit?.getD "c")
  let manual := if stx[3].isNone then [] else
    ((stx[3][0].isStrLit?.getD "").splitOn ";;" |>.map (fun s => s.trimAscii.toString) |>.filter (· ≠ ""))
  liftTermElabM do
    let some n ← (try some <$> realizeGlobalConstNoOverloadWithInfo id catch _ => pure none)
      | emit [id.getId.toString, "ERROR", "-", "-", "name did not resolve"]
    analyze n tag manual

end WestfallV08
