import WestfallVac
import Mathlib.Data.Real.Basic
set_option warn.sorry false
theorem WPre.r (x : ℝ) (h : x < x) : x = 0 := sorry
#westfall_vac WPre.r "p1"
