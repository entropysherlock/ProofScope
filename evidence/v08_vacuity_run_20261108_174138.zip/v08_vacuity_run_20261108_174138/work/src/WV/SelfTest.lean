import WestfallVac
namespace WSelf
set_option warn.sorry false
theorem vac (n : Nat) (h : n < 0) : n = 5 := sorry
theorem nonvac (n : Nat) (h : 4 ≤ n) (h2 : n ≤ 9) : n * n ≥ 16 := sorry
theorem nohyp : ¬ ∃ n : Nat, n < 0 := sorry
theorem bad : ∃ n : Nat, n > 100 := sorry
theorem guard (n : Nat) (h : n > 100) : True := sorry
end WSelf
#westfall_vac WSelf.vac "s1"
#westfall_vac WSelf.nonvac "s2"
#westfall_vac WSelf.nohyp "s3"
#westfall_vac WSelf.guard "s4" "exact WSelf.bad"
