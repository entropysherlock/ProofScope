# Coverage report — An explicit counterexample to the Auslander-Reiten conjecture

Preprint `An-explicit-counterexample-to-the-Auslander-Reiten-conjecture-September-23-2026` · commit `4eaee8754825` · 20261108_174138 UTC

Linked challenges: `AuslanderReiten` (no verdict)

| Paper statement | Kind | Coverage | Basis |
|---|---|---|---|
| `thm:main`  Let $\kk=\mathbb F_2(q,H_1,H_2)$, where $q,H_1,H_2$ are algebraically independent. There exist a finite-dimensional $\kk$-algebra $\Lambda$ | theorem | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `conv:proposition`  Let $A$ be a finite-dimensional symmetric algebra over a field $\kk$ of characteristic two, let $F$ be a finite $A$-bimodule projective on  | proposition | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `conv:comparison`  Let $R$ be a finite-dimensional algebra over a field of characteristic two. Let $P_\bullet$ be a totally acyclic complex of finite projecti | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `alg:C`  The rules \eqref{alg:C-corners}--\eqref{alg:C-products} define an associative unital algebra of dimension ten. Its radical is the span of t | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `alg:T`  The algebra $T$ is symmetric of dimension twenty. A symmetrizing trace is \[ \lambda(a,\phi)=\phi(1), \] and the trace-dual of each basis l | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `coc:data`  The cochain $p$ has weight $-1$ and is a Hochschild cocycle. Its associated class evaluated on $s$ is nonzero in $\Ext_T^3(s,s)$. For any $ | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `res:base`  A projective resolution $R\to s$ over $C$ has terms \[ R_0=Cf,\qquad R_i=Ce\quad(i\geq1), \] and differentials given by right multiplicatio | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `res:polynomial`  For the algebra $T=C\ltimes DC$ and its left $f$-simple $s$, \[ \Ext_T^*(s,s)=\kk[\tau],\qquad |\tau|=3, \] as a graded algebra, where $\ta | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `res:tensor`  The simple left $A$-module $X$ is nonprojective, and \[ \bigoplus_{a\geq0}\stHom{A}{X}{X[a]} =\kk[\tau_1,\tau_2],\qquad |\tau_1|=|\tau_2|=3 | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `cone:finite`  Let $P$ be the bimodule bar resolution of $T$ and let $p:P\to P[3]$ be the selected comparison map. Form the ordinary complex \[ K=\operato | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `cone:profile`  For the finite side-projective bimodule $\mathcal C$ of Lemma~\ref{cone:finite}, put \[ W^a=\stHom{A}{X}{(\mathcal C\otimes_A X)[a]}. \] Fo | proposition | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `lift:main`  For each $H\in\kk^\times$, there is a stable bimodule map \[ f_H:U_H\longrightarrow\mathcal C[3] \] whose composite with the top-cell proje | proposition | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `lift:B`  On the nonnegative resolutions, with $B_{-1}=0$, one has \[ dB+Bd=D_b. \] | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `lift:G`  There are bimodule maps $G_i:Q_i\to P_{i-1}$ for all $i\geq0$ such that \[ pB=dG+Gd. \] | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `lift:evaluation`  Under $U_H\otimes_A X\simeq X$, the evaluated map $\beta_H X$ sends $1$ to $H^2(f^*\otimes f^*)$ in $\Omega X\subset A(f\otimes f)$. It doe | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `branch:profile`  Put $V^a=\stHom{A}{X}{FX[a]}$ for each integer $a$. There is a unique $v\in V^0$ whose two projections are $\id_X$. It spans $V^0$. For eve | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `branch:twist`  For $H\in\{H_1,H_2\}$, tensoring with $U_H=A_{h_H\otimes h_H}$, under its canonical identification on $X$, acts on the whole space $H^{3m}$ | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `branch:comparison`  The finite bimodule $F$ in \eqref{branch:finite-fiber} is projective on both $A$-sides, and the map $v$ of Lemma~\ref{branch:profile} satis | proposition | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `prop:radical`  The algebra $\Lambda$ is noncommutative, satisfies $\Lambda/\rad\Lambda\simeq\kk^8$, and has $\rad(\Lambda)^4\ne0$. | proposition | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `prop:basechange`  For every field extension $K/\kk$, the algebra $\Lambda_K=K\otimes_\kk\Lambda$ and module $Z_K=K\otimes_\kk Z$ satisfy all conclusions of T | proposition | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |

Categories: FORMALIZED / FORMALIZED_PARTIAL / PAPER_ONLY (reviewer-confirmed, DRAFT until signed) · NEEDS_HUMAN_REVIEW · UNKNOWN_NOT_REVIEWED · CANNOT_JUDGE (needs a domain expert). Nothing here is inferred automatically.
