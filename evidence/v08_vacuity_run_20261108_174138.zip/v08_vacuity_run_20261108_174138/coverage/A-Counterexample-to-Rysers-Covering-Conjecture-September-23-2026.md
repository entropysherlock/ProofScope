# Coverage report — A counterexample to Ryser's covering conjecture

Preprint `A-Counterexample-to-Rysers-Covering-Conjecture-September-23-2026` · commit `4eaee8754825` · 20261108_174138 UTC

Linked challenges: `BalancedRyser` (no verdict)

| Paper statement | Kind | Coverage | Basis |
|---|---|---|---|
| `lem:gadget`  For every sufficiently large prime \(s\equiv2\pmod3\), there is a set \(Y\subseteq\F_s^2\) with the following properties. For each \(d\in\F | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `con-deletion-count`  For every candidate and every \(d\in S_i\), exactly \(s-1\) lines of \(\mathcal B_{i,k}\) have direction \(d\). Each of these lines contain | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `con-pool-properties`  There are constants \(\delta\in(0,1)\) and \(\rho=\delta/10\), independent of \(n\), with the following properties with probability tending | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `con-intersection`  The hypergraph \(H\) is intersecting. Furthermore, all the edges in its displayed parametrization are distinct. | proposition | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `con-label-action`  Fix a group \(i\). \begin{enumerate} \item A special vertex of group \(i\) covers the positions on one subfield line. A special vertex of a | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `thm:incidence`  There exist absolute constants $\kappa\in(0,1/10)$ and $Q$ with the following property. Suppose that $q\ge Q$ is a prime power and every pr | theorem | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `inc-sumset-estimates`  Let the sets below be finite subsets of an abelian group. \begin{enumerate} \item If $Z$ is nonempty, then \begin{equation} |X-Y|\,|Z|\le | | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `inc-simultaneous-extraction`  Let $F$ be a field, let $A,B\subseteq F^*$ be finite, and let $G\subseteq A\times B$. Define \[ D=\{a-b:(a,b)\in G\},\qquad J=\{a/b:(a,b)\i | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `inc-scalar-coverings`  Let $B$ be a nonempty finite subset of a field $F$, let $E\subseteq B$, and let $K\ge2$. Suppose that \begin{equation} |B-B|\le K|B|, \qqua | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `inc-no-approximate-subfield`  There is no sequence of prime powers $q\to\infty$, each satisfying the proper-subfield hypothesis of Theorem~\ref{thm:incidence}, together  | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `lem:martingale`  Let $Z_i$, $1\leq i\leq n$, be martingale differences for a filtration $(\mathcal A_i)_{i=0}^n$. Suppose that $M,V>0$ and deterministic num | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `lem:linecover`  Let $q\to\infty$ through prime powers for which every proper subfield of $\F_q$ has order at most $q^{1/3}$. Fix a positive integer $D$ and | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `thm:main`  There exists $s_0$ such that, for every prime $s\ge s_0$ with $s\equiv2\pmod3$, there is an integer $n_0(s)\ge3$ with the following propert | theorem | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `cor:tree-cover`  Let $s_0$ and $n_0(s)$ be as in Theorem~\ref{thm:main}. For every prime $s\ge s_0$ with $s\equiv2\pmod3$ and every odd integer $n\ge n_0(s) | corollary | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `thm:selection`  For every positive integer $D$ there is a positive integer $K=K(D)$ with the following property. Let $q$ tend to infinity through prime pow | theorem | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `sel-domination`  Let a finite simple graph have a vertex partition into nonempty parts $A_1,\ldots,A_n$. If there is no independent set containing one verte | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |

Categories: FORMALIZED / FORMALIZED_PARTIAL / PAPER_ONLY (reviewer-confirmed, DRAFT until signed) · NEEDS_HUMAN_REVIEW · UNKNOWN_NOT_REVIEWED · CANNOT_JUDGE (needs a domain expert). Nothing here is inferred automatically.
