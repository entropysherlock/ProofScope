# Coverage report — Backward intertwiners and a transitive commutant

Preprint `Backward-intertwiners-and-a-transitive-commutant-September-27-2026` · commit `4eaee8754825` · 20261108_174138 UTC

Linked challenges: `BackwardIntertwiners` (no verdict)

| Paper statement | Kind | Coverage | Basis |
|---|---|---|---|
| `thm:direct-model`  There are measurable positive weights $\beta_j:X\to(0,\infty)$, $j\in\Z$, and a contraction $V\in\B(H_0)$ with the following properties. Th | theorem | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `cor:direct-algebra`  Every infinite-dimensional separable complex Hilbert space admits a nonzero bounded norm-quasinilpotent operator with no nonzero proper clo | corollary | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `lem:domar`  Let $w=(w_j)_{j\in\Z}$ be positive and decreasing. Suppose that $\log w_j$ is convex for $j\le0$ and concave for $j\ge0$, that \begin{equat | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `lem:drift`  For every $x\in X_*$ there is a finite $C(x)$ such that, for all $n,q\ge1$, \begin{align} \sum_{k=0}^{n-1}\Delta a_k(x)&\ge Dn-C(x),\\ \sum | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `lem:normalization`  For $x\in X_*$, the coefficients $\widetilde b_j(x)$ tend to zero as $j\to+\infty$ and as $j\to-\infty$. Consequently there are measurable  | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `prop:V`  The contraction $V$ commutes with $S$. For every $x\in X_*$ and $h\in\Z$, \[ \overline{V_x\Ktail{h}}=\Ktail{h-1},\qquad \overline{V_xK}=K.  | proposition | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `lem:descent`  Let $\theta$ be an invertible ergodic probability-preserving transformation of $(Y,\nu)$. Suppose a measurable function $s:Y\to\Z\cup\{-\in | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `lem:ergodicity`  The transformation $\theta$ is ergodic. | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `prop:fibers`  For every $x\in X$, the operator $S_xe_j=\beta_j(x)e_{j+1}$ is bounded, has norm $e^{-c}$, and has precisely the standard tails as its clos | proposition | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `prop:normquasi`  The operator $S$ is nonzero and norm-quasinilpotent. More precisely, for all integers $n\ge1$, \[ \|S^n\|\le \exp\left(-c\left\lfloor\frac{ | proposition | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |

Categories: FORMALIZED / FORMALIZED_PARTIAL / PAPER_ONLY (reviewer-confirmed, DRAFT until signed) · NEEDS_HUMAN_REVIEW · UNKNOWN_NOT_REVIEWED · CANNOT_JUDGE (needs a domain expert). Nothing here is inferred automatically.
