# Coverage report — An Artin group with no geometric CAT(0) action

Preprint `An-Artin-group-with-no-geometric-CAT-0-action-September-23-2026` · commit `4eaee8754825` · 20261108_174138 UTC

Linked challenges: `ArtinCAT0` (no verdict)

| Paper statement | Kind | Coverage | Basis |
|---|---|---|---|
| `thm:main`  There is an Artin matrix \(M\) on 116 generators, with every off-diagonal label in \(\{2,3,\infty\}\), such that \(A_M\) admits no geometri | theorem | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `lem:pair-embeddings`  For every $(u,v)\in\mathcal E$, the homomorphism \[ B_3=\langle t_1,t_2\mid t_1t_2t_1=t_2t_1t_2\rangle \longrightarrow T, \qquad t_1\longma | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `lem:amalgam-normal-form`  Let $H_1,H_2$ be groups with a common embedded subgroup $E$, and let $H_1*_E H_2$ be the group obtained by identifying the two copies of $E | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `lem:common-centralizer`  For the elements $d,e$ of $G$, \[ C_G(d)\cap C_G(e)=T. \] | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `lem:geometric-centralizer`  Suppose a group $H$ acts geometrically on a nonempty proper CAT(0) space $X$. For finitely many elements $q_1,\ldots,q_m\in H$, $m\ge1$, se | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `prop:braid-angle`  Suppose a group acting geometrically on a CAT(0) space contains elements $s_1,\ldots,s_{39}$ satisfying the $B_{40}$ relations, with $\ell( | proposition | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `lem:braid-centers`  The element $L_j$ commutes with $s_i$ for $i\le j-2$, and $Z_r$ commutes with every $s_i$ for $i<r$. In particular, \[ Z_2=s_1^2,\qquad Z_3 | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `lem:triangular-presentation`  For each $(u,v)\in\mathcal E$, introduce two private generators $x_{uv}$ and $h_{uv}$. Write $(x_1,x_2,x_3,h)=(u,v,x_{uv},h_{uv})$ within t | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `lem:link-girth`  The link at every vertex of $\mathcal K$ has no circuit of length less than six, including circuits formed by parallel edges. | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `prop:sphere-counts`  For every combinatorial map from a finite triangulated oriented two-sphere to $\mathcal K$, and every individual target triangle $\tau$, th | proposition | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `lem:controlled-diagrams`  Suppose that $T$ acts geometrically on $Y$ and fix $y\in Y$. There is a constant $C_1$, depending only on this action, $y$, and the fixed p | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `lem:comparison`  In a CAT(0) space, geodesic segments are unique and depend continuously on their endpoints. If $\alpha,\beta:[0,1]\to X$ are geodesics para | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `lem:semisimple`  Suppose $G$ acts geometrically on $X$. Every $g\in G$ attains its minimum displacement, and \[ \ell(g)=\min_{x\in X}d(x,gx). \] If this num | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `lem:commuting-form`  For pairwise commuting isometries $g_1,\ldots,g_k$ of a CAT(0) space, the function \[ v\longmapsto \ell(g^v),\qquad g^v=g_1^{v_1}\cdots g_k | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `lem:centralizer-character`  For a geometric action and a fixed $g\in G$, the function \[ C_G(g)\longrightarrow\mathbb R,\qquad h\longmapsto\langle g,h\rangle \] is a g | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `lem:projected-approximation`  On \(B\), the maps \(q_n\) converge uniformly to \(\kappa\). | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `lem:localized-degree`  For all sufficiently large \(n\), every occurrence in the sphere diagram of a target triangle contributing to the winding count on \(B\) li | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `prop:triangle-obstruction`  There is no geometric action of \(T\) such that, for every \((u,v)\in\mathcal E\), \begin{equation} \frac{\ell(z_{uv})}{3\ell(u^2)} =\frac{ | proposition | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `lem:orbit-control`  For a geometric action of \(T\) and any base point \(y\), there are constants \(R,C<\infty\) such that \(Ty\) is \(R\)-dense and \begin{equ | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `lem:mirror-action`  The formulas \[ u\cdot\xi=e_{D_u}+r_u\xi\qquad(u=a,b,c) \] define an affine isometric action of \(T\) on \(E\). If \(V(t)=t\cdot0\), then \ | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `lem:sector-data`  Each of these six seminorms is positive definite. Each sector angle \(\theta\) satisfies \(0<\theta<\pi/3\). The sectors glue isometrically | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `lem:sector-maps`  There are continuous maps \(f_n:P\to Y\), with \(f_n(0)=y\), and a constant \(C_0\) independent of \(n,p\), such that \begin{equation} d_Y( | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `lem:outer-cap`  There is \(\epsilon>0\) such that, for all sufficiently large \(n\), the map \(f_n|_{\partial P}\) extends to a second parameter disk whose | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |

Categories: FORMALIZED / FORMALIZED_PARTIAL / PAPER_ONLY (reviewer-confirmed, DRAFT until signed) · NEEDS_HUMAN_REVIEW · UNKNOWN_NOT_REVIEWED · CANNOT_JUDGE (needs a domain expert). Nothing here is inferred automatically.
