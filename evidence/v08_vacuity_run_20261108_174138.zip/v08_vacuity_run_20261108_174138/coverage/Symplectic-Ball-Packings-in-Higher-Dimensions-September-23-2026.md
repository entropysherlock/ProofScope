# Coverage report — Symplectic Ball Packings in Higher Dimensions

Preprint `Symplectic-Ball-Packings-in-Higher-Dimensions-September-23-2026` · commit `4eaee8754825` · 20261108_174138 UTC

Linked challenges: `BallPacking` (no verdict), `BallPackingNecessity` (no verdict)

| Paper statement | Kind | Coverage | Basis |
|---|---|---|---|
| `intro:main`  Let \(n\ge3\) and \(k\ge1\) be integers. For positive real numbers \(R,R_1,\ldots,R_k\), there exists a symplectic embedding \[ \bigsqcup_{ | theorem | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `app:quadrics`  Let $N\ge3$, and let $F\subset\PP^N$ be a hyperplane. There is a smooth connected curve $C$, the complete intersection of $N-1$ quadrics, t | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `app:small`  Let $n\ge3$, and let $\rho_1,\ldots,\rho_k$ be positive real numbers with \[ \rho_i<\tfrac12\quad(1\le i\le k),\qquad \sum_{i=1}^k\rho_i^n< | proposition | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `app:large`  Let $n\ge4$, let $A\ge1/2$, and let $\rho_1,\ldots,\rho_k>0$ satisfy \[ A^n+\sum_i\rho_i^n<1,\qquad A+\rho_i<1\quad(1\le i\le k). \] Then t | proposition | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `cmp:comparison`  Let \(P:\Delta\to\R\) be continuous and concave. Suppose that its Lebesgue mean \(\overline P\) is positive and, for some \(0<\tau<1\), \be | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `cmp:rearrangement-properties`  Each \(R_j\) maps continuous convex functions on \(\Delta\) to continuous convex functions. It preserves Lebesgue integrals, order, and add | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `cmp:lifted`  For every continuous convex \(F:\Delta\to\R\), every coordinate \(j\), and every \(\eps>0\), there is a Hamiltonian diffeomorphism \(q_j:V\ | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `cmp:planar-disks`  Let \(Y\) be a compact convex subset of a Euclidean space, let \(0<a_1<\cdots<a_l<A\), and let \[ E_1(y)\Subset\Int E_2(y)\Subset\cdots \Su | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `cmp:disk-realization`  Let \(f_y:[0,1]\to\R\) be a jointly continuous family of convex functions, with \(y\) in a compact convex parameter set. Let \(g_y\) be the | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `geo:relative-moser`  Let \(X\) be a compact complex manifold and let \(\omega_0,\omega_1\) be cohomologous K\"ahler forms. Let \(S_1,\ldots,S_e\) be pairwise di | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `geo:projective-transfer`  Let \(f:\mathcal X\to B\) be a flat projective family over a smooth algebraic curve over \(\C\), with a marked point \(0\), and let \(\math | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `geo:transfer`  Let \(T\) be a smooth projective manifold, \(Z\subset T\) a smooth closed submanifold of positive codimension, possibly disconnected, and \ | proposition | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `geo:bundle`  Let \(A\) be an ample line bundle on a smooth projective manifold \(Z\), equipped with a Hermitian metric of Chern form \(\sigma>0\). Suppo | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `geo:shell`  Let \(n\ge2\), let \(o\in\PP^n\setminus H_\infty\), and write \[ T=\Bl_o\PP^n,\qquad H=\pi^*c_1(\cO_{\PP^n}(1)). \] Let \(E\) be the except | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `six:quadric`  There is an identification \(D=\Bl_{q_1,q_2}\PP^2\), for two distinct points \(q_1,q_2\). Write \(M\) for the pullback of the plane hyperpl | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `six:cut`  Suppose \(s<d_1<b\) and \(\widehat V\) has an invariant Kähler form in the class \begin{equation} A=3bM+d_1U_1-s(\widehat E_1+\widehat E_2) | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `six:cubic-ampleness`  Both classes in \eqref{six:component-classes} are ample. Consequently \(\mathcal A\) is relatively ample near zero. | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `six:weights`  For the above full projective system, the weight \((k_1,k_2)\) runs over \[ 0\le k_1\le Nd_1,\qquad 0\le k_2\le Nd_2-k_1. \] Its coefficien | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `six:toric-model`  Let \(\Delta\) be a compact downward polytope strictly below the two upper boundaries of \(\mathcal Q\), and let \[ C^\circ=C\setminus\{q_1 | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `six:moment-transfer`  Let \(\Sigma\) be a connected compact bordered surface in the unmarked base, and let \(K\) be the entire compact moment region over \(\Sigm | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `six:large`  Let \(R_0,R_1,\ldots,R_k>0\), with \(R_0\ge1/2\), satisfy \[ \sum_{i=0}^k R_i^3<1,\qquad R_i+R_j<1\quad(i\ne j). \] Then the disjoint union | proposition | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `surf:primitive`  Let $\Sigma$ be a compact connected oriented surface with nonempty boundary. A smooth family $\eta_p$ of two-forms, supported in a fixed co | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `surf:moser`  Let $\Sigma$ be a compact connected oriented surface with nonempty boundary. Let $\Omega_\lambda$, $0\leq\lambda\leq1$, be a smooth family  | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `surf:packing`  Let $C^o$ be an oriented surface obtained from a closed connected surface of genus at least one by removing finitely many, but at least one | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |

Categories: FORMALIZED / FORMALIZED_PARTIAL / PAPER_ONLY (reviewer-confirmed, DRAFT until signed) · NEEDS_HUMAN_REVIEW · UNKNOWN_NOT_REVIEWED · CANNOT_JUDGE (needs a domain expert). Nothing here is inferred automatically.
