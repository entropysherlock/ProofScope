# Coverage report — Asymptotically minimal maxima of real Littlewood polynomials

Preprint `Asymptotically-minimal-maxima-of-real-Littlewood-polynomials-September-23-2026` · commit `4eaee8754825` · 20261108_174138 UTC

Linked challenges: `AsymptoticallyMinimalLittlewood` (no verdict)

| Paper statement | Kind | Coverage | Basis |
|---|---|---|---|
| `thm:main`  For Littlewood polynomials with real coefficients, \[ \lim_{N\to\infty}m_N=1. \] Equivalently, for every $\eta>0$ there is $N_0$ such that  | theorem | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `cor:finite-flatness`  There are Littlewood polynomials $P_N$ of every length $N$ such that, for each fixed $0<p<\infty$, \[ \int_{\T}\left|\frac{|P_N(\e(t))|}{\s | corollary | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `cor:merit`  For $N\ge2$, let \[ \mathcal F_N=\max_{A\in\{-1,1\}^N}F(A). \] Then \[ \lim_{N\to\infty}\mathcal F_N=+\infty, \] where the limit runs throu | corollary | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `cor:morse`  There is a binary Morse shift $(X,S)$ with a unique $S$-invariant Borel probability measure $\mu$ for which the Koopman operator $U_Sg=g\ci | corollary | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `lem:signed-packing`  Let $m\ge1$ and $r\ge2$ be integers, and let $a_1,\ldots,a_r\in\Z^m\setminus\{0\}$ be pairwise nonparallel. If $w_1,\ldots,w_r>0$ satisfy $ | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `thm:packing-edge-coloring`  For each integer $r\ge2$ and each $\gamma>0$, there exists $\beta>0$ with the following property. If an $r$-uniform hypergraph satisfies, f | theorem | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `prop:almost-signs`  For every $0<\delta<1/20$, there are vectors $X_N=(X_{N,0},\ldots,X_{N,N-1})\in[-1,1]^N$, one for each integer $N\ge1$, such that \begin{al | proposition | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `lem:rounding`  There is an absolute constant $C$ such that for every $N\ge1$ and every $X\in[-1,1]^N$, some signs $\varepsilon_0,\ldots,\varepsilon_{N-1}$ | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `lem:rounding-matrix`  There is an absolute constant $C_0$ such that, for integers $1\le s\le R$ and a real matrix $B\in[-1,1]^{R\times s}$, there is a vector $\x | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `lem:sampling-poisson`  Let $\chi\in C_c^\infty(\R)$, let $x_*\in\R$ and $\lambda\in\R\setminus\{0\}$, and let $J\subset\R$ be compact. For $b\in J$ and $\ell\in\Z | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `prop:auxiliary`  For every $0<\delta<1/20$, there exist integers $m\ge1$ and $r\ge2$, nonzero vectors $a_1,\ldots,a_r\in\Z^m$, a real-valued trigonometric p | proposition | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |
| `lem:quadratic`  Let $g\in C_c^\infty(\R)$ and let $\beta\in\R\setminus\{0\}$ be fixed. As $T\to\infty$ through positive real values, \begin{equation}  \beg | lemma | **NEEDS_HUMAN_REVIEW** | a matched challenge exists but no reviewer verdict yet |

Categories: FORMALIZED / FORMALIZED_PARTIAL / PAPER_ONLY (reviewer-confirmed, DRAFT until signed) · NEEDS_HUMAN_REVIEW · UNKNOWN_NOT_REVIEWED · CANNOT_JUDGE (needs a domain expert). Nothing here is inferred automatically.
