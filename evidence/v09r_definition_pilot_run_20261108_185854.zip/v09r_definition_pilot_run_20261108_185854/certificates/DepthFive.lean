import WestfallSep
import Mathlib

namespace OAI

noncomputable section

open scoped BigOperators
universe u

namespace Problem335

inductive D5Leaf (K : Type u) (n : ℕ) where
  | scalar : K → D5Leaf K n
  | variable : (Fin n × Fin n × Fin n) → D5Leaf K n

def d5LeafDegree {K : Type u} {n : ℕ} : D5Leaf K n → ℕ
  | D5Leaf.scalar _ => 0
  | D5Leaf.variable _ => 1

structure Depth5Circuit (K : Type u) [CommSemiring K] (n : ℕ) where
  leafCount : ℕ
  leaves : Fin leafCount → D5Leaf K n
  bottomCount : ℕ
  bottomInputs : Fin bottomCount → List (K × Fin leafCount)
  bottomDegree : Fin bottomCount → ℕ
  bottomHomogeneous :
    ∀ i entry, entry ∈ bottomInputs i → d5LeafDegree (leaves entry.2) = bottomDegree i
  bottomEmpty :
    ∀ i, bottomInputs i = [] → bottomDegree i = 0
  lowerCount : ℕ
  lowerInputs : Fin lowerCount → List (Fin bottomCount)
  middleCount : ℕ
  middleInputs : Fin middleCount → List (K × Fin lowerCount)
  middleDegree : Fin middleCount → ℕ
  middleHomogeneous :
    ∀ i entry, entry ∈ middleInputs i →
      ((lowerInputs entry.2).map bottomDegree).sum = middleDegree i
  middleEmpty :
    ∀ i, middleInputs i = [] → middleDegree i = 0
  upperCount : ℕ
  upperInputs : Fin upperCount → List (Fin middleCount)
  outputInputs : List (K × Fin upperCount)
  outputDegree : ℕ
  outputHomogeneous :
    ∀ entry, entry ∈ outputInputs →
      ((upperInputs entry.2).map middleDegree).sum = outputDegree
  outputEmpty :
    outputInputs = [] → outputDegree = 0

def d5LeafValue {K : Type u} [CommSemiring K] {n : ℕ}
    (x : D5Leaf K n) : MvPolynomial (Fin n × Fin n × Fin n) K :=
  match x with
  | D5Leaf.scalar a => MvPolynomial.C a
  | D5Leaf.variable i => MvPolynomial.X i

def bottomValue {K : Type u} [CommSemiring K] {n : ℕ}
    (c : Depth5Circuit K n) (i : Fin c.bottomCount) :
    MvPolynomial (Fin n × Fin n × Fin n) K := by
  classical
  exact ((c.bottomInputs i).map (fun entry =>
    MvPolynomial.C entry.1 * d5LeafValue (c.leaves entry.2))).sum

def lowerValue {K : Type u} [CommSemiring K] {n : ℕ}
    (c : Depth5Circuit K n) (i : Fin c.lowerCount) :
    MvPolynomial (Fin n × Fin n × Fin n) K := by
  classical
  exact ((c.lowerInputs i).map (fun j => bottomValue c j)).prod

def middleValue {K : Type u} [CommSemiring K] {n : ℕ}
    (c : Depth5Circuit K n) (i : Fin c.middleCount) :
    MvPolynomial (Fin n × Fin n × Fin n) K := by
  classical
  exact ((c.middleInputs i).map (fun entry =>
    MvPolynomial.C entry.1 * lowerValue c entry.2)).sum

def upperValue {K : Type u} [CommSemiring K] {n : ℕ}
    (c : Depth5Circuit K n) (i : Fin c.upperCount) :
    MvPolynomial (Fin n × Fin n × Fin n) K := by
  classical
  exact ((c.upperInputs i).map (fun j => middleValue c j)).prod

def circuitValue {K : Type u} [CommSemiring K] {n : ℕ}
    (c : Depth5Circuit K n) : MvPolynomial (Fin n × Fin n × Fin n) K := by
  classical
  exact (c.outputInputs.map (fun entry =>
    MvPolynomial.C entry.1 * upperValue c entry.2)).sum

def circuitSize {K : Type u} [CommSemiring K] {n : ℕ}
    (c : Depth5Circuit K n) : ℕ :=
  c.leafCount + c.bottomCount + c.lowerCount + c.middleCount + c.upperCount + 1

def immLayer (K : Type u) [CommSemiring K] (n : ℕ) (t : Fin n) :
    Matrix (Fin n) (Fin n) (MvPolynomial (Fin n × Fin n × Fin n) K) :=
  fun i j => MvPolynomial.X (t, i, j)

def imm (K : Type u) [CommSemiring K] (n : ℕ) :
    MvPolynomial (Fin n × Fin n × Fin n) K := by
  classical
  by_cases h : 0 < n
  · let matrices :
        List (Matrix (Fin n) (Fin n)
          (MvPolynomial (Fin n × Fin n × Fin n) K)) :=
      List.ofFn (fun t : Fin n => immLayer K n t)
    exact matrices.prod ⟨0, h⟩ ⟨0, h⟩
  · exact 0

def ceilSqrt (n : ℕ) : ℕ :=
  Nat.sqrt n + if (Nat.sqrt n) ^ 2 = n then 0 else 1

def ceilDiv (n t : ℕ) : ℕ :=
  (n + t - 1) / t

def upperGateBound (n : ℕ) : ℕ :=
  let t := ceilSqrt n
  let r := ceilDiv n t
  2 * n ^ 3 + r * n ^ 2 + r * n ^ (t + 1) + n ^ (r - 1) + 1

theorem main :
    (∃ threshold : ℕ, ∀ size : ℕ, threshold ≤ size →
      ∀ circuit : Depth5Circuit ℂ size, circuitValue circuit = imm ℂ size →
        (size : ℝ) ^ (Real.sqrt (size : ℝ) / 400) ≤ (circuitSize circuit : ℝ)) ∧
    (∃ threshold : ℕ, ∀ (FieldType : Type u) [Field FieldType] [CharZero FieldType],
      ∀ size : ℕ, threshold ≤ size → ∀ circuit : Depth5Circuit FieldType size,
        circuitValue circuit = imm FieldType size →
          (size : ℝ) ^ (Real.sqrt (size : ℝ) / 400) ≤ (circuitSize circuit : ℝ)) ∧
    (∀ (FieldType : Type u) [Field FieldType] (size : ℕ), 2 ≤ size →
      ∃ circuit : Depth5Circuit FieldType size, circuitValue circuit = imm FieldType size ∧
        circuitSize circuit ≤ upperGateBound size ∧
        (upperGateBound size : ℝ) ≤ (size : ℝ) ^ (Real.sqrt (size : ℝ) + 4)) := by
  sorry

end Problem335

end

end OAI


-- WESTFALL V0.9-R obligations (appended; the source above is unmodified)
#westfall_obl "R1a_ceilDiv_vs_Mathlib_ceilDiv" "equal_all" "intro n t; rfl ;; intro n t; exact (Nat.ceilDiv_eq_add_pred_div n t).symm ;; intro n t; rw [Nat.ceilDiv_eq_add_pred_div]; rfl ;; intro n t; simp [Nat.ceilDiv_eq_add_pred_div, OAI.Problem335.ceilDiv]" (∀ (n t : ℕ), ((OAI.Problem335.ceilDiv n t) = (CeilDiv.ceilDiv n t)))
#westfall_obl "R1a_ceilDiv_vs_Mathlib_ceilDiv" "agree_domain" "exact fun n t h => (by decide +kernel : ∀ n, n < 80 → ∀ t, t < 10 → 2 ≤ n ∧ t = OAI.Problem335.ceilSqrt n → ((OAI.Problem335.ceilDiv n t) = (CeilDiv.ceilDiv n t))) n (by omega) t (by omega) h" (∀ (n t : ℕ), 2 ≤ n ∧ t = OAI.Problem335.ceilSqrt n → ((OAI.Problem335.ceilDiv n t) = (CeilDiv.ceilDiv n t)))
#westfall_obl "R1a_ceilDiv_vs_Mathlib_ceilDiv" "witness_all" "" (∃ (n t : ℕ), ¬ ((OAI.Problem335.ceilDiv n t) = (CeilDiv.ceilDiv n t)))
#westfall_obl "R1a_ceilDiv_vs_Mathlib_ceilDiv" "witness_domain" "" (∃ (n t : ℕ), (2 ≤ n ∧ t = OAI.Problem335.ceilSqrt n) ∧ ¬ ((OAI.Problem335.ceilDiv n t) = (CeilDiv.ceilDiv n t)))
#westfall_obl "R1a_ceilDiv_vs_Mathlib_ceilDiv" "agree_domain_bounded" "" (∀ n, n < 80 → ∀ t, t < 10 → 2 ≤ n ∧ t = OAI.Problem335.ceilSqrt n → ((OAI.Problem335.ceilDiv n t) = (CeilDiv.ceilDiv n t)))
#westfall_obl "R1a_ceilDiv_vs_Mathlib_ceilDiv" "witness_all_bounded" "" (∃ n, n < 80 ∧ ∃ t, t < 10 ∧ ¬ ((OAI.Problem335.ceilDiv n t) = (CeilDiv.ceilDiv n t)))
#westfall_obl "R1a_ceilDiv_vs_Mathlib_ceilDiv" "witness_domain_bounded" "" (∃ n, n < 80 ∧ ∃ t, t < 10 ∧ (2 ≤ n ∧ t = OAI.Problem335.ceilSqrt n) ∧ ¬ ((OAI.Problem335.ceilDiv n t) = (CeilDiv.ceilDiv n t)))
#westfall_baseline "R1a_ceilDiv_vs_Mathlib_ceilDiv" "agree_domain" (∀ (n t : ℕ), 2 ≤ n ∧ t = OAI.Problem335.ceilSqrt n → ((OAI.Problem335.ceilDiv n t) = (CeilDiv.ceilDiv n t)))
#westfall_baseline "R1a_ceilDiv_vs_Mathlib_ceilDiv" "equal_all" (∀ (n t : ℕ), ((OAI.Problem335.ceilDiv n t) = (CeilDiv.ceilDiv n t)))
#westfall_obl "R1b_ceilDiv_vs_textbook_formula" "equal_all" "" (∀ (n t : ℕ), ((OAI.Problem335.ceilDiv n t) = (n / t + (if n % t = 0 then 0 else 1))))
#westfall_obl "R1b_ceilDiv_vs_textbook_formula" "agree_domain" "intro n t ⟨hn, ht⟩
have tpos : 0 < t := by
  subst ht; unfold OAI.Problem335.ceilSqrt
  rcases Nat.eq_zero_or_pos (Nat.sqrt n) with h | h
  · rw [h]; split <;> simp_all <;> omega
  · omega
have key : ∀ n t : Nat, 0 < t → (n + t - 1) / t = n / t + (if n % t = 0 then 0 else 1) := by
  intro n t ht
  have hdm := Nat.div_add_mod n t
  have hlt := Nat.mod_lt n ht
  split
  · rename_i h0
    have e : n + t - 1 = (t - 1) + t * (n / t) := by omega
    rw [e, Nat.add_mul_div_left _ _ ht, Nat.div_eq_of_lt (by omega)]; omega
  · rename_i h0
    have e : n + t - 1 = (n % t - 1) + t * (n / t + 1) := by rw [Nat.mul_add]; omega
    rw [e, Nat.add_mul_div_left _ _ ht, Nat.div_eq_of_lt (by omega)]; omega
exact key n t tpos ;; exact fun n t h => (by decide +kernel : ∀ n, n < 80 → ∀ t, t < 10 → 2 ≤ n ∧ t = OAI.Problem335.ceilSqrt n → ((OAI.Problem335.ceilDiv n t) = (n / t + (if n % t = 0 then 0 else 1)))) n (by omega) t (by omega) h" (∀ (n t : ℕ), 2 ≤ n ∧ t = OAI.Problem335.ceilSqrt n → ((OAI.Problem335.ceilDiv n t) = (n / t + (if n % t = 0 then 0 else 1))))
#westfall_obl "R1b_ceilDiv_vs_textbook_formula" "witness_all" "" (∃ (n t : ℕ), ¬ ((OAI.Problem335.ceilDiv n t) = (n / t + (if n % t = 0 then 0 else 1))))
#westfall_obl "R1b_ceilDiv_vs_textbook_formula" "witness_domain" "" (∃ (n t : ℕ), (2 ≤ n ∧ t = OAI.Problem335.ceilSqrt n) ∧ ¬ ((OAI.Problem335.ceilDiv n t) = (n / t + (if n % t = 0 then 0 else 1))))
#westfall_obl "R1b_ceilDiv_vs_textbook_formula" "agree_domain_bounded" "" (∀ n, n < 80 → ∀ t, t < 10 → 2 ≤ n ∧ t = OAI.Problem335.ceilSqrt n → ((OAI.Problem335.ceilDiv n t) = (n / t + (if n % t = 0 then 0 else 1))))
#westfall_obl "R1b_ceilDiv_vs_textbook_formula" "witness_all_bounded" "" (∃ n, n < 80 ∧ ∃ t, t < 10 ∧ ¬ ((OAI.Problem335.ceilDiv n t) = (n / t + (if n % t = 0 then 0 else 1))))
#westfall_obl "R1b_ceilDiv_vs_textbook_formula" "witness_domain_bounded" "" (∃ n, n < 80 ∧ ∃ t, t < 10 ∧ (2 ≤ n ∧ t = OAI.Problem335.ceilSqrt n) ∧ ¬ ((OAI.Problem335.ceilDiv n t) = (n / t + (if n % t = 0 then 0 else 1))))
#westfall_baseline "R1b_ceilDiv_vs_textbook_formula" "agree_domain" (∀ (n t : ℕ), 2 ≤ n ∧ t = OAI.Problem335.ceilSqrt n → ((OAI.Problem335.ceilDiv n t) = (n / t + (if n % t = 0 then 0 else 1))))
#westfall_baseline "R1b_ceilDiv_vs_textbook_formula" "equal_all" (∀ (n t : ℕ), ((OAI.Problem335.ceilDiv n t) = (n / t + (if n % t = 0 then 0 else 1))))
#westfall_obl "R2_ceilSqrt_vs_least_k_spec" "equal_all" "" (∀ (n k : ℕ), ((OAI.Problem335.ceilSqrt n = k) ↔ (n ≤ k ^ 2 ∧ ∀ j, j < k → j ^ 2 < n)))
#westfall_obl "R2_ceilSqrt_vs_least_k_spec" "agree_domain" "exact fun n k h => (by decide +kernel : ∀ n, n < 120 → ∀ k, k < 13 → 2 ≤ n → ((OAI.Problem335.ceilSqrt n = k) ↔ (n ≤ k ^ 2 ∧ ∀ j, j < k → j ^ 2 < n))) n (by omega) k (by omega) h" (∀ (n k : ℕ), 2 ≤ n → ((OAI.Problem335.ceilSqrt n = k) ↔ (n ≤ k ^ 2 ∧ ∀ j, j < k → j ^ 2 < n)))
#westfall_obl "R2_ceilSqrt_vs_least_k_spec" "witness_all" "" (∃ (n k : ℕ), ¬ ((OAI.Problem335.ceilSqrt n = k) ↔ (n ≤ k ^ 2 ∧ ∀ j, j < k → j ^ 2 < n)))
#westfall_obl "R2_ceilSqrt_vs_least_k_spec" "witness_domain" "" (∃ (n k : ℕ), (2 ≤ n) ∧ ¬ ((OAI.Problem335.ceilSqrt n = k) ↔ (n ≤ k ^ 2 ∧ ∀ j, j < k → j ^ 2 < n)))
#westfall_obl "R2_ceilSqrt_vs_least_k_spec" "agree_domain_bounded" "" (∀ n, n < 120 → ∀ k, k < 13 → 2 ≤ n → ((OAI.Problem335.ceilSqrt n = k) ↔ (n ≤ k ^ 2 ∧ ∀ j, j < k → j ^ 2 < n)))
#westfall_obl "R2_ceilSqrt_vs_least_k_spec" "witness_all_bounded" "" (∃ n, n < 120 ∧ ∃ k, k < 13 ∧ ¬ ((OAI.Problem335.ceilSqrt n = k) ↔ (n ≤ k ^ 2 ∧ ∀ j, j < k → j ^ 2 < n)))
#westfall_obl "R2_ceilSqrt_vs_least_k_spec" "witness_domain_bounded" "" (∃ n, n < 120 ∧ ∃ k, k < 13 ∧ (2 ≤ n) ∧ ¬ ((OAI.Problem335.ceilSqrt n = k) ↔ (n ≤ k ^ 2 ∧ ∀ j, j < k → j ^ 2 < n)))
#westfall_baseline "R2_ceilSqrt_vs_least_k_spec" "agree_domain" (∀ (n k : ℕ), 2 ≤ n → ((OAI.Problem335.ceilSqrt n = k) ↔ (n ≤ k ^ 2 ∧ ∀ j, j < k → j ^ 2 < n)))
#westfall_baseline "R2_ceilSqrt_vs_least_k_spec" "equal_all" (∀ (n k : ℕ), ((OAI.Problem335.ceilSqrt n = k) ↔ (n ≤ k ^ 2 ∧ ∀ j, j < k → j ^ 2 < n)))
#westfall_obl "M1_ceilDiv_drops_minus_one" "equal_all" "" (∀ (n t : ℕ), (((n + t) / t) = (OAI.Problem335.ceilDiv n t)))
#westfall_obl "M1_ceilDiv_drops_minus_one" "agree_domain" "exact fun n t h => (by decide +kernel : ∀ n, n < 40 → ∀ t, t < 8 → 2 ≤ n ∧ t = OAI.Problem335.ceilSqrt n → (((n + t) / t) = (OAI.Problem335.ceilDiv n t))) n (by omega) t (by omega) h" (∀ (n t : ℕ), 2 ≤ n ∧ t = OAI.Problem335.ceilSqrt n → (((n + t) / t) = (OAI.Problem335.ceilDiv n t)))
#westfall_obl "M1_ceilDiv_drops_minus_one" "witness_all" "" (∃ (n t : ℕ), ¬ (((n + t) / t) = (OAI.Problem335.ceilDiv n t)))
#westfall_obl "M1_ceilDiv_drops_minus_one" "witness_domain" "" (∃ (n t : ℕ), (2 ≤ n ∧ t = OAI.Problem335.ceilSqrt n) ∧ ¬ (((n + t) / t) = (OAI.Problem335.ceilDiv n t)))
#westfall_obl "M1_ceilDiv_drops_minus_one" "agree_domain_bounded" "" (∀ n, n < 40 → ∀ t, t < 8 → 2 ≤ n ∧ t = OAI.Problem335.ceilSqrt n → (((n + t) / t) = (OAI.Problem335.ceilDiv n t)))
#westfall_obl "M1_ceilDiv_drops_minus_one" "witness_all_bounded" "" (∃ n, n < 40 ∧ ∃ t, t < 8 ∧ ¬ (((n + t) / t) = (OAI.Problem335.ceilDiv n t)))
#westfall_obl "M1_ceilDiv_drops_minus_one" "witness_domain_bounded" "" (∃ n, n < 40 ∧ ∃ t, t < 8 ∧ (2 ≤ n ∧ t = OAI.Problem335.ceilSqrt n) ∧ ¬ (((n + t) / t) = (OAI.Problem335.ceilDiv n t)))
#westfall_baseline "M1_ceilDiv_drops_minus_one" "agree_domain" (∀ (n t : ℕ), 2 ≤ n ∧ t = OAI.Problem335.ceilSqrt n → (((n + t) / t) = (OAI.Problem335.ceilDiv n t)))
#westfall_baseline "M1_ceilDiv_drops_minus_one" "equal_all" (∀ (n t : ℕ), (((n + t) / t) = (OAI.Problem335.ceilDiv n t)))
#westfall_obl "M2_ceilDiv_becomes_floor" "equal_all" "" (∀ (n t : ℕ), ((n / t) = (OAI.Problem335.ceilDiv n t)))
#westfall_obl "M2_ceilDiv_becomes_floor" "agree_domain" "exact fun n t h => (by decide +kernel : ∀ n, n < 40 → ∀ t, t < 8 → 2 ≤ n ∧ t = OAI.Problem335.ceilSqrt n → ((n / t) = (OAI.Problem335.ceilDiv n t))) n (by omega) t (by omega) h" (∀ (n t : ℕ), 2 ≤ n ∧ t = OAI.Problem335.ceilSqrt n → ((n / t) = (OAI.Problem335.ceilDiv n t)))
#westfall_obl "M2_ceilDiv_becomes_floor" "witness_all" "" (∃ (n t : ℕ), ¬ ((n / t) = (OAI.Problem335.ceilDiv n t)))
#westfall_obl "M2_ceilDiv_becomes_floor" "witness_domain" "" (∃ (n t : ℕ), (2 ≤ n ∧ t = OAI.Problem335.ceilSqrt n) ∧ ¬ ((n / t) = (OAI.Problem335.ceilDiv n t)))
#westfall_obl "M2_ceilDiv_becomes_floor" "agree_domain_bounded" "" (∀ n, n < 40 → ∀ t, t < 8 → 2 ≤ n ∧ t = OAI.Problem335.ceilSqrt n → ((n / t) = (OAI.Problem335.ceilDiv n t)))
#westfall_obl "M2_ceilDiv_becomes_floor" "witness_all_bounded" "" (∃ n, n < 40 ∧ ∃ t, t < 8 ∧ ¬ ((n / t) = (OAI.Problem335.ceilDiv n t)))
#westfall_obl "M2_ceilDiv_becomes_floor" "witness_domain_bounded" "" (∃ n, n < 40 ∧ ∃ t, t < 8 ∧ (2 ≤ n ∧ t = OAI.Problem335.ceilSqrt n) ∧ ¬ ((n / t) = (OAI.Problem335.ceilDiv n t)))
#westfall_baseline "M2_ceilDiv_becomes_floor" "agree_domain" (∀ (n t : ℕ), 2 ≤ n ∧ t = OAI.Problem335.ceilSqrt n → ((n / t) = (OAI.Problem335.ceilDiv n t)))
#westfall_baseline "M2_ceilDiv_becomes_floor" "equal_all" (∀ (n t : ℕ), ((n / t) = (OAI.Problem335.ceilDiv n t)))
#westfall_obl "M3_ceilSqrt_becomes_floor_sqrt" "equal_all" "" (∀ (n : ℕ), ((Nat.sqrt n) = (OAI.Problem335.ceilSqrt n)))
#westfall_obl "M3_ceilSqrt_becomes_floor_sqrt" "agree_domain" "exact fun n h => (by decide +kernel : ∀ n, n < 40 → 2 ≤ n → ((Nat.sqrt n) = (OAI.Problem335.ceilSqrt n))) n (by omega) h" (∀ (n : ℕ), 2 ≤ n → ((Nat.sqrt n) = (OAI.Problem335.ceilSqrt n)))
#westfall_obl "M3_ceilSqrt_becomes_floor_sqrt" "witness_all" "" (∃ (n : ℕ), ¬ ((Nat.sqrt n) = (OAI.Problem335.ceilSqrt n)))
#westfall_obl "M3_ceilSqrt_becomes_floor_sqrt" "witness_domain" "" (∃ (n : ℕ), (2 ≤ n) ∧ ¬ ((Nat.sqrt n) = (OAI.Problem335.ceilSqrt n)))
#westfall_obl "M3_ceilSqrt_becomes_floor_sqrt" "agree_domain_bounded" "" (∀ n, n < 40 → 2 ≤ n → ((Nat.sqrt n) = (OAI.Problem335.ceilSqrt n)))
#westfall_obl "M3_ceilSqrt_becomes_floor_sqrt" "witness_all_bounded" "" (∃ n, n < 40 ∧ ¬ ((Nat.sqrt n) = (OAI.Problem335.ceilSqrt n)))
#westfall_obl "M3_ceilSqrt_becomes_floor_sqrt" "witness_domain_bounded" "" (∃ n, n < 40 ∧ (2 ≤ n) ∧ ¬ ((Nat.sqrt n) = (OAI.Problem335.ceilSqrt n)))
#westfall_baseline "M3_ceilSqrt_becomes_floor_sqrt" "agree_domain" (∀ (n : ℕ), 2 ≤ n → ((Nat.sqrt n) = (OAI.Problem335.ceilSqrt n)))
#westfall_baseline "M3_ceilSqrt_becomes_floor_sqrt" "equal_all" (∀ (n : ℕ), ((Nat.sqrt n) = (OAI.Problem335.ceilSqrt n)))
#westfall_obl "M4_ceilSqrt_always_rounds_up" "equal_all" "" (∀ (n : ℕ), ((Nat.sqrt n + 1) = (OAI.Problem335.ceilSqrt n)))
#westfall_obl "M4_ceilSqrt_always_rounds_up" "agree_domain" "exact fun n h => (by decide +kernel : ∀ n, n < 40 → 2 ≤ n → ((Nat.sqrt n + 1) = (OAI.Problem335.ceilSqrt n))) n (by omega) h" (∀ (n : ℕ), 2 ≤ n → ((Nat.sqrt n + 1) = (OAI.Problem335.ceilSqrt n)))
#westfall_obl "M4_ceilSqrt_always_rounds_up" "witness_all" "" (∃ (n : ℕ), ¬ ((Nat.sqrt n + 1) = (OAI.Problem335.ceilSqrt n)))
#westfall_obl "M4_ceilSqrt_always_rounds_up" "witness_domain" "" (∃ (n : ℕ), (2 ≤ n) ∧ ¬ ((Nat.sqrt n + 1) = (OAI.Problem335.ceilSqrt n)))
#westfall_obl "M4_ceilSqrt_always_rounds_up" "agree_domain_bounded" "" (∀ n, n < 40 → 2 ≤ n → ((Nat.sqrt n + 1) = (OAI.Problem335.ceilSqrt n)))
#westfall_obl "M4_ceilSqrt_always_rounds_up" "witness_all_bounded" "" (∃ n, n < 40 ∧ ¬ ((Nat.sqrt n + 1) = (OAI.Problem335.ceilSqrt n)))
#westfall_obl "M4_ceilSqrt_always_rounds_up" "witness_domain_bounded" "" (∃ n, n < 40 ∧ (2 ≤ n) ∧ ¬ ((Nat.sqrt n + 1) = (OAI.Problem335.ceilSqrt n)))
#westfall_baseline "M4_ceilSqrt_always_rounds_up" "agree_domain" (∀ (n : ℕ), 2 ≤ n → ((Nat.sqrt n + 1) = (OAI.Problem335.ceilSqrt n)))
#westfall_baseline "M4_ceilSqrt_always_rounds_up" "equal_all" (∀ (n : ℕ), ((Nat.sqrt n + 1) = (OAI.Problem335.ceilSqrt n)))
