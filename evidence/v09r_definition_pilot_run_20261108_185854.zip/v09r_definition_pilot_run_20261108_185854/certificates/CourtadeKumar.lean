import WestfallSep
import Mathlib

namespace OAI

open scoped BigOperators

namespace LeanBlast.GotsmanLinial

abbrev Cube (n : ℕ) := Fin n → Bool

end LeanBlast.GotsmanLinial

noncomputable section

open scoped BigOperators

namespace LeanBlast.CourtadeKumar

abbrev Cube (n : ℕ) := LeanBlast.GotsmanLinial.Cube n

def cubeAverage {n : ℕ} (g : Cube n → ℝ) : ℝ :=
  (∑ x, g x) / (2 : ℝ) ^ n

def ell : ℝ := Real.log 2

def bitFlipKernel {n : ℕ} (ε : ℝ) (x y : Cube n) : ℝ :=
  ∏ i, if x i = y i then 1 - ε else ε

def jointProbability {n : ℕ} (ε : ℝ) (f : Cube n → Bool) (b : Bool) (y : Cube n) : ℝ :=
  cubeAverage (fun x => if f x = b then bitFlipKernel ε x y else 0)

def functionMarginal {n : ℕ} (ε : ℝ) (f : Cube n → Bool) (b : Bool) : ℝ :=
  ∑ y, jointProbability ε f b y

def observationMarginal {n : ℕ} (ε : ℝ) (f : Cube n → Bool) (y : Cube n) : ℝ :=
  ∑ b : Bool, jointProbability ε f b y

def xlogx (t : ℝ) : ℝ := t * Real.log t

def binaryEntropy (ε : ℝ) : ℝ :=
  -(xlogx ε + xlogx (1 - ε)) / ell

def mutualInformation {n : ℕ} (ε : ℝ) (f : Cube n → Bool) : ℝ :=
  (∑ b : Bool, ∑ y : Cube n,
    if 0 < jointProbability ε f b y then
      jointProbability ε f b y *
        Real.log (jointProbability ε f b y /
          (functionMarginal ε f b * observationMarginal ε f y))
    else 0) / ell

def dictator {n : ℕ} (i : Fin n) (x : Cube n) : Bool := x i

def complementDictator {n : ℕ} (i : Fin n) (x : Cube n) : Bool := !(x i)

def CourtadeKumarStatement : Prop :=
  ∀ (n : ℕ), 1 ≤ n →
    ∀ ε : ℝ, 0 ≤ ε → ε ≤ (1 : ℝ) / 2 →
      ∀ f : Cube n → Bool, mutualInformation ε f ≤ 1 - binaryEntropy ε

def DictatorAttainmentStatement : Prop :=
  ∀ (n : ℕ), 1 ≤ n →
    ∀ ε : ℝ, 0 ≤ ε → ε ≤ (1 : ℝ) / 2 →
      ∀ i : Fin n,
        mutualInformation ε (dictator i) = 1 - binaryEntropy ε ∧
        mutualInformation ε (complementDictator i) = 1 - binaryEntropy ε

def FullStatement : Prop := CourtadeKumarStatement ∧ DictatorAttainmentStatement

theorem courtadeKumarAndAttainment : FullStatement := by
  sorry

end LeanBlast.CourtadeKumar

end

end OAI


-- WESTFALL V0.9-R obligations (appended; the source above is unmodified)
#westfall_obl "R3_binaryEntropy_vs_Mathlib_binEntropy" "equal_all" "intro ε; simp only [OAI.LeanBlast.CourtadeKumar.binaryEntropy, OAI.LeanBlast.CourtadeKumar.xlogx, OAI.LeanBlast.CourtadeKumar.ell, Real.binEntropy, Real.log_inv]; ring ;; intro ε; unfold OAI.LeanBlast.CourtadeKumar.binaryEntropy OAI.LeanBlast.CourtadeKumar.xlogx OAI.LeanBlast.CourtadeKumar.ell Real.binEntropy; rw [Real.log_inv, Real.log_inv]; ring ;; intro ε; rw [Real.binEntropy_eq_negMulLog_add_negMulLog_one_sub]; simp [OAI.LeanBlast.CourtadeKumar.binaryEntropy, OAI.LeanBlast.CourtadeKumar.xlogx, OAI.LeanBlast.CourtadeKumar.ell, Real.negMulLog]; ring" (∀ (ε : ℝ), ((OAI.LeanBlast.CourtadeKumar.binaryEntropy ε) = (Real.binEntropy ε / Real.log 2)))
#westfall_obl "R3_binaryEntropy_vs_Mathlib_binEntropy" "agree_domain" "" (∀ (ε : ℝ), 0 ≤ ε ∧ ε ≤ 1 / 2 → ((OAI.LeanBlast.CourtadeKumar.binaryEntropy ε) = (Real.binEntropy ε / Real.log 2)))
#westfall_obl "R3_binaryEntropy_vs_Mathlib_binEntropy" "witness_all" "" (∃ (ε : ℝ), ¬ ((OAI.LeanBlast.CourtadeKumar.binaryEntropy ε) = (Real.binEntropy ε / Real.log 2)))
#westfall_obl "R3_binaryEntropy_vs_Mathlib_binEntropy" "witness_domain" "" (∃ (ε : ℝ), (0 ≤ ε ∧ ε ≤ 1 / 2) ∧ ¬ ((OAI.LeanBlast.CourtadeKumar.binaryEntropy ε) = (Real.binEntropy ε / Real.log 2)))
#westfall_baseline "R3_binaryEntropy_vs_Mathlib_binEntropy" "agree_domain" (∀ (ε : ℝ), 0 ≤ ε ∧ ε ≤ 1 / 2 → ((OAI.LeanBlast.CourtadeKumar.binaryEntropy ε) = (Real.binEntropy ε / Real.log 2)))
#westfall_baseline "R3_binaryEntropy_vs_Mathlib_binEntropy" "equal_all" (∀ (ε : ℝ), ((OAI.LeanBlast.CourtadeKumar.binaryEntropy ε) = (Real.binEntropy ε / Real.log 2)))
#westfall_obl "R4_cubeAverage_vs_uniform_average" "equal_all" "intro n g; simp [OAI.LeanBlast.CourtadeKumar.cubeAverage, Fintype.card_fun, Fintype.card_bool, div_eq_inv_mul] ;; intro n g; simp [OAI.LeanBlast.CourtadeKumar.cubeAverage, Fintype.card_fun, Fintype.card_bool, div_eq_inv_mul]; ring ;; intro n g; rw [OAI.LeanBlast.CourtadeKumar.cubeAverage, div_eq_inv_mul]; congr 1; simp [Fintype.card_fun, Fintype.card_bool]" (∀ (n : ℕ) (g : OAI.LeanBlast.CourtadeKumar.Cube n → ℝ), ((OAI.LeanBlast.CourtadeKumar.cubeAverage g) = ((Fintype.card (OAI.LeanBlast.CourtadeKumar.Cube n) : ℝ)⁻¹ * ∑ x, g x)))
#westfall_obl "R4_cubeAverage_vs_uniform_average" "agree_domain" "" (∀ (n : ℕ) (g : OAI.LeanBlast.CourtadeKumar.Cube n → ℝ), 1 ≤ n → ((OAI.LeanBlast.CourtadeKumar.cubeAverage g) = ((Fintype.card (OAI.LeanBlast.CourtadeKumar.Cube n) : ℝ)⁻¹ * ∑ x, g x)))
#westfall_obl "R4_cubeAverage_vs_uniform_average" "witness_all" "" (∃ (n : ℕ) (g : OAI.LeanBlast.CourtadeKumar.Cube n → ℝ), ¬ ((OAI.LeanBlast.CourtadeKumar.cubeAverage g) = ((Fintype.card (OAI.LeanBlast.CourtadeKumar.Cube n) : ℝ)⁻¹ * ∑ x, g x)))
#westfall_obl "R4_cubeAverage_vs_uniform_average" "witness_domain" "" (∃ (n : ℕ) (g : OAI.LeanBlast.CourtadeKumar.Cube n → ℝ), (1 ≤ n) ∧ ¬ ((OAI.LeanBlast.CourtadeKumar.cubeAverage g) = ((Fintype.card (OAI.LeanBlast.CourtadeKumar.Cube n) : ℝ)⁻¹ * ∑ x, g x)))
#westfall_baseline "R4_cubeAverage_vs_uniform_average" "agree_domain" (∀ (n : ℕ) (g : OAI.LeanBlast.CourtadeKumar.Cube n → ℝ), 1 ≤ n → ((OAI.LeanBlast.CourtadeKumar.cubeAverage g) = ((Fintype.card (OAI.LeanBlast.CourtadeKumar.Cube n) : ℝ)⁻¹ * ∑ x, g x)))
#westfall_baseline "R4_cubeAverage_vs_uniform_average" "equal_all" (∀ (n : ℕ) (g : OAI.LeanBlast.CourtadeKumar.Cube n → ℝ), ((OAI.LeanBlast.CourtadeKumar.cubeAverage g) = ((Fintype.card (OAI.LeanBlast.CourtadeKumar.Cube n) : ℝ)⁻¹ * ∑ x, g x)))
#westfall_obl "M5_binaryEntropy_in_nats" "equal_all" "" (∀ (ε : ℝ), ((-(OAI.LeanBlast.CourtadeKumar.xlogx ε + OAI.LeanBlast.CourtadeKumar.xlogx (1 - ε))) = (OAI.LeanBlast.CourtadeKumar.binaryEntropy ε)))
#westfall_obl "M5_binaryEntropy_in_nats" "agree_domain" "" (∀ (ε : ℝ), 0 ≤ ε ∧ ε ≤ 1 / 2 → ((-(OAI.LeanBlast.CourtadeKumar.xlogx ε + OAI.LeanBlast.CourtadeKumar.xlogx (1 - ε))) = (OAI.LeanBlast.CourtadeKumar.binaryEntropy ε)))
#westfall_obl "M5_binaryEntropy_in_nats" "witness_all" "" (∃ (ε : ℝ), ¬ ((-(OAI.LeanBlast.CourtadeKumar.xlogx ε + OAI.LeanBlast.CourtadeKumar.xlogx (1 - ε))) = (OAI.LeanBlast.CourtadeKumar.binaryEntropy ε)))
#westfall_obl "M5_binaryEntropy_in_nats" "witness_domain" "refine ⟨1 / 2, by norm_num, ?_⟩; simp only [OAI.LeanBlast.CourtadeKumar.binaryEntropy, OAI.LeanBlast.CourtadeKumar.xlogx, OAI.LeanBlast.CourtadeKumar.ell]; intro h; have h2 : (1 : ℝ) - 1 / 2 = 1 / 2 := by norm_num; rw [h2] at h; have hl : Real.log (1 / 2) = - Real.log 2 := by rw [one_div, Real.log_inv]; rw [hl] at h; have hp : 0 < Real.log 2 := Real.log_pos (by norm_num); field_simp at h; nlinarith [Real.log_two_lt_d9, Real.log_two_gt_d9] ;; refine ⟨1 / 2, by norm_num, ?_⟩; norm_num [OAI.LeanBlast.CourtadeKumar.binaryEntropy, OAI.LeanBlast.CourtadeKumar.xlogx, OAI.LeanBlast.CourtadeKumar.ell]; intro h; nlinarith [Real.log_two_lt_d9, Real.log_two_gt_d9]" (∃ (ε : ℝ), (0 ≤ ε ∧ ε ≤ 1 / 2) ∧ ¬ ((-(OAI.LeanBlast.CourtadeKumar.xlogx ε + OAI.LeanBlast.CourtadeKumar.xlogx (1 - ε))) = (OAI.LeanBlast.CourtadeKumar.binaryEntropy ε)))
#westfall_baseline "M5_binaryEntropy_in_nats" "agree_domain" (∀ (ε : ℝ), 0 ≤ ε ∧ ε ≤ 1 / 2 → ((-(OAI.LeanBlast.CourtadeKumar.xlogx ε + OAI.LeanBlast.CourtadeKumar.xlogx (1 - ε))) = (OAI.LeanBlast.CourtadeKumar.binaryEntropy ε)))
#westfall_baseline "M5_binaryEntropy_in_nats" "equal_all" (∀ (ε : ℝ), ((-(OAI.LeanBlast.CourtadeKumar.xlogx ε + OAI.LeanBlast.CourtadeKumar.xlogx (1 - ε))) = (OAI.LeanBlast.CourtadeKumar.binaryEntropy ε)))
#westfall_obl "M6_cubeAverage_wrong_normaliser" "equal_all" "" (∀ (n : ℕ) (g : OAI.LeanBlast.CourtadeKumar.Cube n → ℝ), (((∑ x, g x) / (2 : ℝ) ^ (n + 1)) = (OAI.LeanBlast.CourtadeKumar.cubeAverage g)))
#westfall_obl "M6_cubeAverage_wrong_normaliser" "agree_domain" "" (∀ (n : ℕ) (g : OAI.LeanBlast.CourtadeKumar.Cube n → ℝ), 1 ≤ n → (((∑ x, g x) / (2 : ℝ) ^ (n + 1)) = (OAI.LeanBlast.CourtadeKumar.cubeAverage g)))
#westfall_obl "M6_cubeAverage_wrong_normaliser" "witness_all" "" (∃ (n : ℕ) (g : OAI.LeanBlast.CourtadeKumar.Cube n → ℝ), ¬ (((∑ x, g x) / (2 : ℝ) ^ (n + 1)) = (OAI.LeanBlast.CourtadeKumar.cubeAverage g)))
#westfall_obl "M6_cubeAverage_wrong_normaliser" "witness_domain" "refine ⟨1, fun _ => 1, by norm_num, ?_⟩; simp [OAI.LeanBlast.CourtadeKumar.cubeAverage, Fintype.card_fun, Fintype.card_bool]; norm_num ;; refine ⟨1, fun _ => 1, le_refl 1, ?_⟩; norm_num [OAI.LeanBlast.CourtadeKumar.cubeAverage, Finset.sum_const, Finset.card_univ, Fintype.card_fun, Fintype.card_bool]" (∃ (n : ℕ) (g : OAI.LeanBlast.CourtadeKumar.Cube n → ℝ), (1 ≤ n) ∧ ¬ (((∑ x, g x) / (2 : ℝ) ^ (n + 1)) = (OAI.LeanBlast.CourtadeKumar.cubeAverage g)))
#westfall_baseline "M6_cubeAverage_wrong_normaliser" "agree_domain" (∀ (n : ℕ) (g : OAI.LeanBlast.CourtadeKumar.Cube n → ℝ), 1 ≤ n → (((∑ x, g x) / (2 : ℝ) ^ (n + 1)) = (OAI.LeanBlast.CourtadeKumar.cubeAverage g)))
#westfall_baseline "M6_cubeAverage_wrong_normaliser" "equal_all" (∀ (n : ℕ) (g : OAI.LeanBlast.CourtadeKumar.Cube n → ℝ), (((∑ x, g x) / (2 : ℝ) ^ (n + 1)) = (OAI.LeanBlast.CourtadeKumar.cubeAverage g)))
