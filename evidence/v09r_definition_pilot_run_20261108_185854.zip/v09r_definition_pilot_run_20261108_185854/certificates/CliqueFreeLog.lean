import WestfallSep
import Mathlib

namespace OAI

namespace CliqueFreeLog

noncomputable def averageDegree {V : Type*} [Fintype V] (G : SimpleGraph V) : ℝ := by
  classical
  exact 2 * (G.edgeFinset.card : ℝ) / (Fintype.card V : ℝ)

theorem logarithmic_independence_bound (r : ℕ) (hr : 4 ≤ r) :
    ∃ c : ℝ, 0 < c ∧
      ∀ {V : Type} [Fintype V] (G : SimpleGraph V),
        G.CliqueFree r → 2 ≤ averageDegree G →
        c * (Fintype.card V : ℝ) * Real.log (averageDegree G) / averageDegree G ≤
          (G.indepNum : ℝ) := by
  sorry

end CliqueFreeLog

end OAI


-- WESTFALL V0.9-R obligations (appended; the source above is unmodified)
#westfall_obl "R5_averageDegree_vs_degree_sum" "equal_all" "intro V _ G _; classical; unfold OAI.CliqueFreeLog.averageDegree; rw [← Nat.cast_sum, SimpleGraph.sum_degrees_eq_twice_card_edges]; push_cast; ring ;; intro V _ G _; unfold OAI.CliqueFreeLog.averageDegree; rw [← Nat.cast_sum, SimpleGraph.sum_degrees_eq_twice_card_edges]; push_cast; congr 2; simp ;; intro V _ G _; classical; simp only [OAI.CliqueFreeLog.averageDegree]; rw [← Nat.cast_sum]; congr 2; rw [SimpleGraph.sum_degrees_eq_twice_card_edges]; norm_cast; congr 1; convert rfl" (∀ (V : Type) [Fintype V] (G : SimpleGraph V) [DecidableRel G.Adj], ((OAI.CliqueFreeLog.averageDegree G) = ((∑ v, (G.degree v : ℝ)) / (Fintype.card V : ℝ))))
#westfall_obl "R5_averageDegree_vs_degree_sum" "agree_domain" "" (∀ (V : Type) [Fintype V] (G : SimpleGraph V) [DecidableRel G.Adj], 2 ≤ OAI.CliqueFreeLog.averageDegree G → ((OAI.CliqueFreeLog.averageDegree G) = ((∑ v, (G.degree v : ℝ)) / (Fintype.card V : ℝ))))
#westfall_baseline "R5_averageDegree_vs_degree_sum" "agree_domain" (∀ (V : Type) [Fintype V] (G : SimpleGraph V) [DecidableRel G.Adj], 2 ≤ OAI.CliqueFreeLog.averageDegree G → ((OAI.CliqueFreeLog.averageDegree G) = ((∑ v, (G.degree v : ℝ)) / (Fintype.card V : ℝ))))
#westfall_baseline "R5_averageDegree_vs_degree_sum" "equal_all" (∀ (V : Type) [Fintype V] (G : SimpleGraph V) [DecidableRel G.Adj], ((OAI.CliqueFreeLog.averageDegree G) = ((∑ v, (G.degree v : ℝ)) / (Fintype.card V : ℝ))))
