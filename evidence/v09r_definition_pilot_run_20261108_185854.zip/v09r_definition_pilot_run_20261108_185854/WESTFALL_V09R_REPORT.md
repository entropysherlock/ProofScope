# WESTFALL V0.9-R report

Commit `4eaee87548250b2682affda7d05d947c05554bae` · Lean (version 4.34.1 · Mathlib `d13f23b723b8` · 20261108_185854 UTC

## Levels

- **A_infrastructure**: True
- **B_certified_analysis**: True
- **C_novel_audit_finding**: NOT REACHED
- **D_research_breakthrough**: NOT CLAIMED (never assigned automatically)

## Forgery controls

- honest_module_accepted: PASS
- forged_theorem_rejected: PASS
- forged_certificate_rejected: PASS

## Five-case review (AI-curated; requires independent review)

| # | Definition | Reference | Outcome | Certificates (replayed) | Plausible |
|---|---|---|---|---|---|
| 1 | `OAI.Problem335.ceilDiv` | Mathlib CeilDiv on ℕ (Mathlib.Algebra.Order.Floor.Div) | **EQUIVALENT_CERTIFIED** | 3 (PASS) | NO_COUNTEREXAMPLE_FOUND |
| 1 | `OAI.Problem335.ceilDiv` | textbook ⌈n/t⌉ = ⌊n/t⌋ + [t ∤ n] (meaningful for t > 0) | **DISCREPANCY_OUTSIDE_DOMAIN_ONLY_CERTIFIED** | 3 (PASS) | NO_COUNTEREXAMPLE_FOUND |
| 2 | `OAI.Problem335.ceilSqrt` | textbook: ⌈√n⌉ is the least k with n ≤ k² | **BOUNDED_AGREEMENT_ONLY** | 1 (PASS) | ERROR |
| 3 | `OAI.LeanBlast.CourtadeKumar.binaryEntropy` | Mathlib Real.binEntropy (natural log), converted to bits | **EQUIVALENT_CERTIFIED** | 1 (PASS) | ERROR |
| 4 | `OAI.LeanBlast.CourtadeKumar.cubeAverage` | uniform expectation over the finite cube | **EQUIVALENT_CERTIFIED** | 1 (PASS) | ERROR |
| 5 | `OAI.CliqueFreeLog.averageDegree` | average of vertex degrees (Mathlib SimpleGraph.degree; handshake lemma sum_degrees_eq_twice_card_edges) | **INCONCLUSIVE** | 0 (PASS) | ERROR |

Interpretations:

- `R1a_ceilDiv_vs_Mathlib_ceilDiv`: Kernel-checked proof that the custom definition equals the reference everywhere: no scope change.
- `R1b_ceilDiv_vs_textbook_formula`: Certified difference, but certified agreement on the theorem's domain: a junk-value convention, not a scope change.
- `R2_ceilSqrt_vs_least_k_spec`: Agreement verified by kernel computation on a finite box only; no general certificate.
- `R3_binaryEntropy_vs_Mathlib_binEntropy`: Kernel-checked proof that the custom definition equals the reference everywhere: no scope change.
- `R4_cubeAverage_vs_uniform_average`: Kernel-checked proof that the custom definition equals the reference everywhere: no scope change.
- `R5_averageDegree_vs_degree_sum`: Search exhausted without any certificate: no claim.

## Adversarial controls and mutants

| Case | Expected | Got | Correct | Plausible (domain) |
|---|---|---|---|---|
| `C1_equivalent_rewritten` | EQUIVALENT_CERTIFIED | EQUIVALENT_CERTIFIED | yes | NO_COUNTEREXAMPLE_FOUND |
| `C2_off_by_one_boundary` | DISCREPANCY_IN_DOMAIN_CERTIFIED | DISCREPANCY_IN_DOMAIN_CERTIFIED | yes | COUNTEREXAMPLE |
| `C3_missing_hypothesis` | DISCREPANCY_IN_DOMAIN_CERTIFIED | DISCREPANCY_IN_DOMAIN_CERTIFIED | yes | ERROR |
| `C4_quantifier_order` | DISCREPANCY_IN_DOMAIN_CERTIFIED | DISCREPANCY_IN_DOMAIN_CERTIFIED | yes | ERROR |
| `C5_irrelevant_outside_domain` | DISCREPANCY_OUTSIDE_DOMAIN_ONLY_CERTIFIED | DISCREPANCY_OUTSIDE_DOMAIN_ONLY_CERTIFIED | yes | NO_COUNTEREXAMPLE_FOUND |
| `C6_genuine_inside_domain` | DISCREPANCY_IN_DOMAIN_CERTIFIED | DISCREPANCY_IN_DOMAIN_CERTIFIED | yes | COUNTEREXAMPLE |
| `C8_sorry_route_rejected` | DISCREPANCY_IN_DOMAIN_CERTIFIED | DISCREPANCY_IN_DOMAIN_CERTIFIED | yes | COUNTEREXAMPLE |
| `M1_ceilDiv_drops_minus_one` | DISCREPANCY_IN_DOMAIN_CERTIFIED | DISCREPANCY_IN_DOMAIN_CERTIFIED | yes | COUNTEREXAMPLE |
| `M2_ceilDiv_becomes_floor` | DISCREPANCY_IN_DOMAIN_CERTIFIED | DISCREPANCY_IN_DOMAIN_CERTIFIED | yes | COUNTEREXAMPLE |
| `M3_ceilSqrt_becomes_floor_sqrt` | DISCREPANCY_IN_DOMAIN_CERTIFIED | DISCREPANCY_IN_DOMAIN_CERTIFIED | yes | COUNTEREXAMPLE |
| `M4_ceilSqrt_always_rounds_up` | DISCREPANCY_IN_DOMAIN_CERTIFIED | DISCREPANCY_IN_DOMAIN_CERTIFIED | yes | COUNTEREXAMPLE |
| `M5_binaryEntropy_in_nats` | DISCREPANCY_IN_DOMAIN_CERTIFIED | INCONCLUSIVE | NO | ERROR |
| `M6_cubeAverage_wrong_normaliser` | DISCREPANCY_IN_DOMAIN_CERTIFIED | DISCREPANCY_IN_DOMAIN_CERTIFIED | yes | ERROR |

## Metrics (identical tasks)

```
{
 "engine_in_domain_discrepancy": {
  "tp": 10,
  "fp": 0,
  "fn": 1,
  "tn": 2,
  "precision": 1.0,
  "recall": 0.909,
  "false_positive_rate": 0.0
 },
 "plausible_in_domain_counterexample": {
  "tp": 7,
  "fp": 0,
  "fn": 4,
  "tn": 2,
  "precision": 1.0,
  "recall": 0.636,
  "false_positive_rate": 0.0
 },
 "engine_exact_label_accuracy": "12/13",
 "plausible_could_not_test": 4,
 "engine_certificates_replayed": 39,
 "runtime_s": {
  "Controls": {
   "compile": 8.5,
   "replay": 10.1
  },
  "CourtadeKumar": {
   "compile": 167.8,
   "replay": 25.9
  },
  "DepthFive": {
   "compile": 188.8,
   "replay": 27.5
  },
  "CliqueFreeLog": {
   "compile": 12.4,
   "replay": 11.2
  }
 },
 "labelled_set": "7 synthetic controls + 6 mutants of real definitions (built by WESTFALL; not held out, not independent)"
}
```

## Published numbers (not directly comparable)

- FormalRx-CC (ICML 2026 AI4Math): strict joint metric 13/204 (GPT-4.1-mini); 2/204 strictest — NON-EQUIVALENT (different dataset; code not released)
- SemantEq (Oct 2026): 100% precision, 65.6% recall — NON-EQUIVALENT (statement equivalence, no witnesses; not run here)
- Plausible (Lean, pinned rev): run here on identical tasks — MATCHED (see metrics)

## Limits

- Reference definitions and relevance judgements are AI-curated and must be independently reviewed.
- Controls and mutants are constructed by WESTFALL itself; they show the method behaves as designed, not that it generalises.
- Bounded results are kernel-certified only on the stated finite box.
- Kernel replay uses the same kernel implementation (leanchecker), not an independent checker.
- Pair-specific tactics (marked in obligations.csv) were written for this pilot; portfolio tactics are generic.
