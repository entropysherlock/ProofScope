import PFRS.AllOrders

/-!
# WestfallAudit -- independent restatement of the principal formal theorems

STATUS: WRITTEN, NOT COMPILED.  The author of this file had no Lean toolchain.  Every `pin_*`
theorem below restates, in this file's own text, the type that the manuscript claims, and proves it
by the upstream/WESTFALL theorem of the same content.  If the proved statement were not (up to
definitional unfolding) the pinned one, Lean would reject the `pin_*` declaration and
`verify.py` stage S9 would FAIL.  A failure can also mean a transcription slip in a pin: inspect the
error before concluding anything about the underlying theorem.

The pins are written against the printed kernel terms recorded in the V14.1 audit
(`evidence/V20_FINAL_AUDIT_without_repeated_warnings.txt`) and the source text of
`src/PFRS/*.lean`.  They use only Mathlib's `SimpleGraph`, `SimpleGraph.indepNum`, the rationals,
and two upstream definitions (`connectedMatchingNumber`, `hadwigerNumber`), whose Lean text is
printed in `docs/CORRESPONDENCE.md`.

`#print axioms` is then run on every pin and on the underlying declarations.  verify.py requires
each printed set to be a subset of {propext, Classical.choice, Quot.sound}.
-/

open OAI OAI.HadwigerMatching OAI.HadwigerCounterexample

namespace WestfallAudit

/-- Manuscript Theorem B with k = q (alpha <= 2).  Quantifier order: q, then N0, then m, then G. -/
theorem pin_all_orders_le (q : ℕ) (hq : 0 < q) :
    ∃ N₀ : ℕ, ∀ m : ℕ, N₀ ≤ m →
      ∃ G : SimpleGraph (Fin m), G.indepNum ≤ 2 ∧
        (connectedMatchingNumber G : ℚ) < (m : ℚ) / q :=
  exists_graphs_all_orders q hq

/-- Manuscript Theorem B, alpha = 2 form (q >= 3). -/
theorem pin_all_orders_eq (q : ℕ) (hq : 3 ≤ q) :
    ∃ N₀ : ℕ, ∀ m : ℕ, N₀ ≤ m →
      ∃ G : SimpleGraph (Fin m), G.indepNum = 2 ∧
        (connectedMatchingNumber G : ℚ) < (m : ℚ) / q :=
  exists_graphs_all_orders_eq q hq

/-- Manuscript Theorem 1.5(a) (machine-verified list), alpha = 2. -/
theorem pin_formal_a (q : ℕ) (hq : 3 ≤ q) (M₁ : ℕ) :
    ∃ m : ℕ, max M₁ 5 ≤ m ∧ ∃ G : SimpleGraph (Fin m), G.indepNum = 2 ∧
      (connectedMatchingNumber G : ℚ) < (m : ℚ) / q :=
  exists_graphs_q_eq q hq M₁

/-- Same, alpha <= 2, any q > 0. -/
theorem pin_formal_a_le (q : ℕ) (hq : 0 < q) (M₁ : ℕ) :
    ∃ m : ℕ, max M₁ 5 ≤ m ∧ ∃ G : SimpleGraph (Fin m), G.indepNum ≤ 2 ∧
      (connectedMatchingNumber G : ℚ) < (m : ℚ) / q :=
  exists_graphs_q q hq M₁

/-- Manuscript Theorem 1.5(b): no linear lower bound for connected matchings (alpha = 2). -/
theorem pin_formal_b :
    ¬ ∃ c : ℚ, 0 < c ∧ ∃ m₀ : ℕ, ∀ m : ℕ, m₀ ≤ m → ∀ G : SimpleGraph (Fin m),
      G.indepNum = 2 → c * (m : ℚ) ≤ (connectedMatchingNumber G : ℚ) :=
  no_linear_connected_matching_alpha_two

/-- Same with alpha <= 2. -/
theorem pin_formal_b_le :
    ¬ ∃ c : ℚ, 0 < c ∧ ∃ m₀ : ℕ, ∀ m : ℕ, m₀ ≤ m → ∀ G : SimpleGraph (Fin m),
      G.indepNum ≤ 2 → c * (m : ℚ) ≤ (connectedMatchingNumber G : ℚ) :=
  no_linear_connected_matching

/-- Manuscript Theorem 1.5(c): no linear improvement of the Duchet--Meyniel bound (alpha = 2). -/
theorem pin_formal_c :
    ¬ ∃ ε : ℚ, 0 < ε ∧ ∃ m₀ : ℕ, ∀ m : ℕ, m₀ ≤ m → ∀ G : SimpleGraph (Fin m),
      G.indepNum = 2 → ((1 : ℚ) / 3 + ε) * (m : ℚ) ≤ (LinearListHadwiger.hadwigerNumber G : ℚ) :=
  no_seymour_improvement_alpha_two

/-- Same with alpha <= 2. -/
theorem pin_formal_c_le :
    ¬ ∃ ε : ℚ, 0 < ε ∧ ∃ m₀ : ℕ, ∀ m : ℕ, m₀ ≤ m → ∀ G : SimpleGraph (Fin m),
      G.indepNum ≤ 2 → ((1 : ℚ) / 3 + ε) * (m : ℚ) ≤ (LinearListHadwiger.hadwigerNumber G : ℚ) :=
  no_seymour_improvement

/-- The alpha <= 1 step used to upgrade `<= 2` to `= 2` (complete graphs). -/
theorem pin_alpha_one {V : Type} [Fintype V] (G : SimpleGraph V) (h : G.indepNum ≤ 1) :
    Fintype.card V ≤ 2 * connectedMatchingNumber G + 1 :=
  cm_large_of_indepNum_le_one G h

end WestfallAudit

/-! ## Axiom audit (parsed by verify.py) -/
#print axioms WestfallAudit.pin_all_orders_le
#print axioms WestfallAudit.pin_all_orders_eq
#print axioms WestfallAudit.pin_formal_a
#print axioms WestfallAudit.pin_formal_a_le
#print axioms WestfallAudit.pin_formal_b
#print axioms WestfallAudit.pin_formal_b_le
#print axioms WestfallAudit.pin_formal_c
#print axioms WestfallAudit.pin_formal_c_le
#print axioms WestfallAudit.pin_alpha_one
#print axioms OAI.HadwigerCounterexample.exists_graphs_all_orders
#print axioms OAI.HadwigerCounterexample.exists_graphs_all_orders_eq
#print axioms OAI.HadwigerCounterexample.window_bridge
#print axioms OAI.HadwigerCounterexample.window_cover
#print axioms OAI.HadwigerCounterexample.window_upper
#print axioms OAI.HadwigerCounterexample.window_top_le
#print axioms OAI.HadwigerCounterexample.ord_eq_pow
#print axioms OAI.HadwigerCounterexample.pf_rs
#print axioms OAI.HadwigerCounterexample.pf_rs_dims
#print axioms OAI.HadwigerCounterexample.exists_parameters_L
#print axioms OAI.HadwigerCounterexample.eventual_conflict_lower_bound
#print axioms OAI.HadwigerCounterexample.not_hadwiger_conjecture

/-! ## Definition probes (printed into the log for human comparison with the manuscript) -/
#print OAI.HadwigerMatching.IsTouchingMatching
#print OAI.HadwigerMatching.connectedMatchingNumber
#print OAI.LinearListHadwiger.HasCliqueMinor
#print OAI.LinearListHadwiger.hadwigerNumber
#print OAI.HadwigerCounterexample.ord
