/-!
# KernelControl.Good -- honest control module (verify.py stage S10a)

Uses only core `Init`.  `leanchecker KernelControl.Good` must succeed.
-/

theorem kc_good_add : 1 + 1 = 2 := rfl

theorem kc_good_zero_add (n : Nat) : 0 + n = n := Nat.zero_add n
