import Lean

/-!
# KernelControl.Forged -- deliberate forgery (verify.py stage S10a), NOT part of the proof development

This file is a NEGATIVE CONTROL for the kernel replay.  With the kernel type-check switched off
(`debug.skipKernelTC`), a meta-program inserts the declaration `kc_forged : False` whose value is
`True.intro`.  The elaborator accepts it, `lean -o` writes an `.olean`, and `#print axioms kc_forged` reports
"does not depend on any axioms" -- so an axiom audit alone cannot see this.  `leanchecker KernelControl.Forged`
must REJECT the module with a kernel "declaration type mismatch" naming `kc_forged`; if it does not,
the checker installed on this machine has no power to detect environment tampering and the replay
results for the real modules must not be trusted.

Nothing imports this module.  verify.py scans the six WESTFALL sources and the upstream closure for
`skipKernelTC`; this control file is the only place in the package where it occurs.
-/

open Lean Elab Command

set_option debug.skipKernelTC true in
run_cmd liftCoreM <| addDecl (.thmDecl
  { name := `kc_forged, levelParams := [], type := mkConst ``False, value := mkConst ``True.intro })

#print axioms kc_forged
