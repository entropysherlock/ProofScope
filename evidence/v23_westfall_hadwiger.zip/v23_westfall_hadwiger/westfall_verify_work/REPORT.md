# WESTFALL V22 verification report

Overall: **ALL MANDATORY STAGES PASSED INCLUDING KERNEL REPLAY (see limitations)** (exit code 0)

manifest sha256: `63d4fe3b419c147b1bf4174bb84487e50b54747ef55247cce269dad7dca427bb`
platform: Linux-6.6.159+-x86_64-with-glibc2.39

| stage | status | mandatory | title |
|---|---|---|---|
| S0a | PASS | yes | python >= 3.8 |
| S0a | PASS | yes | git available |
| S1 | PASS | yes | frozen WESTFALL sources: sha256 + forbidden-construct scan |
| S2 | PASS | yes | pinned upstream checkout (fresh clone): HEAD == commit, tree clean |
| S2b | PASS | no | git trees of closure directories identical at 4eaee875 (manuscript claim) |
| S3 | PASS | yes | pins: lake-manifest/lakefile/lean-toolchain hashes, Mathlib rev, 42 package revs |
| S4 | PASS | yes | static import closure (6 PFRS + 288 upstream modules): roots, fingerprint, order |
| S0b | PASS | yes | Lean toolchain == pinned version and commit; lake present; leanchecker present |
| S10a | PASS | yes | leanchecker accepts an honest module and rejects a forged declaration (Mathlib-free control) |
| S5 | PASS | yes | restore pinned dependencies without update: manifest unchanged, 42 revs == pins, closure packages clean |
| S5b | INFO | no | tracked-file changes outside the closure (the source of Lake's 'has local changes' warnings) vs upstream's declared patches |
| S6 | PASS | yes | Mathlib official olean cache (`lake exe cache get`) |
| S7 | PASS | yes | build the upstream import closure from source (lake build OAI.Combinatorics.HadwigerCounterexample.Main) |
| S5c | PASS | no | no .olean path provided by two different LEAN_PATH roots (shadowing; only built oleans are scanned) |
| S8 | PASS | yes | compile the six PFRS modules in dependency order (lean -R src -o build/PFRS/X.olean) |
| S9 | PASS | yes | statement pins compile; #print axioms for 21 targets all within {propext, Classical.choice, Quot.sound} |
| S10 | PASS | yes | leanchecker replay, scope: 6 PFRS modules (non-fresh) |

Stages not reached in this run: none


## Trust base and limitations (always printed)

- Mathlib/Batteries/etc. oleans come from the official Mathlib cache unless `--mathlib-cache none` was used.
- leanchecker uses the same Lean kernel: it is a replay/anti-tampering check, not an independent kernel implementation.
- Compilation success is not mathematical novelty or refereeing; see docs/ for the statement audit.
- Existence theorems only: no explicit N0(q) is claimed or checked.
