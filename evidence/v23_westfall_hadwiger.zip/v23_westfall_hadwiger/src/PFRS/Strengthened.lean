import PFRS.Lifting

/-!
# PF-RS with explicit dimensional guarantees

Caleb J Westfall, November 2026.

`pf_rs` (in `PFRS/Lifting.lean`, unchanged) does not state any property of the
dimension multiplier `M`. This file records, from the same parameter choice,
the facts used by the sampling argument:

* `4 ≤ M` (upstream field `AnalyticParameters.thickness`), hence `N = M * n → ∞`
  (upstream `trend_sizes`);
* eventually `2 * |Full p n| < M * n` (first component of upstream `planted.wrap`);
* eventually a good mixer exists and raw supersaturation holds.

All three eventual statements are combined into a single `∀ᶠ n`.
-/

namespace OAI

noncomputable section
namespace HadwigerCounterexample
open Filter

theorem pf_rs_dims (L : ℝ) (hL0 : 0 ≤ L) :
    ∃ (p : Shape) (b : PreparationParameters) (M r : ℕ),
      p.g = birthG ∧ b.D = 4000 * p.g ∧ b.L = L ∧ 4 ≤ M ∧
      Tendsto (fun n : ℕ => M * n) atTop atTop ∧
      ∀ᶠ n : ℕ in atTop,
        2 * num (Full p n) < ((M * n : ℕ) : ℝ) ∧
        (∃ m : Mixer p n, unaryGood m b.pins r ∧ binaryGood m) ∧
        (∀ m : Mixer p n, unaryGood m b.pins r → binaryGood m →
          conflictLowerBound p m (M * n) b) := by
  obtain ⟨p,b,M,r,h,hg,hd,hl⟩ := exists_parameters_L L hL0
  have ht := h.enter.first
  refine ⟨p,b,M,r,hg,hd,hl,h.thickness,(trend_sizes atTop le_rfl ht.hM).1,?_⟩
  filter_upwards [ht.wrap, goodMixers p b.pins r (by linarith only [ht.hG]) ht.hJ
      (by have hi := h.profiles; omega) h.bigJ, eventual_conflict_lower_bound h] with n hw hm hc
  exact ⟨hw.1, hm, hc⟩

end HadwigerCounterexample

end

end OAI

#print axioms OAI.HadwigerCounterexample.pf_rs_dims
