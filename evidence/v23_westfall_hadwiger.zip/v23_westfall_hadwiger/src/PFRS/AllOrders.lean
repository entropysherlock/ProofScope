import PFRS.WindowTransfer
import PFRS.Strengthened
import PFRS.AlphaTwo

/-!
# All-orders theorem

STATUS: WRITTEN, NOT COMPILED (no Lean toolchain was available where this was authored).
Expect small tactic-level repairs. Do not report as verified until
`#print axioms` on each theorem below shows no `sorryAx`.

* `exists_graphs_all_orders`    : ∀ q > 0, ∃ N₀, ∀ m ≥ N₀, ∃ G : SimpleGraph (Fin m),
                                   α(G) ≤ 2 ∧ cm(G) < m/q          (Theorem 1.6 with k = q)
* `exists_graphs_all_orders_eq` : same with α(G) = 2, for q ≥ 3.

Proof shape: `exists_graphs_q` with `transfer_scales_window` in place of `transfer_scales_q`
(the sample size `m` stays universally quantified in `[ord g N, 2^(1500 g N)]`), then
`window_cover` / `window_upper` to cover every large `m`.
-/

namespace OAI

noncomputable section
namespace HadwigerCounterexample
open Finset Real HadwigerMatching
open Filter Matrix
open StatusAnalysis StatusAnalysis.Station
open LinearListHadwiger

/-- Gap B (arithmetic): the construction's lower order for dimension `k*n`. -/
theorem ord_eq_pow (g k n : ℕ) : ord g (k*n) = 2^(1000*g*k*n) := by
  unfold ord
  congr 1
  ring

/-- Gap B (arithmetic): the top of window `n` sits below `2^(1500 g (k n))` once `2 ≤ n`. -/
theorem window_top_le (g k n : ℕ) (hn : 2 ≤ n) :
    2^(1000*g*k*(n+1)) ≤ 2^(1500*g*(k*n)) := by
  have e : 1000*g*k*(n+1) = 1000*g*(k*n+k) := by ring
  rw [e]
  exact window_upper g k n hn

/-- Gap A (bridge): for each cap `bp (6q+1)` there is a dimension multiplier `k ≥ 4`,
a shape with `g > 0`, and an eventual-in-`n` statement giving a graph at EVERY order in
`[2^(1000 g k n), 2^(1500 g k n)]`. -/
theorem window_bridge (q : ℕ) (hq : 0 < q) :
    ∃ (g k : ℕ), 0 < g ∧ 0 < k ∧
      ∀ᶠ n : ℕ in atTop, 2 ≤ n ∧
        ∀ m : ℕ, 2^(1000*g*k*n) ≤ m → m ≤ 2^(1500*g*(k*n)) →
          ∃ G : SimpleGraph (Fin m), G.indepNum ≤ 2 ∧
            (connectedMatchingNumber G : ℚ) < (m : ℚ)/q := by
  classical
  obtain ⟨p,b,k,r,h,hg,hd,he⟩ := exists_parameters_L (bp (6*(q:ℝ)+1)) (bp_pos _).le
  have ht := h.enter.first
  let B := 4*num (Comp p.g)
  let Y (n:ℕ) := k*n
  have hy := (trend_sizes atTop le_rfl ht.hM).1
  have hp : 0 < p.g := lt_of_lt_of_le (by norm_num) ht.hG
  have hk : 0 < k := by have := h.thickness; omega
  refine ⟨p.g, k, hp, hk, ?_⟩
  filter_upwards [eventually_ge_atTop 2, eventual_conflict_lower_bound h, ht.wrap,
      goodMixers p b.pins r (by linarith only [ht.hG]) ht.hJ
        (by have hi:=h.profiles; omega) h.bigJ,
      hy.eventually
        (transfer_scales_window hp hq
          (show 0≤B from mul_nonneg (by norm_num) (Nat.cast_nonneg _)))]
    with n hn2 hn ht' hl hq'
  refine ⟨hn2, fun m' hlo hhi => ?_⟩
  let N := Y n
  obtain ⟨mx,hm,he'⟩ := hl
  have hT := hn mx hm he'
  have hV : 2*num (Full p n)<(N:ℝ) := ht'.1
  have hC : num (UnitType p n N) ≤ bp (B*N^ (2:ℕ)) := by
    rw [unit_size]; apply bp_le
    have hf : num (Full p n) ≤ N := by linarith only [hV,(Nat.cast_nonneg N : 0≤(N:ℝ))]
    unfold B
    calc _ ≤ num (Comp p.g)*4*(N:ℝ)*N := mul_le_mul_of_nonneg_left hf (by unfold num; positivity)
         _ = _ := by ring
  have hlo' : ord p.g N ≤ m' := by
    have e : ord p.g N = 2^(1000*p.g*k*n) := ord_eq_pow p.g k n
    rw [e]; exact hlo
  obtain ⟨x,hx,hX⟩ := hq' (Orient p n N) (rawHoles mx) (raw mx N) (raw_law mx hV) hC (by
      intro w hw hC hU
      apply hT w _ hU
      apply PreparationParameters.born w hw mx
      rw [hd,he]; simpa only [N,Y,Nat.cast_mul,Nat.cast_ofNat] using hC) m' hlo' hhi
  exact ⟨(rawHoles mx).graph x, hx, hX⟩

/-- **All orders, α ≤ 2.** Manuscript Theorem 1.6 (with `k = q`). -/
theorem exists_graphs_all_orders
    (q : ℕ) (hq : 0 < q) :
    ∃ N₀ : ℕ, ∀ m : ℕ, N₀ ≤ m →
      ∃ G : SimpleGraph (Fin m),
        G.indepNum ≤ 2 ∧
        (connectedMatchingNumber G : ℚ) < (m : ℚ) / q := by
  obtain ⟨g, k, hg, hk, hev⟩ := window_bridge q hq
  obtain ⟨n₁, hn₁⟩ := eventually_atTop.1 hev
  refine ⟨2^(1000*g*k*n₁), fun m hm => ?_⟩
  obtain ⟨n, hn1n, hlo, hhi⟩ := window_cover g k n₁ m hg hk hm
  obtain ⟨h2, hw⟩ := hn₁ n hn1n
  exact hw m hlo (hhi.trans (window_top_le g k n h2))

/-- **All orders, α = 2.** For `q ≥ 3`. -/
theorem exists_graphs_all_orders_eq
    (q : ℕ) (hq : 3 ≤ q) :
    ∃ N₀ : ℕ, ∀ m : ℕ, N₀ ≤ m →
      ∃ G : SimpleGraph (Fin m),
        G.indepNum = 2 ∧
        (connectedMatchingNumber G : ℚ) < (m : ℚ) / q := by
  obtain ⟨N₀, hN⟩ := exists_graphs_all_orders q (by omega)
  refine ⟨max N₀ 5, fun m hm => ?_⟩
  have hmN : N₀ ≤ m := (le_max_left _ _).trans hm
  have hm5 : 5 ≤ m := (le_max_right _ _).trans hm
  obtain ⟨G, hG, hcm⟩ := hN m hmN
  refine ⟨G, ?_, hcm⟩
  by_contra hne
  have h1 : G.indepNum ≤ 1 := by omega
  have hc := cm_large_of_indepNum_le_one G h1
  rw [Fintype.card_fin] at hc
  have hqpos : (0:ℚ) < q := by exact_mod_cast (show 0 < q by omega)
  have hcm' : (connectedMatchingNumber G : ℚ) * q < m := (lt_div_iff₀ hqpos).mp hcm
  have hcQ : (m:ℚ) ≤ 2 * (connectedMatchingNumber G : ℚ) + 1 := by exact_mod_cast hc
  have hq3 : (3:ℚ) ≤ q := by exact_mod_cast hq
  have hm5Q : (5:ℚ) ≤ m := by exact_mod_cast hm5
  have hc0 : (0:ℚ) ≤ (connectedMatchingNumber G : ℚ) := Nat.cast_nonneg _
  have h3 : (connectedMatchingNumber G : ℚ) * 3 ≤ (connectedMatchingNumber G : ℚ) * q :=
    mul_le_mul_of_nonneg_left hq3 hc0
  linarith

end HadwigerCounterexample
end
end OAI

/-! ## Audit commands -/
#print axioms OAI.HadwigerCounterexample.ord_eq_pow
#print axioms OAI.HadwigerCounterexample.window_top_le
#print axioms OAI.HadwigerCounterexample.window_bridge
#print axioms OAI.HadwigerCounterexample.exists_graphs_all_orders
#print axioms OAI.HadwigerCounterexample.exists_graphs_all_orders_eq
#print OAI.HadwigerCounterexample.exists_graphs_all_orders
#print OAI.HadwigerCounterexample.exists_graphs_all_orders_eq
#print axioms OAI.HadwigerCounterexample.window_upper
#print axioms OAI.HadwigerCounterexample.window_cover

/-! ## Definition-fidelity probes (manuscript Sec. 4 compares these to its printed definitions) -/
#print OAI.HadwigerMatching.IsTouchingMatching
#print OAI.HadwigerMatching.connectedMatchingNumber
#print OAI.LinearListHadwiger.HasCliqueMinor
#print OAI.LinearListHadwiger.hadwigerNumber
#print OAI.HadwigerCounterexample.ord
