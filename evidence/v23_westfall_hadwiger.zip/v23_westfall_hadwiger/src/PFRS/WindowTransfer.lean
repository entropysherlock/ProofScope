import PFRS.Sampling

/-!
# Window transfer: every order in `[2^(1000 g N), 2^(1500 g N)]`

STATUS: SOURCE ONLY. NOT COMPILED. Written against upstream `transfer_scales`
(openai/math, ExponentialGraphTransfer.lean) and the WESTFALL `transfer_scales_q`
(PFRS/Sampling.lean, PDF transcription). Expect small tactic-level repairs.

`transfer_scales_window` is `transfer_scales_q` with the sample size `m` universally
quantified in the window `ord g N ≤ m ≤ 2^(1500*g*N)` instead of fixed to `ord g N`.
`transfer_q` already accepts an arbitrary `m`, so only the numeric side conditions change.
-/

namespace OAI
noncomputable section
namespace HadwigerCounterexample

open Finset Real HadwigerMatching Filter
open scoped BigOperators

/-- For `n ≥ 2`, `N = M0 * n`: `N + M0 ≤ 3N/2`, hence the window's upper end is `≤ 2^(1500 g N)`. -/
theorem window_upper (g M0 n : ℕ) (hn : 2 ≤ n) :
    2^(1000*g*(M0*n+M0)) ≤ 2^(1500*g*(M0*n)) := by
  apply Nat.pow_le_pow_right (by norm_num)
  have h := Nat.mul_le_mul_left (g*M0) hn
  nlinarith [h]

/-- Windows `[2^(c n), 2^(c (n+1))]`, `c = 1000*g*M0 ≥ 1`, cover every `m ≥ 2^(c n1)`
with some `n ≥ n1`. -/
theorem window_cover (g M0 n1 m : ℕ) (hg : 0 < g) (hM0 : 0 < M0)
    (hm : 2^(1000*g*M0*n1) ≤ m) :
    ∃ n : ℕ, n1 ≤ n ∧ 2^(1000*g*M0*n) ≤ m ∧ m ≤ 2^(1000*g*M0*(n+1)) := by
  have hc : 0 < 1000*g*M0 := by positivity
  set c := 1000*g*M0 with hcdef
  have hm0 : m ≠ 0 := by
    have : 0 < 2^(c*n1) := pow_pos (by norm_num : 0 < (2:ℕ)) _
    omega
  refine ⟨Nat.log 2 m / c, ?_, ?_, ?_⟩
  · have h1 : c*n1 ≤ Nat.log 2 m := Nat.le_log_of_pow_le (by norm_num) hm
    calc n1 = c*n1 / c := (Nat.mul_div_cancel_left n1 hc).symm
      _ ≤ Nat.log 2 m / c := Nat.div_le_div_right h1
  · calc 2^(c*(Nat.log 2 m / c)) ≤ 2^(Nat.log 2 m) :=
          Nat.pow_le_pow_right (by norm_num) (Nat.mul_div_le _ _)
      _ ≤ m := Nat.pow_log_le_self 2 hm0
  · have h3 : Nat.log 2 m + 1 ≤ c*(Nat.log 2 m / c + 1) :=
      Nat.lt_mul_div_succ (Nat.log 2 m) hc
    calc m ≤ 2^(Nat.log 2 m + 1) := (Nat.lt_pow_succ_log_self (by norm_num) m).le
      _ ≤ 2^(c*(Nat.log 2 m / c + 1)) := Nat.pow_le_pow_right (by norm_num) h3

theorem transfer_scales_window {g q : ℕ} (hg : 0 < g) (hq : 0 < q) {B : ℝ} (hB : 0 ≤ B) :
    ∀ᶠ N : ℕ in atTop, ∀ (A : Type) [Fintype A] [Nonempty A]
      (H : Holes A) (μ : Wgt A), IsLaw μ →
      (Fintype.card (A × A) : ℝ) ≤ bp (B * (N:ℝ)^2) →
      (∀ w : Wgt (A × A), IsLaw w → pairCaps μ (bp (6*(q:ℝ)+1)) (bp (4000*g*N)) w →
        carried w H.unit → bp (-100*g*N) ≤ pr (pairW w w) (fun x => H.conflict x.1 x.2)) →
      ∀ m : ℕ, ord g N ≤ m → m ≤ 2^(1500*g*N) →
      ∃ x : Fin m → A,
        (H.graph x).indepNum ≤ 2 ∧
        (connectedMatchingNumber (H.graph x) : ℚ) < (m : ℚ)/q := by
  have hg' : (1:ℝ) ≤ g := by exact_mod_cast hg
  have hh := bp_poly_dom_nat (a:=100*g) (by positivity) (B+1) 2
  filter_upwards [hh, eventually_ge_atTop 1,
    (tendsto_ord hg).eventually (eventually_ge_atTop 2), eventually_ge_atTop q]
    with N hN hN' hord hNq
  intro A _ _ H μ hμ hA hs m hlo hhi
  let y : ℝ := g * (N:ℝ)
  have hNr : (1:ℝ) ≤ N := by exact_mod_cast hN'
  have hy : 1 ≤ y := by unfold y; nlinarith
  let L : ℕ := 2^(200*g*N)
  have hmlo : bp (1000*y) ≤ (m:ℝ) := by
    have h1 : ((ord g N : ℕ):ℝ) ≤ (m:ℝ) := by exact_mod_cast hlo
    have h2 : ((ord g N : ℕ):ℝ) = bp (1000*y) := by
      rw [cast_ord]; unfold y; ring_nf
    linarith
  have hmhi : (m:ℝ) ≤ bp (1500*y) := by
    have h1 : (m:ℝ) ≤ (2:ℝ)^(1500*g*N) := by exact_mod_cast hhi
    have h := (bp_nat (1500*g*N)).symm
    push_cast at h
    unfold y
    rw [← mul_assoc]
    rw [h] at h1
    exact h1
  have hl : (L:ℝ) = bp (200*y) := by
    have h := (bp_nat (200*g*N)).symm
    push_cast at h
    dsimp only [L]
    push_cast
    unfold y
    rwa [← mul_assoc]
  let z : ℝ := B*(N:ℝ)^2
  have hz : 0 ≤ z := by unfold z; positivity
  have hb : z + 1 < bp (100*y) := by
    have hh : (B+1)*(N:ℝ)^2 < bp (100*y) := by simpa only [y, mul_assoc] using hN
    unfold z
    nlinarith only [hh,hNr]
  have hm' : (2:ℝ) ≤ m := by
    have : 2 ≤ m := hord.trans hlo
    exact_mod_cast this
  obtain ⟨k, hk1, hk2⟩ : ∃ k : ℕ, 2*q*k < m + 2*q ∧ m ≤ 2*q*k := by
    refine ⟨(m+2*q-1)/(2*q), ?_⟩
    have h1 := Nat.div_add_mod (m+2*q-1) (2*q)
    have h2 := Nat.mod_lt (m+2*q-1) (show 0 < 2*q by omega)
    generalize 2 * q * ((m + 2 * q - 1) / (2 * q)) = P at h1 ⊢
    generalize (m + 2 * q - 1) % (2 * q) = r at h1 h2
    omega
  refine transfer_q H hμ hq (bp_pos _) (bp_pos _) (bp_pos _) hs (L:=L) (k:=k) ?_ hk1 ?_
  · have hi : log (Fintype.card (A × A) : ℝ) ≤ z * Real.log 2 := by
      rw [← log_bp]
      exact Real.log_le_log (by exact_mod_cast Fintype.card_pos) hA
    apply lt_of_le_of_lt hi
    calc z * log 2 < bp (100*y)*log 2 :=
          mul_lt_mul_of_pos_right (by linarith only [hb]) (Real.log_pos (by norm_num))
      _ = _ := by
          rw [hl,← mul_assoc (bp (200 * y)),← bp_add]
          unfold y; ring_nf
  · have hk2r : (m:ℝ) ≤ 2*q*k := by exact_mod_cast hk2
    have hqy : (q:ℝ) ≤ y := by
      have h0 : (q:ℝ) ≤ N := by exact_mod_cast hNq
      have h1 : (N:ℝ) ≤ y := by unfold y; nlinarith
      linarith
    have hqk : (q:ℝ)*k ≤ y*k := mul_le_mul_of_nonneg_right hqy (Nat.cast_nonneg _)
    have hyk : 0 ≤ y*k := mul_nonneg (by linarith) (Nat.cast_nonneg _)
    let a := (Fintype.card (A × A):ℝ)+1
    have ha : a ≤ bp (z+1) := by
      rw [bp_add,bp_one]
      have hx : 1 ≤ bp z := by simpa only [bp_zero] using bp_le hz
      change _ ≤ bp z at hA
      dsimp only [a]
      linarith only [hx,hA]
    have hal : a^L ≤ bp (m:ℝ) := calc
      a^L ≤ bp (z+1)^L := by
            have hp : 0 ≤ a := by dsimp [a]; positivity
            gcongr
      _ = bp ((z+1)*L) := (bp_mul_nat _ _).symm
      _ ≤ bp (m:ℝ) := bp_le (by
            rw [hl]
            calc (z+1)*bp (200*y) ≤ bp (100*y)*bp (200*y) :=
                  mul_le_mul_of_nonneg_right hb.le (bp_pos _).le
              _ ≤ bp (1000*y) := by rw [← bp_add]; apply bp_le; linarith only [hy]
              _ ≤ (m:ℝ) := hmlo)
    let d := bp (4000*(g:ℝ)*(N:ℝ))
    have ha1 : bp (m:ℝ) * ((2:ℝ)^m * (2/bp (6*(q:ℝ)+1))^k) ≤ bp (-(m:ℝ)) := by
      rw [← bp_nat, show 2/bp (6*(q:ℝ)+1) = bp (1-(6*(q:ℝ)+1)) by simp only [bp_sub,bp_one],
        ← bp_mul_nat, ← bp_add, ← bp_add]
      apply bp_le
      nlinarith [hk2r]
    have he : (m:ℝ)^(k+k) ≤ bp ((1500*y)*(k+k:ℕ)) := by
      rw [bp_mul_nat]
      calc (m:ℝ)^(k+k) ≤ (bp (1500*y))^(k+k) := by gcongr
        _ = _ := rfl
    have ha2 : bp (m:ℝ) * ((m:ℝ)^(k+k) * (d⁻¹)^k) ≤ bp (-(m:ℝ)) := by
      have hd' : d⁻¹ = bp (-(4000*y)) := by simp only [bp_neg,d,y,mul_assoc]
      rw [hd']
      calc bp (m:ℝ) * ((m:ℝ)^(k+k) * (bp (-(4000*y)))^k)
          ≤ bp (m:ℝ) * (bp ((1500*y)*(k+k:ℕ)) * (bp (-(4000*y)))^k) :=
            mul_le_mul_of_nonneg_left
              (mul_le_mul_of_nonneg_right he (pow_pos (bp_pos _) k).le) (bp_pos _).le
        _ ≤ bp (-(m:ℝ)) := by
            rw [← bp_mul_nat (-(4000*y)) k, ← bp_add, ← bp_add]
            apply bp_le
            push_cast
            nlinarith [hk2r, hqk, hyk]
    have hx : bp (-(m:ℝ)) < 1/2 := by
      rw [show (1:ℝ)/2 = bp (-1) by simp only [one_div,bp_neg,bp_one]]
      exact bp_lt (by linarith only [hm'])
    change a^L * (2^m * (2/bp (6*(q:ℝ)+1))^k + (m:ℝ)^(k+k) * d⁻¹^k) < 1
    refine lt_of_le_of_lt (mul_le_mul_of_nonneg_right hal (by
      have h := bp_pos (6*(q:ℝ)+1)
      have h' : 0 < d := bp_pos _
      positivity)) ?_
    linarith only [ha1,ha2,hx]

end HadwigerCounterexample
end
end OAI

#print axioms OAI.HadwigerCounterexample.window_upper
#print axioms OAI.HadwigerCounterexample.window_cover
#print axioms OAI.HadwigerCounterexample.transfer_scales_window
