import PFRS.Lifting
import Mathlib.Data.Fintype.Powerset

/-!
# From PF-RS to vanishing connected-matching density

Caleb J Westfall, November 2026.

Upstream `transfer` (FiniteGraphTransfer.lean) already accepts an arbitrary
marginal cap, but its conclusion is fixed to `cm < m/100`, and
`transfer_scales` (ExponentialGraphTransfer.lean) fixes the cap `bp 1000`.
This file generalizes both to the target `cm < m/q` for every `q ≥ 1`, using
the cap `bp (6q+1)` supplied by `exists_parameters_L` from `PFRS/Lifting.lean`.

The private upstream helpers `badS`, `badS_pr`, `badE`, `badE_pr` and
`many_bad` are copied verbatim under the suffix `Q`, since private
declarations are not visible across modules.

Main results:
* `exists_graphs_q` : for every `q ≥ 1` there are arbitrarily large `m` and
  graphs on `Fin m` with independence number at most two and `cm < m/q`;
* `no_linear_connected_matching` : no constant `c > 0` has `cm(G) ≥ c·m` for all
  large graphs with independence number at most two;
* `no_seymour_improvement` : no `ε > 0` has `h(G) ≥ (1/3+ε)·m` for all large
  graphs with independence number at most two.
-/

namespace OAI

noncomputable section

namespace HadwigerCounterexample
open Finset Real HadwigerMatching
open scoped BigOperators
variable {A V : Type*}

/-! ## Copies of the private upstream helpers (verbatim, renamed) -/

/-- k distinct samples in S (unordered). -/
private def badSQ (S : A → Prop) (k : ℕ) (x : V → A) :=
  ∃ T : Finset V, T.card = k ∧ ∀ v ∈ T, S (x v)

private theorem badSQ_pr [Fintype A] {μ : Wgt A} (hμ : IsLaw μ)
    (S : A → Prop) (k m : ℕ) :
    pr (prodW (fun _ : Fin m => μ)) (badSQ S k) ≤
      2 ^ m * (pr μ S)^k := by
  classical
  let q := prodW (fun _ : Fin m => μ)
  have hp (T : Finset (Fin m)) :
      pr q (fun x => T.card = k ∧ ∀ v ∈ T, S (x v)) ≤ (pr μ S)^k := by
    by_cases h : T.card = k
    · have e (x : Fin m → A) : (∀ v ∈ T, S (x v)) ↔ ∀ v : T, S (x v.val) := by simp
      have h' := prodW_pr_inj (e:=fun v : T => v.val) Subtype.val_injective
        (w:=fun _ => μ) (fun _ => hμ) (fun _ : T => S)
      simp_rw [h, true_and, e]
      simp only [prod_const, Finset.card_univ, Fintype.card_coe,h] at h'
      exact h'.le
    · have hn : 0 ≤ pr μ S := pr_nonneg hμ.nz
      simp only [h, false_and, pr_false]
      positivity
  have he := pr_exists_le (prodW_nonneg (w:=fun _ : Fin m => μ) (fun _ => hμ.nz))
    (fun T : Finset (Fin m) => (fun x => T.card = k ∧ ∀ v ∈ T, S (x v)))
  refine he.trans ((sum_le_sum (fun i _ => hp i)).trans_eq ?_)
  simp

/-- k pair exceptions using disjoint sample positions (ordered pairs). -/
private def badEQ (E : A × A → Prop) (k : ℕ) (x : V → A) :=
  ∃ e : Fin k ⊕ Fin k → V, Function.Injective e ∧
    ∀ i, E (x (e (.inl i)), x (e (.inr i)))

private theorem badEQ_pr [Fintype A] {μ : Wgt A} (hμ : IsLaw μ)
    (E : A × A → Prop) (k m : ℕ) :
    pr (prodW (fun _ : Fin m => μ)) (badEQ E k) ≤
      (m : ℝ)^(k+k) * (pr (pairW μ μ) E)^k := by
  classical
  let Q := prodW (fun _ : Fin m => μ)
  let P (e : Fin k ⊕ Fin k → Fin m) (x : Fin m → A) :=
    Function.Injective e ∧ ∀ i, E (x (e (.inl i)), x (e (.inr i)))
  have hp (e : Fin k ⊕ Fin k → Fin m) :
      pr Q (P e) ≤ (pr (pairW μ μ) E)^k := by
    by_cases h : Function.Injective e
    · have h' := prodW_map_pairs e h hμ
      let f (x : Fin m → A) (i : Fin k) := (x (e (.inl i)), x (e (.inr i)))
      have hp : P e = (fun x => ∀ i, E (f x i)) := by simp [P,h,f]
      rw [hp, ← mapW_pr Q f (fun x => ∀ i, E (x i))]
      change mapW Q f = _ at h'
      rw [h']
      have hb := prodW_pr (w:=fun _ : Fin k => pairW μ μ) (p:=fun _ => E)
      simpa using hb.le
    · have hn : 0 ≤ pr (pairW μ μ) E := pr_nonneg (pairW_law hμ hμ).nz
      simp only [P,h,false_and,pr_false]; positivity
  have he := pr_exists_le (prodW_nonneg (w:=fun _ : Fin m => μ) (fun _ => hμ.nz)) P
  refine he.trans ((sum_le_sum (fun i _ => hp i)).trans_eq ?_)
  simp

private theorem many_badQ {x : V → A} (S : A → Prop) (E : A × A → Prop)
    {k t : ℕ} (ht : k + k ≤ t + 1)
    {e : Fin t ⊕ Fin t → V} (he : Function.Injective e)
    (hp : ∀ i, S (x (e (.inl i))) ∨ S (x (e (.inr i))) ∨
      E (x (e (.inl i)), x (e (.inr i)))) :
    badSQ S k x ∨ badEQ E k x := by
  classical
  let p (i : Fin t) := S (x (e (.inl i))) ∨ S (x (e (.inr i)))
  let I := univ.filter p
  let J := univ.filter (fun i => ¬ p i)
  by_cases hI : k ≤ I.card
  · left
    obtain ⟨r⟩ := Function.Embedding.nonempty_of_card_le
      (show Fintype.card (Fin k) ≤ Fintype.card I by simpa using hI)
    let f : Fin k → Fin t := fun i => r i
    have hf : Function.Injective f := fun i j g => r.injective (Subtype.ext g)
    let y : Fin k → Fin t ⊕ Fin t :=
      fun i => if S (x (e (.inl (f i)))) then .inl (f i) else .inr (f i)
    have hy (i : Fin k) : S (x (e (y i))) := by
      have h : p (f i) := (mem_filter.mp (r i).property).2
      unfold p at h
      unfold y
      split
      · assumption
      · rename_i hn; exact h.resolve_left hn
    have hid i : Sum.elim id id (y i) = f i := by unfold y; split <;> rfl
    have hy' : Function.Injective y := fun i j g =>
      hf (by rw [←hid,←hid,g])
    refine ⟨univ.image (e ∘ y), by rw [card_image_of_injective _ (he.comp hy')]; simp,?_⟩
    intro v hv
    obtain ⟨i,_,rfl⟩ := mem_image.mp hv
    exact hy i
  · right
    have hJ : k ≤ J.card := by
      have hsum : I.card + J.card = t := by
        simpa using Finset.card_filter_add_card_filter_not (s:=univ) p
      omega
    obtain ⟨r⟩ := Function.Embedding.nonempty_of_card_le
      (show Fintype.card (Fin k) ≤ Fintype.card J by simpa using hJ)
    let f : Fin k → Fin t := fun i => r i
    have hf : Function.Injective f := fun i j g => r.injective (Subtype.ext g)
    refine ⟨e ∘ Sum.map f f, he.comp (Sum.map_injective.mpr ⟨hf,hf⟩),?_⟩
    intro i
    have h : ¬p (f i) := (mem_filter.mp (r i).property).2
    exact ((hp _).resolve_left (fun g => h (Or.inl g))).resolve_left
      (fun g => h (Or.inr g))

/-! ## Finite transfer with target `m/q` -/

/-- Upstream `transfer` with the conclusion `cm < m/q` in place of `cm < m/100`
and the hypothesis `2*q*k < m + 2*q` in place of `200*k < m+200`. -/
theorem transfer_q [Fintype A] [Nonempty A] (H : Holes A) {μ : Wgt A} (hμ : IsLaw μ)
    {q : ℕ} (hq : 0 < q)
    {M D ε : ℝ} (hM : 0 < M) (hD : 0 < D) (hε : 0 < ε)
    (hsat : ∀ w : Wgt (A × A), IsLaw w → pairCaps μ M D w → carried w H.unit →
      ε ≤ pr (pairW w w) (fun x => H.conflict x.1 x.2))
    {L m k : ℕ} (hL : Real.log (Fintype.card (A × A)) < L * (ε * Real.log 2))
    (hk : 2*q*k < m + 2*q)
    (herr :
      ((Fintype.card (A × A) : ℝ) + 1)^L *
        (2^m * (2/M)^k + (m:ℝ)^(k+k) * D⁻¹^k) < 1) :
    ∃ x : Fin m → A,
      (H.graph x).indepNum ≤ 2 ∧
      (connectedMatchingNumber (H.graph x) : ℚ) < (m : ℚ)/q := by
  classical
  let R := univ.filter H.unit
  let O := {w : Wgt (A × A) | IsLaw w} ∩ {w | pairCaps μ M D w}
  obtain ⟨C,hC,hTC,hCC⟩ := containers (ok:=O)
    (compact_isLaw.inter_right (closed_pairCaps _ _ _)) (fun _ h => h.1)
    (fun _ h _ g => ⟨mid_isLaw h.1 g.1, mid_pairCaps h.2 g.2⟩)
    H.conflict hε R (fun w hw g => hsat w hw.1 hw.2 (by simpa [carried,R] using g))
    L (fun w hw _ => by
      have h := log_card_le_negEnt hw.1
      linarith)
  have hx (r : C) :
      ∃ (S : A → Prop) (E : A × A → Prop), M* pr μ S < 2 ∧
        D * pr (pairW μ μ) E < 1 ∧ ∀ x : A × A, x ∈ r.val → S x.1 ∨ S x.2 ∨ E x :=
    terminal hμ.nz hM hD _ (fun ⟨w,h,g,k⟩ => (hTC _ r.property).2 ⟨w,⟨h,g⟩,k⟩)
  choose S E hs hq' hcover using hx
  let P (r : C) (x : Fin m → A) := badSQ (S r) k x ∨ badEQ (E r) k x
  let W := prodW (fun _ : Fin m => μ)
  have hw : IsLaw W := prodW_law fun _ => hμ
  let b := (2:ℝ)^m * (2/M)^k + (m:ℝ)^(k+k) * D⁻¹^k
  have hp (r : C) : pr W (P r) ≤ b := by
    have h₁ := badSQ_pr hμ (S r) k m
    have h₂ := badEQ_pr hμ (E r) k m
    refine (pr_or_le hw.nz).trans ((add_le_add h₁ h₂).trans ?_)
    have hi : 0 ≤ pr μ (S r) := pr_nonneg hμ.nz
    have hj : 0 ≤ pr (pairW μ μ) (E r) := pr_nonneg (pairW_law hμ hμ).nz
    have hk : pr μ (S r) ≤ 2/M := (le_div_iff₀ hM).mpr (by linarith only [hs r])
    have hn : pr (pairW μ μ) (E r) ≤ D⁻¹ := by
      rw [← one_div]
      apply (le_div_iff₀ hD).mpr
      linarith only [hq' r]
    unfold b; gcongr
  have hf : pr W (fun x => ∃ r, P r x) < 1 := by
    have h : pr W (fun x => ∃ r, P r x) ≤ (C.card : ℝ) * b := by
      refine (pr_exists_le hw.nz P).trans ((sum_le_sum (fun i _ => hp i)).trans_eq ?_)
      simp
    apply lt_of_le_of_lt h
    apply lt_of_le_of_lt _ herr
    have hg : C.card ≤ (Fintype.card (A × A) + 1)^L :=
      hC.trans (by gcongr; exact card_le_univ _)
    have hb : 0 ≤ b := by unfold b; positivity
    exact mul_le_mul_of_nonneg_right (by exact_mod_cast hg) hb
  have hg : 0 < pr W (fun x => ¬∃ r, P r x) := by rw [pr_not, hw.total]; linarith only [hf]
  obtain ⟨x,hx,_⟩ := exists_of_pr_pos hw.nz hg
  refine ⟨x, H.indepNum_graph_le _,?_⟩
  let t := connectedMatchingNumber (H.graph x)
  by_contra! hn
  obtain ⟨e,he,he₁,he₂⟩ := H.matching_pairs x
  let f (i : Fin t) : A × A := (x (e (.inl i)), x (e (.inr i)))
  let I := univ.image f
  have hIR : I ⊆ R := by
    intro y hy; obtain ⟨i,_,rfl⟩ := mem_image.mp hy
    exact mem_filter.mpr ⟨mem_univ _, he₁ i⟩
  have hI (v) (hv : v ∈ I) (w) (hw : w ∈ I) : ¬ H.conflict v w := by
    obtain ⟨i,_,rfl⟩ := mem_image.mp hv
    obtain ⟨j,_,rfl⟩ := mem_image.mp hw
    exact he₂ i j
  obtain ⟨r,hr,g⟩ := hCC I hIR hI
  have ht : m ≤ t * q := by
    change (m:ℚ)/q ≤ (t:ℚ) at hn
    have hqQ : (0:ℚ) < q := by exact_mod_cast hq
    have h : (m:ℚ) ≤ (t:ℚ)*q := (div_le_iff₀ hqQ).mp hn
    exact_mod_cast h
  have h2 : k + k ≤ t + 1 := by
    by_contra hc
    have h5 : q*(t+2) ≤ q*(k+k) := Nat.mul_le_mul (le_refl q) (by omega)
    nlinarith [hk, ht, h5]
  apply hx
  let r' : C := ⟨r,hr⟩
  refine ⟨r', many_badQ (S r') (E r') h2 he fun i =>
    hcover r' (f i) (g (mem_image_of_mem f (mem_univ i)))⟩

/-! ## Asymptotic transfer with cap `bp (6q+1)` and target `m/q` -/

open Filter in
theorem transfer_scales_q {g q : ℕ} (hg : 0 < g) (hq : 0 < q) {B : ℝ} (hB : 0 ≤ B) :
    ∀ᶠ N : ℕ in atTop, ∀ (A : Type) [Fintype A] [Nonempty A]
      (H : Holes A) (μ : Wgt A), IsLaw μ →
      (Fintype.card (A × A) : ℝ) ≤ bp (B * (N:ℝ)^2) →
      (∀ w : Wgt (A × A), IsLaw w → pairCaps μ (bp (6*(q:ℝ)+1)) (bp (4000*g*N)) w →
        carried w H.unit → bp (-100*g*N) ≤ pr (pairW w w) (fun x => H.conflict x.1 x.2)) →
      ∃ x : Fin (ord g N) → A,
        (H.graph x).indepNum ≤ 2 ∧
        (connectedMatchingNumber (H.graph x) : ℚ) < (ord g N : ℚ)/q := by
  have hg' : (1:ℝ) ≤ g := by exact_mod_cast hg
  have hh := bp_poly_dom_nat (a:=100*g) (by positivity) (B+1) 2
  filter_upwards [hh, eventually_ge_atTop 1,
    (tendsto_ord hg).eventually (eventually_ge_atTop 2), eventually_ge_atTop q]
    with N hN hN' hord hNq
  intro A _ _ H μ hμ hA hs
  let y : ℝ := g * (N:ℝ)
  have hNr : (1:ℝ) ≤ N := by exact_mod_cast hN'
  have hy : 1 ≤ y := by unfold y; nlinarith
  let m := ord g N
  let L : ℕ := 2^(200*g*N)
  have hm : (m:ℝ) = bp (1000*y) := by rw [cast_ord]; unfold y; ring_nf
  have hl : (L:ℝ) = bp (200*y) := by
    have h := (bp_nat (200*g*N)).symm
    push_cast at h
    dsimp only [L]
    push_cast
    unfold y
    rwa [← mul_assoc]
  let z : ℝ := B*(N:ℝ)^2
  have hz : 0 ≤ z := by unfold z; positivity
  have hb : z + 1 < bp (100*y) := by
    have hh : (B+1)*(N:ℝ)^2 < bp (100*y) := by simpa only [y, mul_assoc] using hN
    unfold z
    nlinarith only [hh,hNr]
  obtain ⟨k, hk1, hk2⟩ : ∃ k : ℕ, 2*q*k < m + 2*q ∧ m ≤ 2*q*k := by
    refine ⟨(m+2*q-1)/(2*q), ?_⟩
    have h1 := Nat.div_add_mod (m+2*q-1) (2*q)
    have h2 := Nat.mod_lt (m+2*q-1) (show 0 < 2*q by omega)
    generalize 2 * q * ((m + 2 * q - 1) / (2 * q)) = P at h1 ⊢
    generalize (m + 2 * q - 1) % (2 * q) = r at h1 h2
    omega
  refine transfer_q H hμ hq (bp_pos _) (bp_pos _) (bp_pos _) hs (L:=L) (k:=k) ?_ hk1 ?_
  · have hi : log (Fintype.card (A × A) : ℝ) ≤ z * Real.log 2 := by
      rw [← log_bp]
      exact Real.log_le_log (by exact_mod_cast Fintype.card_pos) hA
    apply lt_of_le_of_lt hi
    calc z * log 2 < bp (100*y)*log 2 :=
           mul_lt_mul_of_pos_right (by linarith only [hb]) (Real.log_pos (by norm_num))
         _ = _ := by
           rw [hl,← mul_assoc (bp (200 * y)),← bp_add]
           unfold y; ring_nf
  · have hk2r : (m:ℝ) ≤ 2*q*k := by exact_mod_cast hk2
    have hm' : (2:ℝ) ≤ m := by exact_mod_cast hord
    have hqy : (q:ℝ) ≤ y := by
      have h0 : (q:ℝ) ≤ N := by exact_mod_cast hNq
      have h1 : (N:ℝ) ≤ y := by unfold y; nlinarith
      linarith
    have hqk : (q:ℝ)*k ≤ y*k := mul_le_mul_of_nonneg_right hqy (Nat.cast_nonneg _)
    have hyk : 0 ≤ y*k := mul_nonneg (by linarith) (Nat.cast_nonneg _)
    let a := (Fintype.card (A × A):ℝ)+1
    have ha : a ≤ bp (z+1) := by
      rw [bp_add,bp_one]
      have hx : 1 ≤ bp z := by simpa only [bp_zero] using bp_le hz
      change _ ≤ bp z at hA
      dsimp only [a]
      linarith only [hx,hA]
    have hal : a^L ≤ bp (m:ℝ) := calc
      a^L ≤ bp (z+1)^L := by
        have hp : 0 ≤ a := by dsimp [a]; positivity
        gcongr
      _ = bp ((z+1)*L) := (bp_mul_nat _ _).symm
      _ ≤ bp (m:ℝ) := bp_le (by
        rw [hm,hl]
        calc (z+1)*bp (200*y) ≤ bp (100*y)*bp (200*y) :=
               mul_le_mul_of_nonneg_right hb.le (bp_pos _).le
             _ ≤ bp (1000*y) := by rw [← bp_add]; apply bp_le; linarith only [hy])
    let d := bp (4000*(g:ℝ)*(N:ℝ))
    have ha1 : bp (m:ℝ) * ((2:ℝ)^m * (2/bp (6*(q:ℝ)+1))^k) ≤ bp (-(m:ℝ)) := by
      rw [← bp_nat, show 2/bp (6*(q:ℝ)+1) = bp (1-(6*(q:ℝ)+1)) by simp only [bp_sub,bp_one],
        ← bp_mul_nat, ← bp_add, ← bp_add]
      apply bp_le
      nlinarith [hk2r]
    have ha2 : bp (m:ℝ) * ((m:ℝ)^(k+k) * (d⁻¹)^k) ≤ bp (-(m:ℝ)) := by
      have he : (m:ℝ)^(k+k) = bp ((1000*y)*(k+k:ℕ)) := by
        rw [hm,bp_mul_nat]
      rw [he, show d⁻¹ = bp (-(4000*y)) by simp only [bp_neg,d,y,mul_assoc],
        ← bp_mul_nat, ← bp_add, ← bp_add]
      apply bp_le
      push_cast
      nlinarith [hk2r, hqk, hyk]
    have hx : bp (-(m:ℝ)) < 1/2 := by
      rw [show (1:ℝ)/2 = bp (-1) by simp only [one_div,bp_neg,bp_one]]
      exact bp_lt (by linarith only [hm'])
    change a^L * (2^m * (2/bp (6*(q:ℝ)+1))^k + (m:ℝ)^(k+k) * d⁻¹^k) < 1
    refine lt_of_le_of_lt (mul_le_mul_of_nonneg_right hal (by
      have h := bp_pos (6*(q:ℝ)+1)
      have h' : 0 < d := bp_pos _
      positivity)) ?_
    linarith only [ha1,ha2,hx]

/-! ## Graphs with small connected matchings at arbitrarily large orders -/

open Filter Matrix
open StatusAnalysis StatusAnalysis.Station
open LinearListHadwiger

/-- For every `q ≥ 1` and every bound `M₁`, there is `m ≥ max M₁ 5` and a graph
on `Fin m` with independence number at most two and `cm < m/q`. -/
theorem exists_graphs_q (q : ℕ) (hq : 0 < q) (M₁ : ℕ) : ∃ m : ℕ, max M₁ 5 ≤ m ∧
    ∃ G : SimpleGraph (Fin m), G.indepNum ≤ 2 ∧
      (connectedMatchingNumber G : ℚ) < (m : ℚ)/q := by
  classical
  obtain ⟨p,b,k,r,h,hg,hd,he⟩ := exists_parameters_L (bp (6*(q:ℝ)+1)) (bp_pos _).le
  have ht := h.enter.first
  let B := 4*num (Comp p.g)
  let Y (n:ℕ) := k*n
  have hy := (trend_sizes atTop le_rfl ht.hM).1
  have hp : 0 < p.g := lt_of_lt_of_le (by norm_num) ht.hG
  have hs : ∀ᶠ n:ℕ in atTop, ∃ m:ℕ, max M₁ 5 ≤ m ∧
      ∃ G : SimpleGraph (Fin m), G.indepNum ≤ 2 ∧ (connectedMatchingNumber G:ℚ)<(m:ℚ)/q := by
    filter_upwards [eventual_conflict_lower_bound h,ht.wrap,goodMixers p b.pins r (by linarith only [ht.hG])
      ht.hJ (by have hi:=h.profiles; omega) h.bigJ,hy.eventually
      (transfer_scales_q hp hq (show 0≤B from mul_nonneg (by norm_num) (Nat.cast_nonneg _))),
      ((tendsto_ord hp).comp hy).eventually (eventually_ge_atTop (max M₁ 5))] with n hn ht hl hq' hN
    let N := Y n
    obtain ⟨m,hm,he'⟩ := hl
    have hT := hn m hm he'; have hV : 2*num (Full p n)<(N:ℝ) := ht.1
    have hC : num (UnitType p n N) ≤ bp (B*N^ (2:ℕ)) := by
      rw [unit_size]; apply bp_le
      have hf : num (Full p n) ≤ N := by linarith only [hV,(Nat.cast_nonneg N : 0≤(N:ℝ))]
      unfold B
      calc _ ≤ num (Comp p.g)*4*(N:ℝ)*N := mul_le_mul_of_nonneg_left hf (by unfold num; positivity)
           _ = _ := by ring
    obtain ⟨x,hx,hX⟩ := hq' (Orient p n N) (rawHoles m) (raw m N) (raw_law m hV) hC (by
      intro w hw hC hU
      apply hT w _ hU
      apply PreparationParameters.born w hw m
      rw [hd,he]; simpa only [N,Y,Nat.cast_mul,Nat.cast_ofNat] using hC)
    exact ⟨ord p.g N,hN,(rawHoles m).graph x,hx,hX⟩
  obtain ⟨n,hn⟩ := hs.exists; exact hn

/-- The linear connected-matching conjecture fails: there is no `c > 0` such that
every sufficiently large graph with independence number at most two has a
connected matching of size at least `c·|V(G)|`. -/
theorem no_linear_connected_matching :
    ¬ ∃ c : ℚ, 0 < c ∧ ∃ m₀ : ℕ, ∀ m : ℕ, m₀ ≤ m → ∀ G : SimpleGraph (Fin m),
      G.indepNum ≤ 2 → c * m ≤ (connectedMatchingNumber G : ℚ) := by
  rintro ⟨c, hc, m₀, h⟩
  obtain ⟨q, hq⟩ := exists_nat_gt (1/c)
  have hq0 : 0 < q := by
    have h1 : (0:ℚ) < 1/c := by positivity
    exact_mod_cast h1.trans hq
  obtain ⟨m, hm, G, hG, hcm⟩ := exists_graphs_q q hq0 m₀
  have hm5 : 5 ≤ m := (le_max_right _ _).trans hm
  have h1 := h m ((le_max_left _ _).trans hm) G hG
  have hmpos : (0:ℚ) < m := by exact_mod_cast (show 0 < m by omega)
  have hqpos : (0:ℚ) < q := by exact_mod_cast hq0
  have hcq : 1 < q*c := (div_lt_iff₀ hc).mp hq
  have hcm' : (connectedMatchingNumber G : ℚ) * q < m := (lt_div_iff₀ hqpos).mp hcm
  nlinarith [mul_le_mul_of_nonneg_right h1 hqpos.le]

/-- Seymour's problem has a negative answer: there is no `ε > 0` such that every
sufficiently large graph with independence number at most two has a
`K_t` minor with `t ≥ (1/3 + ε)·|V(G)|`. -/
theorem no_seymour_improvement :
    ¬ ∃ ε : ℚ, 0 < ε ∧ ∃ m₀ : ℕ, ∀ m : ℕ, m₀ ≤ m → ∀ G : SimpleGraph (Fin m),
      G.indepNum ≤ 2 → (1/3 + ε) * m ≤ (LinearListHadwiger.hadwigerNumber G : ℚ) := by
  rintro ⟨ε, hε, m₀, h⟩
  obtain ⟨q, hq⟩ := exists_nat_gt (8/(3*ε))
  have hq0 : 0 < q := by
    have h1 : (0:ℚ) < 8/(3*ε) := by positivity
    exact_mod_cast h1.trans hq
  obtain ⟨m, hm, G, hG, hcm⟩ := exists_graphs_q q hq0 (max m₀ q)
  have hm5 : 5 ≤ m := (le_max_right _ _).trans hm
  have hmq : q ≤ m := (le_max_right _ _).trans ((le_max_left _ _).trans hm)
  have hm0 : m₀ ≤ m := (le_max_left _ _).trans ((le_max_left _ _).trans hm)
  have : NeZero m := ⟨by omega⟩
  have hx := full_matching_minor_proposition (Fin m) G
  dsimp only at hx
  rw [Fintype.card_fin] at hx
  have hmb := hx.1
  have h1 := h m hm0 G hG
  have hmpos : (0:ℚ) < m := by exact_mod_cast (show 0 < m by omega)
  have hqpos : (0:ℚ) < q := by exact_mod_cast hq0
  have hmqQ : (q:ℚ) ≤ m := by exact_mod_cast hmq
  have hεq : 8 < 3*ε*q := by
    have := (div_lt_iff₀ (by positivity : (0:ℚ) < 3*ε)).mp hq
    linarith
  have hcm' : (connectedMatchingNumber G : ℚ) * q < m := (lt_div_iff₀ hqpos).mp hcm
  have k2 : 3*ε*m ≤ 4*(connectedMatchingNumber G : ℚ) + 2 := by linarith
  have k3 : 3*ε*m*q ≤ (4*(connectedMatchingNumber G : ℚ) + 2)*q :=
    mul_le_mul_of_nonneg_right k2 hqpos.le
  have k4 : 8*(m:ℚ) < 3*ε*q*m := by nlinarith
  nlinarith

end HadwigerCounterexample

end

end OAI

#print axioms OAI.HadwigerCounterexample.exists_graphs_q
#print axioms OAI.HadwigerCounterexample.no_linear_connected_matching
#print axioms OAI.HadwigerCounterexample.no_seymour_improvement
