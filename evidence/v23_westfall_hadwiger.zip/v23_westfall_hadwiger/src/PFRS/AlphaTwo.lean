import PFRS.Sampling

/-!
# The disproofs with independence number exactly two

Caleb J Westfall, November 2026.

Füredi–Gyárfás–Simonyi state their connected-matching conjecture for graphs with
independence number exactly two. `PFRS/Sampling.lean` proves the disproofs for
independence number at most two. This file closes the gap: a graph with
independence number at most one is complete, so it has a touching matching
covering all but at most one vertex (upstream `extend_matching_by_clique_pairs`),
which is far larger than `m/q` for `q ≥ 3`. Hence the sampled graphs of
`exists_graphs_q` have independence number exactly two.
-/

namespace OAI

noncomputable section

namespace HadwigerCounterexample
open Finset HadwigerMatching

/-- A finite graph with independence number at most one is complete, so it has a
touching matching covering all but at most one vertex. -/
theorem cm_large_of_indepNum_le_one {V : Type} [Fintype V] (G : SimpleGraph V)
    (h : G.indepNum ≤ 1) : Fintype.card V ≤ 2 * connectedMatchingNumber G + 1 := by
  classical
  have hS : G.IsClique ((Finset.univ : Finset V) : Set V) := by
    intro v _ w _ hvw
    by_contra hadj
    have hI : G.IsIndepSet (({v, w} : Finset V) : Set V) := by
      rw [Finset.coe_pair]
      exact Set.pairwise_pair.mpr (fun _ => ⟨hadj, fun h' => hadj h'.symm⟩)
    have h2 := hI.card_le_indepNum
    rw [Finset.card_pair_eq_two_iff.mpr hvw] at h2
    omega
  obtain ⟨P, hP, -, hcard⟩ := extend_matching_by_clique_pairs G ∅ Finset.univ
    (isTouchingMatching_empty G) hS (by simp) (by simp)
  have hle := matching_card_le_number hP
  rw [Finset.empty_union] at hle
  rw [Finset.card_univ] at hcard
  omega

/-- `exists_graphs_q` with independence number exactly two (for `q ≥ 3`). -/
theorem exists_graphs_q_eq (q : ℕ) (hq : 3 ≤ q) (M₁ : ℕ) : ∃ m : ℕ, max M₁ 5 ≤ m ∧
    ∃ G : SimpleGraph (Fin m), G.indepNum = 2 ∧
      (connectedMatchingNumber G : ℚ) < (m : ℚ)/q := by
  obtain ⟨m, hm, G, hG, hcm⟩ := exists_graphs_q q (by omega) M₁
  refine ⟨m, hm, G, ?_, hcm⟩
  by_contra hne
  have h1 : G.indepNum ≤ 1 := by omega
  have hc := cm_large_of_indepNum_le_one G h1
  rw [Fintype.card_fin] at hc
  have hm5 : 5 ≤ m := (le_max_right _ _).trans hm
  have hqpos : (0:ℚ) < q := by exact_mod_cast (show 0 < q by omega)
  have hcm' : (connectedMatchingNumber G : ℚ) * q < m := (lt_div_iff₀ hqpos).mp hcm
  have hcQ : (m:ℚ) ≤ 2 * (connectedMatchingNumber G : ℚ) + 1 := by exact_mod_cast hc
  have hq3 : (3:ℚ) ≤ q := by exact_mod_cast hq
  have hm5Q : (5:ℚ) ≤ m := by exact_mod_cast hm5
  have hc0 : (0:ℚ) ≤ (connectedMatchingNumber G : ℚ) := Nat.cast_nonneg _
  have h3 : (connectedMatchingNumber G : ℚ) * 3 ≤ (connectedMatchingNumber G : ℚ) * q :=
    mul_le_mul_of_nonneg_left hq3 hc0
  linarith

/-- Füredi–Gyárfás–Simonyi's linear connected-matching conjecture, in its original form
for graphs with independence number exactly two, is false. -/
theorem no_linear_connected_matching_alpha_two :
    ¬ ∃ c : ℚ, 0 < c ∧ ∃ m₀ : ℕ, ∀ m : ℕ, m₀ ≤ m → ∀ G : SimpleGraph (Fin m),
      G.indepNum = 2 → c * m ≤ (connectedMatchingNumber G : ℚ) := by
  rintro ⟨c, hc, m₀, h⟩
  obtain ⟨q, hq⟩ := exists_nat_gt (1/c + 3)
  have hc1 : (0:ℚ) < 1/c := by positivity
  have hq1 : 1/c < (q:ℚ) := by linarith
  have hq3 : 3 ≤ q := by
    have h3 : (3:ℚ) ≤ q := by linarith
    exact_mod_cast h3
  obtain ⟨m, hm, G, hG, hcm⟩ := exists_graphs_q_eq q hq3 m₀
  have hm5 : 5 ≤ m := (le_max_right _ _).trans hm
  have h1 := h m ((le_max_left _ _).trans hm) G hG
  have hmpos : (0:ℚ) < m := by exact_mod_cast (show 0 < m by omega)
  have hqpos : (0:ℚ) < q := by linarith
  have hcq : 1 < q*c := (div_lt_iff₀ hc).mp hq1
  have hcm' : (connectedMatchingNumber G : ℚ) * q < m := (lt_div_iff₀ hqpos).mp hcm
  nlinarith [mul_le_mul_of_nonneg_right h1 hqpos.le]

/-- Seymour's problem, for graphs with independence number exactly two, has a negative
answer: no `ε > 0` gives `K_t` minors with `t ≥ (1/3 + ε)·|V(G)|` for all large graphs. -/
theorem no_seymour_improvement_alpha_two :
    ¬ ∃ ε : ℚ, 0 < ε ∧ ∃ m₀ : ℕ, ∀ m : ℕ, m₀ ≤ m → ∀ G : SimpleGraph (Fin m),
      G.indepNum = 2 → (1/3 + ε) * m ≤ (LinearListHadwiger.hadwigerNumber G : ℚ) := by
  rintro ⟨ε, hε, m₀, h⟩
  obtain ⟨q, hq⟩ := exists_nat_gt (8/(3*ε) + 3)
  have he1 : (0:ℚ) < 8/(3*ε) := by positivity
  have hq1 : 8/(3*ε) < (q:ℚ) := by linarith
  have hq3 : 3 ≤ q := by
    have h3 : (3:ℚ) ≤ q := by linarith
    exact_mod_cast h3
  obtain ⟨m, hm, G, hG, hcm⟩ := exists_graphs_q_eq q hq3 (max m₀ q)
  have hm5 : 5 ≤ m := (le_max_right _ _).trans hm
  have hmq : q ≤ m := (le_max_right _ _).trans ((le_max_left _ _).trans hm)
  have hm0 : m₀ ≤ m := (le_max_left _ _).trans ((le_max_left _ _).trans hm)
  have : NeZero m := ⟨by omega⟩
  have hx := full_matching_minor_proposition (Fin m) G
  dsimp only at hx
  rw [Fintype.card_fin] at hx
  have hmb := hx.1
  have h1 := h m hm0 G hG
  have hmpos : (0:ℚ) < m := by exact_mod_cast (show 0 < m by omega)
  have hqpos : (0:ℚ) < q := by linarith
  have hmqQ : (q:ℚ) ≤ m := by exact_mod_cast hmq
  have hεq : 8 < 3*ε*q := by
    have := (div_lt_iff₀ (by positivity : (0:ℚ) < 3*ε)).mp hq1
    linarith
  have hcm' : (connectedMatchingNumber G : ℚ) * q < m := (lt_div_iff₀ hqpos).mp hcm
  have k2 : 3*ε*m ≤ 4*(connectedMatchingNumber G : ℚ) + 2 := by linarith
  have k3 : 3*ε*m*q ≤ (4*(connectedMatchingNumber G : ℚ) + 2)*q :=
    mul_le_mul_of_nonneg_right k2 hqpos.le
  have k4 : 8*(m:ℚ) < 3*ε*q*m := by nlinarith
  nlinarith

end HadwigerCounterexample

end

end OAI

#print axioms OAI.HadwigerCounterexample.cm_large_of_indepNum_le_one
#print axioms OAI.HadwigerCounterexample.exists_graphs_q_eq
#print axioms OAI.HadwigerCounterexample.no_linear_connected_matching_alpha_two
#print axioms OAI.HadwigerCounterexample.no_seymour_improvement_alpha_two
