#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
WESTFALL V22 -- one-command verification driver.

    python verify.py                 full run (needs git + a Lean toolchain via elan; hours)
    python verify.py --selftest      offline logic tests of this script only (seconds)
    python verify.py --stages static fetch-and-audit without Lean (minutes)

Standard library only; Python >= 3.8.

WHAT THIS SCRIPT DOES NOT DO
  * It never runs `lake update`.  Dependencies come from the committed lake-manifest.json, and the
    script fails if that file or any package revision differs from the pins in MANIFEST.json.
  * It never edits the upstream checkout or the six frozen PFRS sources.
  * It never reports a stage as PASS unless the underlying command ran and its output was parsed.
    A stage that could not run is UNAVAILABLE or SKIPPED, never PASS.

EXIT CODES
  0  every mandatory stage passed and the requested kernel replay passed
  1  a mandatory stage FAILED (hash mismatch, wrong pin, compile error, nonstandard axiom, ...)
  2  environment problem (git/lean/lake missing or wrong version, network): nothing was verified
  3  all mandatory stages passed but kernel replay was not run (--kernel none) or not available

STATUS OF THE LEAN-DRIVING STAGES (read this)
  Stages S0-S4 were executed for real.  S0b (toolchain check) and S10a (Mathlib-free kernel-checker
  controls, `--stages controls`) were additionally executed against the real Lean 4.34.1 release
  binaries (see docs/REAL_TOOLCHAIN_LOG.txt).  Stages S5-S10 (dependency restore, Mathlib cache, build,
  compile of the six modules, statement audit, replay of the real modules) are written from the Lean
  4.34.1 sources and documentation; what has been exercised for real is listed in docs/VERIFICATION_REPORT.md.
  The mock toolchain (tests/mock_toolchain_test.py) checks control flow, parsing and exit codes, NOT Lean.
  Any unexpected failure of an unexercised stage is reported with its log; it is not hidden.
"""
import argparse
import concurrent.futures as cf
import hashlib
import json
import os
import platform
import re
import shlex
import shutil
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
EXIT_OK, EXIT_FAIL, EXIT_ENV, EXIT_INCOMPLETE = 0, 1, 2, 3
STANDARD_AXIOMS = {"propext", "Classical.choice", "Quot.sound"}

# --------------------------------------------------------------------------- utilities

def sha256_bytes(b):
    return hashlib.sha256(b).hexdigest()


def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def strip_lean_comments(text):
    """Remove Lean block comments (nested), line comments and string literals."""
    out, i, n = [], 0, len(text)
    while i < n:
        c = text[i]
        if text.startswith("/-", i):
            depth, i = 1, i + 2
            while i < n and depth:
                if text.startswith("/-", i):
                    depth, i = depth + 1, i + 2
                elif text.startswith("-/", i):
                    depth, i = depth - 1, i + 2
                else:
                    if text[i] == "\n":
                        out.append("\n")
                    i += 1
        elif text.startswith("--", i):
            while i < n and text[i] != "\n":
                i += 1
        elif c == '"':
            i += 1
            while i < n and text[i] != '"':
                i += 2 if text[i] == "\\" else 1
            i += 1
            out.append('""')
        else:
            out.append(c)
            i += 1
    return "".join(out)


def parse_imports(text):
    """Imports of a Lean file (header only), after comment stripping."""
    mods = []
    for line in strip_lean_comments(text).splitlines():
        s = line.strip()
        if not s:
            continue
        m = re.match(r"^(?:public\s+|meta\s+)*import\s+(?:all\s+)?(.+)$", s)
        if m:
            mods += m.group(1).split()
            continue
        if s in ("prelude", "module"):
            continue
        break
    return mods


FORBIDDEN = {  # construct -> regex (applied to comment/string-stripped source)
    "sorry": r"\bsorry\b",
    "admit": r"\badmit\b",
    "axiom_decl": r"(?m)^\s*(?:private\s+|protected\s+|noncomputable\s+)*axiom\b",
    "native_decide": r"\bnative_decide\b",
    "ofReduceBool": r"\bofReduceBool\b",
    "unsafe": r"\bunsafe\b",
    "implemented_by": r"\bimplemented_by\b",
    "extern": r"\bextern\b",
    "csimp": r"\bcsimp\b",
    "skipKernelTC": r"\bskipKernelTC\b",   # `set_option debug.skipKernelTC true` lets a false declaration into an olean
}
WATCH = {  # informational: metaprogramming/environment-affecting commands
    "macro_elab_syntax": r"(?m)^\s*(?:local\s+|scoped\s+)?(?:macro|macro_rules|elab|elab_rules|syntax|notation|infix|infixl|infixr|prefix|postfix)\b",
    "run_cmd_meta": r"\b(?:run_cmd|run_meta|run_elab|initialize|builtin_initialize)\b",
    "attribute_simp_global": r"(?m)^\s*attribute\s*\[",
    "set_option_debug": r"\bset_option\s+debug\.",
}


def scan_source(text):
    s = strip_lean_comments(text)
    return ({k: len(re.findall(rx, s)) for k, rx in FORBIDDEN.items()},
            {k: len(re.findall(rx, s)) for k, rx in WATCH.items()})


AX_RE = re.compile(r"'([^']+)' depends on axioms: \[(.*?)\]", re.S)
NOAX_RE = re.compile(r"'([^']+)' does not depend on any axioms")


def parse_axioms(text):
    res = {}
    for m in AX_RE.finditer(text):
        parts = re.split(r",\s*(?![^{}]*\})", m.group(2).replace("\n", " "))
        res[m.group(1)] = [re.sub(r"\.\{[^}]*\}$", "", a.strip()) for a in parts if a.strip()]
    for m in NOAX_RE.finditer(text):
        res[m.group(1)] = []
    return res


LEAN_VER_RE = re.compile(r"Lean \(version (\d+\.\d+\.\d+)[^,]*, ([^,]+), commit ([0-9a-f]{40}),")


def parse_lean_version(text):
    m = LEAN_VER_RE.search(text)
    return {"version": m.group(1), "platform": m.group(2).strip(), "commit": m.group(3)} if m else None


def compute_closure(roots, resolve):
    """resolve(mod)-> (path|None). Returns (seen_local, external_modules, edges)."""
    seen, ext, edges, stack = set(), set(), {}, list(roots)
    while stack:
        m = stack.pop()
        if m in seen:
            continue
        seen.add(m)
        p = resolve(m)
        if p is None:
            ext.add(m)
            continue
        imps = parse_imports(Path(p).read_text(encoding="utf-8"))
        edges[m] = imps
        stack.extend(imps)
    return seen, ext, edges


def order_violations(order, edges_local):
    """Return [(module, dependency)] where a PFRS module is listed before a PFRS module it imports,
    plus modules missing from / extra in `order`.  Empty list == `order` is a valid build order."""
    pos = {m: i for i, m in enumerate(order)}
    bad = []
    for m in sorted(set(edges_local) ^ set(order)):
        bad.append((m, "listed in only one of {build order, import graph}"))
    for m, imps in edges_local.items():
        for d in imps:
            if d in edges_local and m in pos and d in pos and pos[d] >= pos[m]:
                bad.append((m, d))
    return bad


# --------------------------------------------------------------------------- ledger

class Ledger:
    def __init__(self, workdir):
        self.rows = []
        self.workdir = Path(workdir)
        self.logdir = self.workdir / "logs"
        self.logdir.mkdir(parents=True, exist_ok=True)
        self.facts = {}
        self._n = 0

    def log_path(self, name):
        self._n += 1
        return self.logdir / ("%02d_%s.log" % (self._n, re.sub(r"[^A-Za-z0-9_.-]", "_", name)))

    def add(self, sid, title, status, detail="", mandatory=True, commands=None):
        row = {"id": sid, "title": title, "status": status, "mandatory": mandatory,
               "detail": detail, "commands": commands or []}
        self.rows.append(row)
        flag = "" if mandatory else " (informational)"
        print("[%-11s] %s %s%s" % (status, sid, title, flag), flush=True)
        for line in str(detail).splitlines()[:12]:
            print("              " + line, flush=True)
        return row

    def failed(self):
        return [r for r in self.rows if r["mandatory"] and r["status"] == "FAIL"]

    def env_problems(self):
        return [r for r in self.rows if r["mandatory"] and r["status"] == "ENV"]


def run_cmd(cmd, cwd, log, env=None, timeout=None, heartbeat=60):
    """Run a command, stream its output to `log`.  Returns (rc, seconds).  rc=127 if not found."""
    t0 = time.time()
    shown = cmd if isinstance(cmd, str) else " ".join(shlex.quote(str(c)) for c in cmd)
    with open(str(log), "w", encoding="utf-8", errors="replace") as f:
        f.write("$ %s\n# cwd=%s\n" % (shown, cwd))
        f.flush()
        try:
            p = subprocess.Popen(cmd, cwd=str(cwd), env=env, stdout=f, stderr=subprocess.STDOUT,
                                 shell=isinstance(cmd, str))
        except FileNotFoundError as e:
            f.write("[not found] %s\n" % e)
            return 127, time.time() - t0
        stop = threading.Event()

        def beat():
            while not stop.wait(heartbeat):
                print("    ... %ds elapsed (%s)" % (time.time() - t0, Path(str(log)).name), flush=True)
        th = threading.Thread(target=beat, daemon=True)
        th.start()
        try:
            rc = p.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            p.kill(); rc = -9; f.write("\n[TIMEOUT after %s s]\n" % timeout)
        finally:
            stop.set()
    return rc, time.time() - t0


def read_log(log, tail=None):
    t = Path(str(log)).read_text(encoding="utf-8", errors="replace")
    return t if tail is None else "\n".join(t.splitlines()[-tail:])


def strip_index_lines(text):
    """git diff text without its `index <abbrev>..<abbrev>` lines (patch files abbreviate them inconsistently)."""
    return "\n".join(l for l in text.splitlines() if not l.startswith("index "))


def probe_host(url, timeout=20):
    """(reachable, detail).  Reachable = some HTTP answer came back from the host itself, even an error status;
    a refused/blocked connection (e.g. a proxy answering the CONNECT with 403) is NOT reachable."""
    try:
        req = urllib.request.Request(url, method="HEAD")
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return True, "HTTP %s" % r.status
    except urllib.error.HTTPError as e:
        return True, "HTTP %s from the host" % e.code
    except Exception as e:  # noqa: BLE001
        return False, "%s: %s" % (type(e).__name__, e)


NET_FAIL_RE = re.compile(r"CONNECT tunnel failed|Could not resolve host|Failed to connect|Connection (?:refused|timed out)|"
                         r"curl exit code: (?:6|7|28|35|56)|download failed", re.I)


def cmd_record(cmd, rc, secs, log):
    return {"cmd": cmd if isinstance(cmd, str) else " ".join(shlex.quote(str(c)) for c in cmd),
            "exit": rc, "seconds": round(secs, 1), "log": str(log)}


# --------------------------------------------------------------------------- stages

def load_manifest(path):
    m = json.loads(Path(path).read_text(encoding="utf-8"))
    m["_sha256"] = sha256_file(path)
    return m


def stage_sources(L, man):
    """S1: the frozen PFRS sources are byte-identical to the pinned hashes and free of forbidden constructs."""
    bad, notes = [], []
    for s in man["sources"]:
        p = HERE / s["path"]
        if not p.exists():
            bad.append("%s missing" % s["path"]); continue
        h = sha256_file(p)
        if h != s["sha256"]:
            bad.append("%s sha256 %s != pinned %s" % (s["path"], h, s["sha256"]))
        forb, _watch = scan_source(p.read_text(encoding="utf-8"))
        hit = {k: v for k, v in forb.items() if v}
        if hit:
            bad.append("%s contains forbidden constructs %s" % (s["path"], hit))
    stale = []
    for s in man["sources"]:
        t = (HERE / s["path"]).read_text(encoding="utf-8") if (HERE / s["path"]).exists() else ""
        if re.search(r"NOT COMPILED|SOURCE ONLY", t):
            stale.append(s["module"])
    if stale:
        notes.append("NOTE: stale 'NOT COMPILED' header text still present in " + ", ".join(stale) +
                     " (comment only; sources are frozen, so hashes include it)")
    L.add("S1", "frozen WESTFALL sources: sha256 + forbidden-construct scan",
          "FAIL" if bad else "PASS", "\n".join(bad + notes) or "6/6 hashes match; no sorry/admit/axiom/native_decide/unsafe/extern",
          True)
    return not bad


def _raw_fetch(owner_repo, commit, path, tries=4):
    url = "https://raw.githubusercontent.com/%s/%s/%s" % (owner_repo, commit, path)
    for _ in range(tries):
        try:
            with urllib.request.urlopen(url, timeout=60) as r:
                return r.read()
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return None
        except Exception:
            time.sleep(1)
    raise RuntimeError("could not fetch " + url)


def _owner_repo(url):
    m = re.search(r"github\.com[/:]([^/]+/[^/.]+)", url)
    if not m:
        raise ValueError("cannot parse owner/repo from " + url)
    return m.group(1)


def stage_fetch(L, man, args):
    """S2: obtain the pinned upstream tree. Returns the path of `<checkout>/lean` or None."""
    up = man["upstream"]
    work = Path(args.workdir)
    if args.fetch_mode == "raw":
        root = work / "upstream_raw"
        need = man["upstream"]["closure_files"]
        owner_repo = _owner_repo(up["url"])
        bad = []
        try:
            with cf.ThreadPoolExecutor(12) as ex:
                results = list(ex.map(lambda p: (p, _raw_fetch(owner_repo, up["commit"], p)), need))
        except RuntimeError as e:
            L.add("S2", "fetch pinned upstream (RAW mode)", "ENV", "%s\nNothing downstream was run." % e, True)
            return None
        for p, b in results:
            if b is None:
                bad.append("404 " + p); continue
            q = root / p
            q.parent.mkdir(parents=True, exist_ok=True)
            q.write_bytes(b)
        L.add("S2", "fetch pinned upstream (RAW file mode: closure files only; cannot build)",
              "FAIL" if bad else "PASS",
              "commit %s, %d files fetched from raw.githubusercontent.com%s" %
              (up["commit"], len(need) - len(bad), ("; " + "; ".join(bad[:5])) if bad else ""), True)
        return None if bad else root / "lean"

    if args.upstream_dir:
        co = Path(args.upstream_dir)
        origin = "pre-existing checkout %s" % co
    else:
        co = work / "upstream"
        origin = "fresh clone"
        if not (co / ".git").exists():
            cmds = [
                ["git", "clone", "--filter=blob:none", "--no-checkout", "--sparse", up["url"], str(co)],
                ["git", "-C", str(co), "sparse-checkout", "set", up["lean_subdir"]],
                ["git", "-C", str(co), "checkout", "--detach", up["commit"]],
            ]
            recs = []
            for c in cmds:
                log = L.log_path("fetch")
                rc, secs = run_cmd(c, work, log)
                recs.append(cmd_record(c, rc, secs, log))
                if rc != 0:
                    # Not being able to obtain the pinned tree is an environment problem (network, git), not a
                    # verification failure: nothing was verified, and the exit code (2) says so.
                    L.add("S2", "fetch pinned upstream", "ENV",
                          "command failed (exit %s): %s\n%s\nNothing downstream was run." % (rc, recs[-1]["cmd"], read_log(log, 8)),
                          True, recs)
                    return None
    problems = []
    log = L.log_path("git_head")
    rc, _ = run_cmd(["git", "-C", str(co), "rev-parse", "HEAD"], work, log)
    head = read_log(log).splitlines()[-1].strip() if rc == 0 else "?"
    if head != up["commit"]:
        problems.append("HEAD %s != pinned %s" % (head, up["commit"]))
    log = L.log_path("git_status")
    rc, _ = run_cmd(["git", "-C", str(co), "status", "--porcelain", "--untracked-files=all"], work, log)
    # Lake's own build products (untracked, under lean/.lake/) are expected on a re-run; any tracked-file change,
    # or any other untracked file, is not.
    dirty = [l for l in read_log(log).splitlines()[2:]
             if l.strip() and not l.startswith("?? %s/.lake/" % up["lean_subdir"])]
    if dirty:
        problems.append("working tree not clean (%d entries), e.g. %s" % (len(dirty), dirty[:3]))
    L.add("S2", "pinned upstream checkout (%s): HEAD == commit, tree clean" % origin,
          "FAIL" if problems else "PASS", "; ".join(problems) or "HEAD %s, clean" % head, True)
    if problems:
        return None
    # informational: manuscript claims identical git trees at a second commit
    eq = up.get("equivalent_commit_claim")
    if eq:
        res = []
        for pth in up["tree_paths"]:
            outs = []
            for c in (up["commit"], eq):
                log = L.log_path("treecmp")
                rc, _ = run_cmd(["git", "-C", str(co), "rev-parse", "%s:%s" % (c, pth)], work, log)
                outs.append(read_log(log).splitlines()[-1].strip() if rc == 0 else "unavailable")
            res.append((pth, outs[0] == outs[1] and outs[0] != "unavailable", outs))
        ok = all(r[1] for r in res)
        L.add("S2b", "git trees of closure directories identical at %s (manuscript claim)" % eq[:8],
              "PASS" if ok else "WARN",
              "\n".join("%s %s" % ("same" if r[1] else "DIFF/UNAVAILABLE", r[0]) for r in res), False)
    return co / up["lean_subdir"]


def stage_pins(L, man, lean_dir):
    """S3: manifest/lakefile/toolchain files equal the pinned hashes; Mathlib rev and toolchain agree."""
    up, bad = man["upstream"], []
    for rel, want in up["config_sha256"].items():
        p = lean_dir.parent / rel
        got = sha256_file(p) if p.exists() else "missing"
        if got != want:
            bad.append("%s sha256 %s != pinned %s" % (rel, got, want))
    tc = (lean_dir / "lean-toolchain").read_text().strip() if (lean_dir / "lean-toolchain").exists() else "?"
    if tc != man["toolchain"]["lean_toolchain_file"]:
        bad.append("lean-toolchain %r != %r" % (tc, man["toolchain"]["lean_toolchain_file"]))
    try:
        lm = json.loads((lean_dir / "lake-manifest.json").read_text())
        pk = {p["name"].strip("«»"): p for p in lm["packages"]}
        if pk["mathlib"]["rev"] != man["mathlib"]["rev"]:
            bad.append("mathlib rev %s != pinned %s" % (pk["mathlib"]["rev"], man["mathlib"]["rev"]))
        names = set(pk)
        miss = [n for n in man["manifest_packages"] if n not in names]
        extra = sorted(names - set(man["manifest_packages"]))
        if miss or extra:
            bad.append("package set differs: missing %s extra %s" % (miss, extra))
        for n, rev in man["manifest_revs"].items():
            if n in pk and pk[n]["rev"] != rev:
                bad.append("package %s rev %s != pinned %s" % (n, pk[n]["rev"], rev))
    except Exception as e:  # noqa
        bad.append("cannot parse lake-manifest.json: %s" % e)
    L.add("S3", "pins: lake-manifest/lakefile/lean-toolchain hashes, Mathlib rev, 42 package revs",
          "FAIL" if bad else "PASS", "\n".join(bad) or "all equal to MANIFEST.json", True)
    return not bad


def stage_closure(L, man, lean_dir):
    """S4: static import closure of the six modules; every external import root must be allow-listed."""
    pf = {s["module"]: HERE / s["path"] for s in man["sources"]}
    up_root = lean_dir

    def resolve(m):
        if m in pf:
            return pf[m]
        p = up_root / (m.replace(".", "/") + ".lean")
        return p if p.exists() else None

    seen, ext, edges = compute_closure(list(pf), resolve)
    oai_local = sorted(m for m in seen if m.startswith("OAI.") and m in edges)
    oai_missing = sorted(m for m in ext if m.split(".")[0] in ("OAI", "PFRS"))
    roots = {}
    for m in ext:
        roots.setdefault(m.split(".")[0], 0)
        roots[m.split(".")[0]] += 1
    disallowed = sorted(r for r in roots if r not in man["allowed_import_roots"] and r not in ("OAI", "PFRS"))
    flagged = sorted(set(man["flagged_packages_23"]) & set(roots))
    forb_hits = []
    for m in oai_local:
        forb, _ = scan_source(Path(resolve(m)).read_text(encoding="utf-8"))
        h = {k: v for k, v in forb.items() if v}
        if h:
            forb_hits.append((m, h))
    fp = hashlib.sha256()
    for m in sorted(oai_local):
        fp.update(("%s\t%s\n" % (m, sha256_file(resolve(m)))).encode())
    fingerprint = fp.hexdigest()
    bad = []
    if oai_missing:
        bad.append("OAI modules in the closure not found in checkout: %s" % oai_missing[:5])
    if disallowed:
        bad.append("import roots outside the allow-list: %s" % disallowed)
    if flagged:
        bad.append("closure imports a flagged-package root: %s" % flagged)
    if forb_hits:
        bad.append("forbidden constructs in upstream closure: %s" % forb_hits[:3])
    if len(oai_local) != man["upstream"]["closure_module_count"]:
        bad.append("closure has %d OAI modules, pinned %d" % (len(oai_local), man["upstream"]["closure_module_count"]))
    if fingerprint != man["upstream"]["closure_modules_fingerprint"]:
        bad.append("closure fingerprint %s != pinned %s" % (fingerprint, man["upstream"]["closure_modules_fingerprint"]))
    viol = order_violations(man["build_order"], {m: edges[m] for m in pf})
    if viol:
        bad.append("pinned build order violates import dependencies: %s" % viol)
    direct_external = sorted(ext)
    L.facts["closure"] = {"oai_modules": len(oai_local), "external_direct_modules": len(direct_external),
                          "external_roots": roots, "fingerprint": fingerprint}
    L.add("S4", "static import closure (6 PFRS + %d upstream modules): roots, fingerprint, order" % len(oai_local),
          "FAIL" if bad else "PASS",
          "\n".join(bad) or ("external import roots: %s; none of the 23 flagged packages is imported; "
                             "fingerprint %s" % (dict(sorted(roots.items())), fingerprint[:16])), True)
    return not bad


# ---- Lean-driving stages (S0b, S5..S10): see the status note at the top of this file

def lean_tools(L, man, lean_dir, args):
    """S0b: locate lean/lake/leanchecker for the toolchain selected by lean-toolchain; check version+commit."""
    work = Path(args.workdir)
    log = L.log_path("lean_version")
    rc, secs = run_cmd(["lean", "--version"], lean_dir, log)
    txt = read_log(log)
    if rc != 0:
        L.add("S0b", "Lean toolchain available", "ENV",
              "`lean --version` failed in %s (rc=%s). Install elan "
              "(https://github.com/leanprover/elan) and re-run; elan picks leanprover/lean4:v4.34.1 from "
              "lean-toolchain automatically.\n%s" % (lean_dir, rc, txt[-300:]), True,
              [cmd_record(["lean", "--version"], rc, secs, log)])
        return None
    v = parse_lean_version(txt)
    want = man["toolchain"]
    bad = []
    if not v:
        bad.append("cannot parse `lean --version`: %r" % txt[-200:])
    else:
        if v["version"] != want["version"]:
            bad.append("Lean version %s != pinned %s" % (v["version"], want["version"]))
        if v["commit"] != want["commit"]:
            bad.append("Lean commit %s != pinned %s" % (v["commit"], want["commit"]))
    log2 = L.log_path("lean_prefix")
    rc2, _ = run_cmd(["lean", "--print-prefix"], lean_dir, log2)
    prefix = read_log(log2).splitlines()[-1].strip() if rc2 == 0 else ""
    tools = {"prefix": prefix}
    for t in ("lean", "lake", "leanchecker"):
        p = Path(prefix) / "bin" / t
        tools[t] = str(p) if prefix and p.exists() else None
    if not tools["lean"] or not tools["lake"]:
        bad.append("lean/lake not found under prefix %r" % prefix)
    L.facts["lean_version"] = v
    L.facts["tools"] = tools
    log3 = L.log_path("lake_version")
    run_cmd([tools["lake"] or "lake", "--version"], lean_dir, log3)
    L.facts["lake_version"] = read_log(log3).splitlines()[-1].strip() if (log3).exists() else "?"
    L.add("S0b", "Lean toolchain == pinned version and commit; lake present; leanchecker %s" %
          ("present" if tools.get("leanchecker") else "ABSENT"),
          "FAIL" if bad else "PASS",
          "\n".join(bad) or "%s ; lake: %s ; prefix %s" % (txt.strip().splitlines()[-1], L.facts["lake_version"], prefix), True)
    return None if bad else tools


def lean_env(L, tools, lean_dir, extra=None):
    """LEAN_PATH exactly as `lake env` computes it, optionally with extra roots appended."""
    log = L.log_path("lake_env_leanpath")
    rc, secs = run_cmd([tools["lake"], "env", "printenv", "LEAN_PATH"], lean_dir, log)
    lines = [l for l in read_log(log).splitlines()[2:] if l.strip() and not l.startswith("warning:") and not l.startswith("info:")]
    if rc != 0 or not lines:
        return None, cmd_record([tools["lake"], "env", "printenv", "LEAN_PATH"], rc, secs, log)
    lp = lines[-1].strip()
    if extra:
        lp = lp + os.pathsep + os.pathsep.join(str(e) for e in extra)
    env = dict(os.environ)
    env["LEAN_PATH"] = lp
    return env, cmd_record([tools["lake"], "env", "printenv", "LEAN_PATH"], rc, secs, log)


def stage_deps(L, man, tools, lean_dir):
    """S5: let Lake materialise the packages named in the committed manifest (no update); verify revs."""
    manifest_path = lean_dir / "lake-manifest.json"
    before = sha256_file(manifest_path)
    env, rec = lean_env(L, tools, lean_dir)
    if env is None:
        L.add("S5", "restore pinned dependencies (lake, no update)", "FAIL", "lake env failed:\n" + read_log(rec["log"], 15), True, [rec])
        return None
    after = sha256_file(manifest_path)
    bad = []
    if before != after:
        bad.append("lake-manifest.json CHANGED during dependency restore (%s -> %s)" % (before, after))
    pk_dir = lean_dir / ".lake" / "packages"
    dirty_core, dirty_other, rev_bad, missing = [], [], [], []
    core = set(man["mathlib_dep_packages"]) | {"mathlib"}
    for name, rev in man["manifest_revs"].items():
        d = pk_dir / name
        if not d.exists():
            missing.append(name); continue
        log = L.log_path("pkg_head")
        rc, _ = run_cmd(["git", "-C", str(d), "rev-parse", "HEAD"], lean_dir, log)
        head = read_log(log).splitlines()[-1].strip() if rc == 0 else "?"
        if head != rev:
            rev_bad.append("%s HEAD %s != pinned %s" % (name, head[:12], rev[:12]))
        log = L.log_path("pkg_status")
        rc, _ = run_cmd(["git", "-C", str(d), "status", "--porcelain", "--untracked-files=no"], lean_dir, log)
        d_lines = [x for x in read_log(log).splitlines()[2:] if x.strip()]
        if d_lines:
            (dirty_core if name in core else dirty_other).append((name, len(d_lines), d_lines[:3]))
    if missing:
        bad.append("packages missing after restore: %s" % missing)
    if rev_bad:
        bad.append("package revisions differ from pins: %s" % rev_bad)
    if dirty_core:
        bad.append("TRACKED-FILE CHANGES in a package of the import closure: %s" % dirty_core)
    L.facts["pkg_dirty_non_closure"] = dirty_other
    L.add("S5", "restore pinned dependencies without update: manifest unchanged, 42 revs == pins, closure packages clean",
          "FAIL" if bad else "PASS", "\n".join(bad) or "manifest sha256 unchanged; all package HEADs equal the pins", True, [rec])
    # S5b: are the tracked-file changes outside the closure exactly the upstream's declared compatibility patches?
    groups = man.get("patch_groups", {})
    patched_all = set(groups.get("pre_resolution", [])) | set(groups.get("post_update", []))
    exact, other = [], []
    for name, cnt, _ in dirty_other:
        pf = lean_dir / "patches" / (name + "-lean4341.patch")
        d = pk_dir / name
        ok = False
        if pf.exists():
            r = subprocess.run(["git", "-C", str(d), "diff", "--full-index", "HEAD"], stdout=subprocess.PIPE,
                               stderr=subprocess.DEVNULL)
            got = strip_index_lines(r.stdout.decode("utf-8", "replace"))
            ok = r.returncode == 0 and got == strip_index_lines(pf.read_text(encoding="utf-8", errors="replace"))
        (exact if ok else other).append((name, cnt))
    clean_patched = sorted(n for n in patched_all if n not in {x[0] for x in dirty_other})
    L.facts["patch_check"] = {"exact": exact, "other": other, "patched_but_clean": clean_patched}
    if dirty_other or clean_patched:
        detail = ("%d packages outside the closure carry tracked-file changes; %d of them are byte-for-byte upstream's own "
                  "compatibility patch (lean/patches/<pkg>-lean4341.patch, index-line abbreviation ignored): %s."
                  % (len(dirty_other), len(exact), sorted(n for n, _ in exact)))
        if other:
            detail += "\nNOT explained by a patch: %s" % other
        if clean_patched:
            detail += ("\n%d further packages have a declared patch that is applied only by upstream's `post_update` hook "
                       "(i.e. after `lake update`, which this script never runs), so they are clean here: %s"
                       % (len(clean_patched), clean_patched))
        L.add("S5b", "tracked-file changes outside the closure (the source of Lake's 'has local changes' warnings) vs upstream's declared patches",
              "WARN" if other else "INFO", detail, False)
    else:
        L.add("S5b", "tracked-file changes outside the closure", "INFO", "none", False)
    return None if bad else env


def stage_leanpath_shadow(L, env):
    """S5c: any .olean relative path provided by two different LEAN_PATH roots."""
    seen, dup = {}, []
    for root in env["LEAN_PATH"].split(os.pathsep):
        r = Path(root)
        if not r.is_dir():
            continue
        for p in r.rglob("*.olean"):
            rel = str(p.relative_to(r))
            if rel in seen and seen[rel] != root:
                dup.append((rel, seen[rel], root))
            else:
                seen.setdefault(rel, root)
    L.add("S5c", "no .olean path provided by two different LEAN_PATH roots (shadowing; only built oleans are scanned)",
          "PASS" if not dup else "WARN", "%d oleans scanned; duplicates: %s" % (len(seen), dup[:5]) if dup else "%d oleans scanned, no duplicates" % len(seen), False)


def stage_mathlib_cache(L, man, tools, lean_dir, env, args):
    if args.mathlib_cache != "official":
        L.add("S6", "Mathlib oleans", "SKIP", "--mathlib-cache none: Mathlib will be compiled from source by the build stage", False); return True
    host = man.get("mathlib_cache_host")
    if host:                      # fail fast instead of letting curl retry thousands of denied downloads
        reach, detail = probe_host(host)
        if not reach:
            L.add("S6", "Mathlib official olean cache (`lake exe cache get`)", "ENV",
                  "the cache host %s cannot be reached from this machine (%s). Nothing was downloaded. Re-run where it is "
                  "reachable, or use --mathlib-cache none (compiles all of Mathlib's needed closure from source: many hours)."
                  % (host, detail), True)
            return False
    cmd = [tools["lake"], "exe", "cache", "get"]
    log = L.log_path("cache_get")
    rc, secs = run_cmd(cmd, lean_dir, log, env=env, timeout=args.timeout)
    out = read_log(log)
    status = "PASS" if rc == 0 else ("ENV" if NET_FAIL_RE.search(out) else "FAIL")
    L.add("S6", "Mathlib official olean cache (`lake exe cache get`)", status,
          "exit %s\n%s" % (rc, "\n".join(out.replace("\r", "\n").splitlines()[-6:])), True, [cmd_record(cmd, rc, secs, log)])
    return rc == 0


def stage_build_upstream(L, man, tools, lean_dir, env, args):
    target = man["upstream"]["build_target"]
    recs, rc = [], 1
    for t in ("+" + target, target):     # `+Module` is Lake's unambiguous module spelling; the plain name resolved to a different job set on the real Lake
        cmd = [tools["lake"], "build", t]
        log = L.log_path("lake_build")
        rc, secs = run_cmd(cmd, lean_dir, log, env=env, timeout=args.timeout)
        recs.append(cmd_record(cmd, rc, secs, log))
        out = read_log(log)
        if rc == 0 or not re.search(r"unknown (target|package)|invalid (target|module)", out, re.I):
            break
    st = "PASS" if rc == 0 else "FAIL"
    L.add("S7", "build the upstream import closure from source (lake build %s)" % target, st,
          "exit %s\n%s" % (rc, read_log(recs[-1]["log"], 6)), True, recs)
    return rc == 0


def stage_compile(L, man, tools, lean_dir, env0, args):
    """S8: compile the six modules in dependency order with `lean -R <src> -o <build>/PFRS/X.olean`."""
    work = Path(args.workdir)
    srcroot = HERE / "src"
    buildroot = work / "build"
    (buildroot / "PFRS").mkdir(parents=True, exist_ok=True)
    env = dict(env0)
    env["LEAN_PATH"] = env0["LEAN_PATH"] + os.pathsep + str(buildroot)
    recs, bad = [], []
    for mod in man["build_order"]:
        short = mod.split(".", 1)[1]
        src = srcroot / "PFRS" / (short + ".lean")
        out = buildroot / "PFRS" / (short + ".olean")
        if out.exists():
            out.unlink()
        cmd = [tools["lean"], "-R", str(srcroot), "-o", str(out), str(src)]
        log = L.log_path("compile_" + short)
        rc, secs = run_cmd(cmd, lean_dir, log, env=env, timeout=args.timeout)
        recs.append(cmd_record(cmd, rc, secs, log))
        text = read_log(log)
        errs = [l for l in text.splitlines() if re.search(r":\d+:\d+: error", l) or l.startswith("error:")]
        sorry = [l for l in text.splitlines() if "declaration uses 'sorry'" in l or "sorryAx" in l]
        if rc != 0 or errs or sorry or not out.exists():
            bad.append("%s: exit %s, %d error lines, %d sorry lines, olean %s" %
                       (mod, rc, len(errs), len(sorry), "present" if out.exists() else "MISSING"))
            break
        print("    compiled %s in %.0fs" % (mod, secs), flush=True)
    L.add("S8", "compile the six PFRS modules in dependency order (lean -R src -o build/PFRS/X.olean)",
          "FAIL" if bad else "PASS", "\n".join(bad) or "6/6 compiled, 0 errors, no sorry, .olean written for each", True, recs)
    return (not bad), env


def stage_audit(L, man, tools, lean_dir, env, args):
    """S9: statement pins + `#print axioms`, from the shipped lean/WestfallAudit.lean."""
    src = HERE / "lean" / "WestfallAudit.lean"
    want = man["audit"]["sha256"]
    got = sha256_file(src)
    if got != want:
        L.add("S9", "statement pins and axiom audit", "FAIL", "WestfallAudit.lean sha256 %s != pinned %s" % (got, want), True)
        return False
    cmd = [tools["lean"], "-R", str(HERE / "lean"), str(src)]
    log = L.log_path("audit")
    rc, secs = run_cmd(cmd, lean_dir, log, env=env, timeout=args.timeout)
    text = read_log(log)
    ax = parse_axioms(text)
    bad = []
    if rc != 0 or re.search(r":\d+:\d+: error", text):
        errs = [l for l in text.splitlines() if re.search(r":\d+:\d+: error", l)]
        bad.append("lean exit %s; %d error lines (a failed pin means the proved statement is NOT the pinned one, "
                   "or the pin text has a transcription error -- inspect):\n  %s" % (rc, len(errs), "\n  ".join(errs[:6])))
    for name in man["audit"]["axiom_targets"]:
        if name not in ax:
            bad.append("no axiom line printed for %s" % name)
        elif not set(ax[name]) <= STANDARD_AXIOMS:
            bad.append("%s depends on non-standard axioms %s" % (name, sorted(set(ax[name]) - STANDARD_AXIOMS)))
    L.facts["axioms"] = ax
    L.add("S9", "statement pins compile; #print axioms for %d targets all within {propext, Classical.choice, Quot.sound}" %
          len(man["audit"]["axiom_targets"]), "FAIL" if bad else "PASS",
          "\n".join(bad) or "; ".join("%s:%s" % (k.split(".")[-1], len(v)) for k, v in sorted(ax.items()))[:400], True,
          [cmd_record(cmd, rc, secs, log)])
    return not bad


def stage_kernel_controls(L, man, tools, args):
    """S10a: Mathlib-free proof that THIS leanchecker can detect a forged declaration.
       lean/KernelControl/Good.lean (honest) must be accepted; lean/KernelControl/Forged.lean (inserts
       `kc_forged : False` with the kernel check disabled) must be rejected, with the output naming kc_forged.
       Needs only the toolchain: no Mathlib, no network.  Without it a silent `exit 0` from leanchecker on the real
       modules would not show that the tool is able to say no."""
    lc = tools.get("leanchecker")
    if not lc:
        L.add("S10a", "leanchecker detects a forged declaration (control)", "UNAVAILABLE",
              "no leanchecker binary under %s/bin" % tools["prefix"], False)
        return "unavailable"
    kc = man.get("kernel_controls") or {}
    bad, recs = [], []
    for rel, want in sorted((kc.get("files") or {"<missing in manifest>": ""}).items()):
        p = HERE / rel
        if not p.exists() or sha256_file(p) != want:
            bad.append("%s missing or sha256 differs from MANIFEST.json" % rel)
    if bad:
        L.add("S10a", "leanchecker detects a forged declaration (control)", "FAIL", "\n".join(bad), True)
        return "fail"
    work = Path(args.workdir) / "kernel_controls"
    build = work / "build"
    (build / "KernelControl").mkdir(parents=True, exist_ok=True)
    env = dict(os.environ)
    env["LEAN_PATH"] = os.pathsep.join([str(Path(tools["prefix"]) / "lib" / "lean"), str(build)])
    env["LEAN_SYSROOT"] = tools["prefix"]
    srcroot = HERE / "lean"
    notes = []
    for mod in ("Good", "Forged"):
        out = build / "KernelControl" / (mod + ".olean")
        if out.exists():
            out.unlink()
        cmd = [tools["lean"], "-R", str(srcroot), "-o", str(out), str(srcroot / "KernelControl" / (mod + ".lean"))]
        log = L.log_path("kc_compile_" + mod)
        rc, secs = run_cmd(cmd, work, log, env=env, timeout=args.timeout)
        recs.append(cmd_record(cmd, rc, secs, log))
        text = read_log(log)
        if rc != 0 or not out.exists():
            bad.append("control module KernelControl.%s did not compile (exit %s, olean %s):\n%s" %
                       (mod, rc, "present" if out.exists() else "MISSING", "\n".join(text.splitlines()[-4:])))
        elif mod == "Forged" and "'kc_forged' does not depend on any axioms" in text:
            notes.append("#print axioms calls the forged declaration axiom-free (as designed: an axiom audit cannot see it)")

    def check(label, argl):
        cmd = [lc] + argl
        log = L.log_path("kc_checker_" + label)
        rc, secs = run_cmd(cmd, work, log, env=env, timeout=args.timeout)
        recs.append(cmd_record(cmd, rc, secs, log))
        return rc, read_log(log)

    if not bad:
        rc, out = check("good", ["KernelControl.Good"])
        if rc != 0:
            bad.append("leanchecker rejected the HONEST control module (exit %s): %s" % (rc, out[-200:]))
        rc, out = check("forged", ["KernelControl.Forged"])
        if rc == 0:
            bad.append("leanchecker ACCEPTED the forged module (exit 0): it cannot detect environment tampering here")
        elif "kc_forged" not in out:
            bad.append("leanchecker rejected the forged module (exit %s) but not for the planted declaration "
                       "(output does not name kc_forged): %s" % (rc, out[-300:]))
        else:
            notes.append("non-fresh replay rejects KernelControl.Forged (exit %s, names kc_forged)" % rc)
        if args.kernel in ("fresh", "all") and not bad:
            rc, out = check("fresh_good", ["--fresh", "KernelControl.Good"])
            if rc != 0:
                bad.append("--fresh rejected the HONEST control module (exit %s): %s" % (rc, out[-200:]))
            rc, out = check("fresh_forged", ["--fresh", "KernelControl.Forged"])
            if rc == 0 or "kc_forged" not in out:
                bad.append("--fresh did not reject the forged module for the planted declaration (exit %s): %s" % (rc, out[-300:]))
            else:
                notes.append("--fresh replay rejects KernelControl.Forged (exit %s, names kc_forged)" % rc)
    L.add("S10a", "leanchecker accepts an honest module and rejects a forged declaration (Mathlib-free control)",
          "FAIL" if bad else "PASS",
          "\n".join(bad) or "; ".join(notes), True, recs)
    return "fail" if bad else "pass"


def stage_kernel(L, man, tools, lean_dir, env, args, kc_state=None):
    """S10: leanchecker (Lean >= 4.28 ships it).  Invocation derived from the v4.34.1 source, not assumed:
         leanchecker [-v|--verbose] [--fresh] [Module ...]
       * no module argument  => replays EVERY module with the root-package prefix (OAI*): avoid;
       * `--help` is NOT a help flag (it is ignored and the no-argument behaviour runs): never call it;
       * non-fresh: each named module's own declarations are replayed against its (trusted) imports;
       * --fresh <one module>: every constant of the whole import closure is replayed into an empty
         environment (single-threaded; slow).
       It uses the same Lean kernel, so it detects olean tampering / environment hacking, not kernel bugs."""
    if args.kernel == "none":
        L.add("S10", "leanchecker kernel replay", "SKIP", "--kernel none requested; NOT RUN", False)
        return "skipped"
    if not tools.get("leanchecker"):
        L.add("S10", "leanchecker kernel replay", "UNAVAILABLE", "no leanchecker binary under %s/bin" % tools["prefix"], False)
        return "unavailable"
    if kc_state != "pass":
        L.add("S10", "leanchecker replay of the real modules", "FAIL",
              "NOT RUN: the Mathlib-free kernel control (S10a) did not pass, so a leanchecker verdict would not be trustworthy", True)
        return "fail"
    lc = tools["leanchecker"]
    env = dict(env)
    env["LEAN_SYSROOT"] = tools["prefix"]   # leanchecker's findSysroot honours this
    recs, bad = [], []

    def go(label, extra_args, expect_ok=True, timeout=None):
        cmd = [lc] + extra_args
        log = L.log_path("leanchecker_" + label)
        rc, secs = run_cmd(cmd, lean_dir, log, env=env, timeout=timeout or args.timeout)
        recs.append(cmd_record(cmd, rc, secs, log))
        return rc, read_log(log)

    # controls: positive on a tiny upstream module (built in S7), negative on a nonexistent one
    ctl = "OAI.Combinatorics.HadwigerMatching.Definitions"
    rc, _ = go("control_positive", [ctl])
    if rc != 0:
        bad.append("positive control failed: `leanchecker %s` exit %s" % (ctl, rc))
    rc, out = go("control_negative", ["No.Such.Module.V22"])
    if rc == 0:
        bad.append("negative control did not fail: `leanchecker No.Such.Module.V22` exit 0")
    if not bad:
        mods = list(man["build_order"])
        for m in mods:                       # replay each WESTFALL module (non-fresh) one at a time
            rc, out = go("west_" + m.split(".")[1], [m])
            if rc != 0:
                bad.append("%s: leanchecker exit %s" % (m, rc))
                break
        if args.kernel in ("oai", "all") and not bad:
            names, k = man["upstream"]["closure_module_names"], max(1, args.kernel_batch)
            for i in range(0, len(names), k):
                batch = names[i:i + k]
                rc, out = go("oai_batch%03d" % (i // k), batch)
                if rc != 0:
                    bad.append("batch %d (%s ...): leanchecker exit %s; see log for 'found a problem in'" % (i // k, batch[0], rc)); break
        if args.kernel in ("fresh", "all") and not bad:
            rc, out = go("fresh_AllOrders", ["--fresh", "PFRS.AllOrders"])
            if rc != 0:
                bad.append("--fresh PFRS.AllOrders: exit %s" % rc)
    scope = {"west": "6 PFRS modules (non-fresh)", "oai": "6 PFRS + %d upstream modules (non-fresh)" % len(man["upstream"]["closure_module_names"]),
             "fresh": "6 PFRS non-fresh + `--fresh PFRS.AllOrders` (whole closure into an empty environment)",
             "all": "6 PFRS + upstream modules + --fresh PFRS.AllOrders"}[args.kernel]
    L.add("S10", "leanchecker replay, scope: " + scope, "FAIL" if bad else "PASS",
          "\n".join(bad) or "all invocations exited 0; positive and negative controls behaved; SAME KERNEL (not an independent implementation)",
          True, recs)
    return "fail" if bad else "pass"


# --------------------------------------------------------------------------- report

def write_report(L, man, args, started, overall, code):
    work = Path(args.workdir)
    nr = not_reached(L, args)
    rep = {"overall": overall, "exit_code": code, "stages_not_reached": nr, "started": started, "finished": time.strftime("%Y-%m-%d %H:%M:%S"),
           "manifest_sha256": man["_sha256"], "manifest_path": str(args.manifest),
           "python": sys.version.split()[0], "platform": platform.platform(), "stages": L.rows, "facts": L.facts,
           "arguments": vars(args)}
    (work / "report.json").write_text(json.dumps(rep, indent=1, default=str), encoding="utf-8")
    lines = ["# WESTFALL V22 verification report", "", "Overall: **%s** (exit code %d)" % (overall, code), "",
             "manifest sha256: `%s`" % man["_sha256"], "platform: %s" % platform.platform(), "",
             "| stage | status | mandatory | title |", "|---|---|---|---|"]
    for r in L.rows:
        lines.append("| %s | %s | %s | %s |" % (r["id"], r["status"], "yes" if r["mandatory"] else "no", r["title"].replace("|", "/")))
    lines += ["", "Stages not reached in this run: %s" % (", ".join(nr) if nr else "none"), ""]
    lines += ["", "## Trust base and limitations (always printed)", ""]
    lines += ["- Mathlib/Batteries/etc. oleans come from the official Mathlib cache unless `--mathlib-cache none` was used.",
              "- leanchecker uses the same Lean kernel: it is a replay/anti-tampering check, not an independent kernel implementation.",
              "- Compilation success is not mathematical novelty or refereeing; see docs/ for the statement audit.",
              "- Existence theorems only: no explicit N0(q) is claimed or checked."]
    (work / "REPORT.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def expected_stage_ids(args):
    if args.stages == "static":
        return ["S1", "S2", "S3", "S4"]
    if args.stages == "controls":
        return ["S0b", "S10a"]
    ids = ["S1", "S2", "S3", "S4", "S0b", "S5", "S6", "S7", "S8", "S9"]
    if args.kernel != "none":
        ids = ids[:5] + ["S10a"] + ids[5:] + ["S10"]
    return ids


def not_reached(L, args):
    present = {r["id"] for r in L.rows}
    return [x for x in expected_stage_ids(args) if x not in present]


def classify(L, kernel_state, args, kc_state=None):
    if L.failed():
        return "VERIFICATION FAILED (mandatory stage failed)", EXIT_FAIL
    if L.env_problems():
        return "NOT VERIFIED: environment problem (see the ENV row; the stages listed as not reached did not run)", EXIT_ENV
    if args.stages == "controls":
        if kc_state == "pass":
            return ("KERNEL-CHECKER CONTROLS PASSED: leanchecker accepted an honest module and rejected a forged declaration. "
                    "Nothing about PFRS or the upstream development was checked"), EXIT_INCOMPLETE
        return "KERNEL-CHECKER CONTROLS NOT RUN (leanchecker unavailable)", EXIT_INCOMPLETE
    if args.stages == "static":
        return "STATIC STAGES PASSED (no Lean was run; this is NOT a compilation or kernel verification)", EXIT_INCOMPLETE
    if kernel_state in ("skipped", "unavailable", None):
        return "ALL MANDATORY STAGES PASSED; KERNEL REPLAY NOT RUN", EXIT_INCOMPLETE
    if kernel_state == "pass":
        return "ALL MANDATORY STAGES PASSED INCLUDING KERNEL REPLAY (see limitations)", EXIT_OK
    return "VERIFICATION FAILED (kernel replay)", EXIT_FAIL


# --------------------------------------------------------------------------- main

def main(argv=None):
    ap = argparse.ArgumentParser(description="WESTFALL V22 verification driver")
    ap.add_argument("--workdir", default=str(Path.cwd() / "westfall_verify_work"))
    ap.add_argument("--manifest", default=str(HERE / "MANIFEST.json"))
    ap.add_argument("--stages", choices=["all", "static", "controls"], default="all",
                    help="static = S1-S4 only (no Lean needed); controls = S0b + S10a only (Lean toolchain, no Mathlib, no network)")
    ap.add_argument("--fetch-mode", choices=["git", "raw"], default="git",
                    help="raw = fetch only the closure files via raw.githubusercontent.com (static stages only)")
    ap.add_argument("--upstream-dir", help="use an existing upstream checkout (still verified: HEAD, clean tree)")
    ap.add_argument("--mathlib-cache", choices=["official", "none"], default="official")
    ap.add_argument("--kernel", choices=["none", "west", "oai", "fresh", "all"], default="west")
    ap.add_argument("--kernel-batch", type=int, default=8, help="modules per leanchecker call in --kernel oai/all (memory vs speed)")
    ap.add_argument("--timeout", type=int, default=None, help="per-command timeout (seconds)")
    ap.add_argument("--selftest", action="store_true")
    args = ap.parse_args(argv)
    if args.selftest:
        sys.path.insert(0, str(HERE / "tests"))
        import unit_tests  # noqa
        return unit_tests.run()
    if args.fetch_mode == "raw" and args.stages != "static":
        ap.error("--fetch-mode raw can only be combined with --stages static")
    started = time.strftime("%Y-%m-%d %H:%M:%S")
    Path(args.workdir).mkdir(parents=True, exist_ok=True)
    man = load_manifest(args.manifest)
    L = Ledger(args.workdir)
    print("WESTFALL V22 verification -- manifest sha256 %s" % man["_sha256"], flush=True)
    if Path(args.manifest).resolve() != (HERE / "MANIFEST.json").resolve():
        print("WARNING: custom manifest in use; this is NOT a verification against the shipped pins.", flush=True)
    py_ok = sys.version_info >= (3, 8)
    L.add("S0a", "python >= 3.8", "PASS" if py_ok else "ENV", sys.version.split()[0], True)
    if args.fetch_mode == "git" and args.stages != "controls":
        log = L.log_path("git_version")
        rc, _ = run_cmd(["git", "--version"], Path.cwd(), log)
        L.add("S0a", "git available", "PASS" if rc == 0 else "ENV", read_log(log).splitlines()[-1] if rc == 0 else "git not found", True)
    kernel_state = kc_state = None
    if args.stages == "controls":
        # no fetch, no Mathlib: toolchain check + forged-declaration control only.  A lean-toolchain file in the
        # working directory lets elan select the pinned toolchain; the pins themselves are re-checked by S0b.
        work = Path(args.workdir)
        (work / "lean-toolchain").write_text(man["toolchain"]["lean_toolchain_file"] + "\n", encoding="utf-8")
        tools = lean_tools(L, man, work, args)
        if tools:
            kc_state = stage_kernel_controls(L, man, tools, args)
    elif stage_sources(L, man) and not L.env_problems():
        lean_dir = stage_fetch(L, man, args)
        if lean_dir is not None and stage_pins(L, man, lean_dir) and stage_closure(L, man, lean_dir) and args.stages == "all":
            tools = lean_tools(L, man, lean_dir, args)
            if tools and args.kernel != "none":
                kc_state = stage_kernel_controls(L, man, tools, args)
            env = stage_deps(L, man, tools, lean_dir) if tools else None
            if env is not None:
                if stage_mathlib_cache(L, man, tools, lean_dir, env, args) and stage_build_upstream(L, man, tools, lean_dir, env, args):
                    stage_leanpath_shadow(L, env)
                    ok, env2 = stage_compile(L, man, tools, lean_dir, env, args)
                    if ok and stage_audit(L, man, tools, lean_dir, env2, args):
                        kernel_state = stage_kernel(L, man, tools, lean_dir, env2, args, kc_state)
    overall, code = classify(L, kernel_state, args, kc_state)
    write_report(L, man, args, started, overall, code)
    nr = not_reached(L, args)
    print("\nRESULT: %s\nstages not reached: %s\nreport: %s\nexit code: %d" %
          (overall, ", ".join(nr) if nr else "none", Path(args.workdir) / "REPORT.md", code), flush=True)
    return code


if __name__ == "__main__":
    sys.exit(main())
